from tkinter import *
import time
from PIL import Image, ImageTk


def redWindow():
    firstWindow.destroy()
    fistWindow = Tk()
    fistWindow.config(background='black')  # for background color
    fistWindow.state('zoomed')
    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/red2.png")
    labelTwo3 = Label(fistWindow, image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(fistWindow, text=""" This is the color of extroversion, of a person with desire, appetite, a will to live life fully. You are somewhat aggressive,
    impulsive, perhaps athletic, surely quick to release your feelings and emotions.You have many ups and downs in your feelings.
    To you, life is meant to be happy, and when it isn’t, you are  confused and upset. You hate monotony, are quick to judge people,
    quick to form opinions and boldly express them.""",
                 font="ARIAL 12 bold", fg="#FF0000", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(fistWindow, text="""Your weakness: Red lovers often have a short fuse. We know you're just passionate, but watch your temper!
     Your special strength: Your zest for life! You truly live every moment as if it was your last and you have no regrets! Way to go!""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    fistWindow.mainloop()
def bluewindoww():
    firstWindow.destroy()
    secondWindow = Tk()
    secondWindow.config(background='black')  # for background color
    secondWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/blue2.png")
    labelTwo3 = Label(secondWindow , image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(secondWindow , text=""" Blue is the color of dreamers! Blue is associated with soft, soothing, compassionate and caring individuals.
    Blue people are also known to be introverts and daydreamers with their heads in the clouds. Blue people, however, also tend
     to be very trustworthy and reliable.In other words, you are very imaginative and creative, but you also have both feet
    on the ground! Blue lovers don't like having their feathers ruffled, often expressing a deep need for peace and harmony in their everyday life.
    You are sensitive,but not overly emotional, with an intuition that you can always rely on.""",
                 font="ARIAL 12 bold", fg="#00FFFF", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(secondWindow , text="""Your weakness: Blue lovers often have inflexible beliefs and can be too cautious. You're an old soul, but it's okay to lighten up a bit!
     Your special strength: Your intuition! Always trust your gut feeling, because it's always right!""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    secondWindow.mainloop()
def blackwindoww():
    firstWindow.destroy()
    sixthWindow = Tk()
    sixthWindow.config(background='black')  # for background color
    sixthWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/black2.png")
    labelTwo3 = Label(sixthWindow, image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(sixthWindow, text="""Black is the color of power and mystery! Black is both dignified and impressive,
    but also humble and hints at hidden secrets. People who love the color black tend to be
    refined, intelligent, inquisitive and always able to think outside the box. You always
    appear calm, collected and in control! You're a deep thinker and natural-born leader
    but your love for black indicates some hidden skeletons in your closet! """,
                 font="ARIAL 12 bold", fg="white", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(sixthWindow, text="""Your weakness: You may be a bit intimidating and sometimes rebellious, but you're really just a powerful thinker!
      your special strengths: You're incredibly responsible, intelligent, and capable. You have lots of leadership potential!""",
                 font="ARIAL 10 bold", fg="white", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    sixthWindow.mainloop()
def pinkwindoww():
    firstWindow.destroy()
    seventhWindow = Tk()
    seventhWindow.config(background='black')  # for background color
    seventhWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/pink2.png")
    labelTwo3 = Label(seventhWindow, image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(seventhWindow, text="""Pink is the color of love and affection! Pink people are loving, kind, generous and sensitive to the needs of others.
     Pink lovers have a unique maternal/paternal instinct and always know how to support their loved ones.
    In other words, you always have a shoulder for your friends to cry on! You are a true romantic at heart, appreciating the finer things in life
    and waiting for that one true love! You are also very sensual and many would say that you're absolutely irresistible! """,
                 font="ARIAL 12 bold", fg="#FF00FF", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(seventhWindow, text="""Your weakness: Pink lovers can be very emotional, and often wear their hearts on their sleeves. Stay positive and don't let anyone get you down!
    Your special strength: You have enough love for everyone! You are a true lover, with a heart of gold!""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    seventhWindow.mainloop()
def whitewindoww():
    firstWindow.destroy()
    eigthWindow = Tk()
    eigthWindow.config(background='black')  # for background color
    eigthWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/white2.png")
    labelTwo3 = Label(eigthWindow, image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(eigthWindow, text="""White is the color of purity and spirituality! This is a very special and unique favorite color.
     Interestingly, rarely is white a favorite color from a young age - white tends to become a
      favorite during transitional periods, new beginnings or during a search for a new direction.
       The winds of destiny may be blowing you in new directions; Pay attention! White lovers are
        on the move, with lots of changes happening around them. White are orderly, immaculate in
     appearance, and always seem to have an innocent twinkle in their eye. """,
                 font="ARIAL 12 bold", fg="white", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(eigthWindow, text="""Your weakness: White lovers have a tendency to be loners. You're very independent and self-sufficient, just don't forget that sometimes you do need friends!
      Your special strengths: You are well-balanced, sensible, discreet and wise.""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    eigthWindow.mainloop()
def greenwindoww():
    firstWindow.destroy()
    secondWindow = Tk()
    secondWindow.config(background='black')  # for background color
    secondWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/green2.png")
    labelTwo3 = Label(secondWindow , image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(secondWindow , text="""Green is the color of life and peace! Green people are down-to-earth, practical, peace seekers, and nature lovers.
     Green people tend to be very involved in their communities, always looking for a way to bring people together and reconcile differences.
      The desire for harmony drives many green lovers, making them excellent friends and coworkers. You would make an excellent counselor, psychologist,
       or social worker as you are a good listener and can view others problems with empathy""",
                 font="ARIAL 12 bold", fg="#008000", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(secondWindow , text="""Your weakness: You may be too peaceful! Green lovers are often too modest and patient, which leads to being exploited by others.
    Your special strength: You're healthy! Your body is in sync with nature and you know what's good for you and what's not. Keep it up!""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    secondWindow.mainloop()


def yellowwindow():

        firstWindow.destroy()
        forthWindow = Tk()
        forthWindow.config(background='black')  # for background color
        forthWindow.state('zoomed')

        photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/yellow3.png")
        labelTwo3 = Label(forthWindow, image=photoTwo3)
        labelTwo3.place(relx=.5, rely=.3, anchor="c")
        ylab = Label(forthWindow, text="""Yellow is the color of joy, warmth, luck, and energy!People who love yellow are known to have happy
         dispositions and are cheerful and fun to be with! Yellow people naturally bring warmth with them wherever they go. Numerous studies have found that
         yellow lovers are especially helpful and warm to strangers. You are also incredibly creative, full of lively ideas and loving advice.
          You are a true optimist at heart and you are always ready for an adventure!""",
                     font="ARIAL 10 bold", fg="#FFFF00", background='black')
        ylab.place(relx=.5, rely=.8, anchor="c")
        ylab = Label(forthWindow, text="""Your weakness: Yellow people are clear thinkers with a distinct vision of how
              they want their lives and surroundings to be, sometimes this comes across as
              being a perfectionist.
              Special strengths: It goes without saying that your warmth is one of your
              best qualities, but yellow people are also very independent and adventurous!""",
                     font="ARIAL 10 bold", fg="#FFFFFF", background='black')
        ylab.place(relx=.5, rely=.9, anchor="c")
        forthWindow.mainloop()

def purplewindow():
    firstWindow.destroy()
    fifthWindow = Tk()
    fifthWindow.config(background='black')  # for background color
    fifthWindow.state('zoomed')

    photoTwo3 = ImageTk.PhotoImage(file="E:/Python Projects/Project project pics/purple2.png")
    labelTwo3 = Label(fifthWindow, image=photoTwo3)
    labelTwo3.place(relx=.5, rely=.3, anchor="c")
    plab = Label(fifthWindow, text="""Purple is the color of royalty! In fact, in her time, Queen Elizabeth I banned anyone except close members of the royal family to wear it! It stands for luxury,
     wealth and sophistication. It is also the color of true romance and extreme sensitivity.People who love the color purple tend to inspire
     others with their creative minds and elegance. Purple people are mostly positive, although when they're upset, they see the world in completely dark colors.
      They also have a deep need for emotional security and to create order and perfection in all areas of life.""",
                 font="ARIAL 12 bold", fg="#800080", background='black')
    plab.place(relx=.5, rely=.8, anchor="c")
    plab = Label(fifthWindow, text="""Your weakness: You can sometimes be a bit arrogant, although you always try to make sure no one is hurt by that.
    Your special strengths: You have the ability to be very sympathetic and empathetic, which makes everyone around you feel important!""",
                 font="ARIAL 10 bold", fg="#FFFFFF", background='black')
    plab.place(relx=.5, rely=.9, anchor="c")
    fifthWindow.mainloop()

firstWindow = Tk()
firstWindow.config(background='black')  # for background color
# root["bg"] = "black"
firstWindow.state('zoomed')


firstWindow.title("Choose Your Favourite Color")

lab1 = Label(firstWindow, text="""Believe it or not your favorite color says a lot about you,
 your strengths, your weakness, and how others perceive you! Let's find out
what your favorite color says about you!""", font="ARIAL 14 bold", fg="#0000FF",background='black')
lab1.pack()
bigimg1 = PhotoImage(file="E:/Python Projects/Project project pics/choose.png")
img1 = PhotoImage(file="E:/Python Projects/Project project pics/red.png")
img2 = PhotoImage(file="E:/Python Projects/Project project pics/white.png")
img3 = PhotoImage(file="E:/Python Projects/Project project pics/black.png")
img4 = PhotoImage(file="E:/Python Projects/Project project pics/yellow.png")
img5 = PhotoImage(file="E:/Python Projects/Project project pics/blue.png")
img6 = PhotoImage(file="E:/Python Projects/Project project pics/green.png")
img7 = PhotoImage(file="E:/Python Projects/Project project pics/pink.png")
img8 = PhotoImage(file="E:/Python Projects/Project project pics/purple.png")

butt0= Button(firstWindow, image=bigimg1)
butt0.pack()

butt1= Button(firstWindow, image=img1, width=90, height=90,command=redWindow)
butt1.pack()
butt2= Button(firstWindow, image=img2, width=90, height=90,command=whitewindoww)
butt2.pack()
butt3= Button(firstWindow, image=img3, width=90, height=90,command=blackwindoww)
butt4= Button(firstWindow, image=img4, width=90, height=90,command=yellowwindow)
butt5= Button(firstWindow, image=img5, width=90, height=90,command=bluewindoww)
butt6= Button(firstWindow, image=img6, width=90, height=90,command=greenwindoww)
butt7= Button(firstWindow,image=img7, width=90, height=90,command=pinkwindoww)
butt8= Button(firstWindow, image=img8, width=90, height=90,command=purplewindow)
butt1.place(relx=.2, rely=.9, anchor="c")
butt2.place(relx=.3, rely=.9, anchor="c")
butt3.place(relx=.4, rely=.9, anchor="c")
butt4.place(relx=.5, rely=.9, anchor="c")
butt5.place(relx=.6, rely=.9, anchor="c")
butt6.place(relx=.7, rely=.9, anchor="c")
butt7.place(relx=.8, rely=.9, anchor="c")
butt8.place(relx=.9, rely=.9, anchor="c")

#closeBttn = Button(firstWindow, text="Close!", command=openNewWindow)
#closeBttn.pack()

#secBttn = Button(firstWindow, text="Close!", command=opennewwindoww)
#secBttn.pack()

firstWindow.mainloop()