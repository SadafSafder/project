from tkinter import *
from tkinter.colorchooser import *
import tkinter as tk
import os
import time
from PIL import ImageGrab
from PIL import Image, ImageTk
"""paint.py: not exactly a paint program.. just a smooth line drawing demo."""

b1 = "up"
xold, yold = None, None
def colortest():
    toplevel = Toplevel()
    toplevel.title('HTP TEST')
    toplevel.config(background='Navy')
    w = 800  # width for the Tk root
    h = 780  # height for the Tk root

    # get screen width and height
    ws = toplevel.winfo_screenwidth()  # width of the screen
    hs = toplevel.winfo_screenheight()  # height of the screen

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)


    # set the dimensions of the screen
    # and where it is placed
    # self.root.geometry('%dx%d+%d+%d' % (w, h, x, y))
    ######mainwindow#########
    lab1 = Label(toplevel, text="""Believe it or not your favorite color says a lot about you,
     your strengths, your weakness, and how others perceive you! Let's find out
    what your favorite color says about you!""", font="ARIAL 14 bold", fg="#0000FF", background='black')
    lab1.grid()

    toplevel.focus_set()
    toplevel.grab_set()

def mhello22():


    def myfunction(event):
        canvas.configure(scrollregion=canvas.bbox("all"), width=900, height=630)

    root1 = Toplevel()
    sizex = 1000
    sizey = 1080
    posx = 100
    posy = 100
    root1.wm_geometry("%dx%d+%d+%d" % (sizex, sizey, posx, posy))
    myframe = Frame(root1, relief=GROOVE, width=70, height=50, bd=1)
    myframe.place(x=10, y=15)

    canvas = Canvas(myframe)
    frame = Frame(canvas)
    myscrollbar = Scrollbar(myframe, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=myscrollbar.set)

    myscrollbar.pack(side="right", fill="y")
    canvas.pack(side="left")
    canvas.create_window((0, 0), window=frame, anchor='nw')
    frame.bind("<Configure>", myfunction)





    ########House Interpertation #########

    global checked1
    global checked2
    global checked3
    checked1 = IntVar()
    checked2 = IntVar()
    checked3 = IntVar()
    # roof1
    global checked4
    global checked5
    global checked6
    checked4 = IntVar()
    checked5 = IntVar()
    checked6 = IntVar()
    # wall
    global checked7
    global checked8
    checked7 = IntVar()
    checked8 = IntVar()
    # door
    global checked9
    global checked10
    global checked11
    checked9 = IntVar()
    checked10 = IntVar()
    checked11 = IntVar()
    # window
    global checked12
    global checked13
    global checked14
    checked12 = IntVar()
    checked13 = IntVar()
    checked14 = IntVar()
    # chimney
    global checked30
    global checked31
    global checked32
    checked30 = IntVar()
    checked31 = IntVar()
    checked32 = IntVar()
    # side walk
    global checked33
    global checked34
    global checked35
    checked33 = IntVar()
    checked34 = IntVar()
    checked35 = IntVar()
    # house decor
    global checked36
    global checked37
    global checked38
    checked36 = IntVar()
    checked37 = IntVar()
    checked38 = IntVar()
    ########Tree Interpertation #########
    # trunk
    global checked16
    global checked17
    global checked18
    checked16 = IntVar()
    checked17 = IntVar()
    checked18 = IntVar()
    # Branches
    global checked19
    global checked20
    global checked21
    global checked28
    checked19 = IntVar()
    checked20 = IntVar()
    checked21 = IntVar()
    checked28 = IntVar()
    # Leaves
    global checked22
    global checked23
    global checked24
    checked22 = IntVar()
    checked23 = IntVar()
    checked24 = IntVar()
    # root
    global checked25
    global checked26
    global checked27

    global checked29
    checked25 = IntVar()
    checked26 = IntVar()
    checked27 = IntVar()
    checked29 = IntVar()
    # roof
    global c1_value
    c1_value = 'The subjects devotes much of his time to phantasy, presumably seeking satisfaction therein.'
    global c2_value
    c2_value = 'A highly constricted, concrete orientation.'
    global c3_value
    c3_value = 'can indicate avoidance of overpowering and frightening fantasies.'
    # roof value1
    global c4_value
    c4_value = 'the person might tend to view the environment through a world of fantasy images. .'
    global c5_value
    c5_value = 'It shows axiety and depression.'
    global c6_value
    c6_value = 'like phantasy as well as reality.'
    # wall value
    global c7_value
    c7_value = 'weaknesses in the ego.'
    global c8_value
    c8_value = 'problems with anxiety and a need to reinforce boundaries.'
    # door value
    global c9_value
    c9_value = 'the person strong needs to engage others. .'
    global c10_value
    c10_value = 'some unwillingness to reveal much about yourself '
    global c11_value
    c11_value = 'you’re very dependent.'
    # windows value
    global c12_value
    c12_value = 'the person might willingness to interact with others and could be exhibitionistic desires. '
    global c13_value
    c13_value = 'It shows the persoson want to conceal himself from others'
    global c14_value
    c14_value = 'they feel insecure.'
    # chemney value
    global c30_value
    c30_value = 'the person might show his affective and sexual life. '
    global c31_value
    c31_value = 'It shows his affective and sexual life and also his internal tension.'
    global c32_value
    c32_value = ' you concel your feelings from others'
    # sidewalk value
    global c33_value
    c33_value = 'openness, access to your intimate family life..'
    global c34_value

    c34_value = 'some unwillingness to reveal much about yourself .'
    global c35_value
    c35_value = 'visitors coming or people in the home leaving.'
    # house decor value
    global c36_value
    global c37_value
    global c38_value
    c36_value = 'welcome visitors or reveal prowlers.'
    c37_value = 'stability and contact with reality.'
    c38_value = 'you forget the bad things.'
    ########Tree values #########
    ########trunk #########
    global c16_value
    global c17_value
    global c18_value
    c16_value = 'the person might have a weak ego .'
    c17_value = 'You have fragmented or split personality and serious mental illness, or a sign of organicity'
    c18_value = 'you have larger ego'
    # branches
    global c19_value
    global c20_value
    global c21_value
    global c28_value
    c19_value = 'the person might have difficulty communicate with others'
    c20_value = 'the person might connecting with others too much'
    c21_value = 'indicate hostility .'
    c28_value = 'represent desolation'
    # leaves
    global c22_value
    global c23_value
    global c24_value
    c22_value = 'represents successfully connecting with others, '
    c23_value = 'emptiness '
    c24_value = 'indicates a lack of nurturance.'
    # ROOT
    global c25_value
    global c26_value
    global c27_value
    global c29_value
    c25_value = 'grounded person. .'
    c26_value = 'instability'
    c27_value = 'indicate an obsession with examining reality '
    c29_value = 'represent feeling completely removed from reality.'

    ######## #########

    #HOUSE fUNCTION
    # roof
    def check():
        if checked1.get():
            c2.config(state=DISABLED)
            c3.config(state=DISABLED)

    def checkk():
        if checked2.get():
            c1.config(state=DISABLED)
            c3.config(state=DISABLED)

    def checkkk():
        if checked3.get():
            c1.config(state=DISABLED)
            c2.config(state=DISABLED)

            # roof1
    def check1():
        if checked4.get():
            c5.config(state=DISABLED)
            c6.config(state=DISABLED)

    def check2():
        if checked5.get():
            c4.config(state=DISABLED)
            c6.config(state=DISABLED)

    def check3():
        if checked6.get():
            c4.config(state=DISABLED)
            c5.config(state=DISABLED)

    # wall
    def checkwall():
        if checked7.get():
            c8.config(state=DISABLED)
    def checkwal():
        if checked8.get():
            c7.config(state=DISABLED)
    # door

    def checkdoor():
        if checked9.get():
            c10.config(state=DISABLED)
            c11.config(state=DISABLED)
    def checkdoor1():
        if checked10.get():
            c9.config(state=DISABLED)
            c11.config(state=DISABLED)

    def checkdoor2():
        if checked11.get():
            c9.config(state=DISABLED)
            c10.config(state=DISABLED)

            # door

    def checkwind():
        if checked12.get():
            c13.config(state=DISABLED)
            c14.config(state=DISABLED)

    def checkwindo():
        if checked13.get():
            c12.config(state=DISABLED)
            c14.config(state=DISABLED)

    def checkwindow():
        if checked14.get():
            c12.config(state=DISABLED)
            c14.config(state=DISABLED)
    # chimney
    def checkchm():
        if checked30.get():
            c31.config(state=DISABLED)
            c32.config(state=DISABLED)

    def checkchmn():
        if checked31.get():
            c30.config(state=DISABLED)
            c32.config(state=DISABLED)

    def checkchmney():
        if checked32.get():
            c30.config(state=DISABLED)
            c31.config(state=DISABLED)
    # side walk
    def checksw():
        if checked33.get():
            c34.config(state=DISABLED)
            c35.config(state=DISABLED)

    def checksw1():
        if checked34.get():
            c33.config(state=DISABLED)
            c35.config(state=DISABLED)

    def checksw2():
        if checked35.get():
            c33.config(state=DISABLED)
            c34.config(state=DISABLED)
    # house decor
    def checkdec():
        if checked36.get():
            c37.config(state=DISABLED)
            c38.config(state=DISABLED)

    def checkdec1():
        if checked37.get():
            c36.config(state=DISABLED)
            c38.config(state=DISABLED)

    def checkdec2():
        if checked38.get():
            c36.config(state=DISABLED)
            c37.config(state=DISABLED)
            # TREE fUNCTIONS
            # trunk

    def tcheck():
         if checked16.get():
             c17.config(state=DISABLED)
             c18.config(state=DISABLED)

    def tcheckk():
        if checked17.get():
            c16.config(state=DISABLED)
            c18.config(state=DISABLED)

    def tcheckkk():
        if checked18.get():
            c16.config(state=DISABLED)
            c17.config(state=DISABLED)
            # branches


    def bcheck():
        if checked19.get():
            c20.config(state=DISABLED)
            c21.config(state=DISABLED)
            c28.config(state=DISABLED)

    def bcheckk():
        if checked20.get():
            c19.config(state=DISABLED)
            c21.config(state=DISABLED)
            c28.config(state=DISABLED)


    def bcheckkk():
        if checked21.get():
            c19.config(state=DISABLED)
            c20.config(state=DISABLED)
            c28.config(state=DISABLED)


    def bcheckkkk():
        if checked28.get():
            c19.config(state=DISABLED)
            c20.config(state=DISABLED)
            c21.config(state=DISABLED)

            # leaves

    def lcheck():
        if checked22.get():
            c23.config(state=DISABLED)
            c24.config(state=DISABLED)


    def lcheckk():
        if checked23.get():
            c22.config(state=DISABLED)
            c24.config(state=DISABLED)


    def lcheckkk():
        if checked24.get():
            c23.config(state=DISABLED)
            c22.config(state=DISABLED)

            # root

    def rcheck():
        if checked25.get():
            c26.config(state=DISABLED)
            c27.config(state=DISABLED)
            c29.config(state=DISABLED)

    def rcheckk():
        if checked26.get():
            c25.config(state=DISABLED)
            c27.config(state=DISABLED)

            c29.config(state=DISABLED)

    def rcheckkk():
        if checked27.get():
            c25.config(state=DISABLED)
            c26.config(state=DISABLED)
            c29.config(state=DISABLED)

    def rcheckkkk():
        if checked29.get():
            c25.config(state=DISABLED)
            c26.config(state=DISABLED)
            c27.config(state=DISABLED)


    #House checkButtons
    # roof chkbuttons
    global c1

    c1 = Checkbutton(frame, text='large roof', variable=checked1, command=check,bg="Midnight Blue",fg="White")
    global c2
    c2 = Checkbutton(frame, text='Absence of roof', variable=checked2, command=checkk,bg="Midnight Blue",fg="White")
    global c3
    c3 = Checkbutton(frame, text=' incomplete, tiny, or burning roofs ', variable=checked3,command=checkkk,bg="Midnight Blue",fg="White")
    # roof chkbuttons1
    global c4
    global c5
    global c6
    c4 = Checkbutton(frame, text='windows are drawn on the roof', variable=checked4, command=check1,bg="Midnight Blue",fg="White")
    c5 = Checkbutton(frame, text='roof with massive lines ', variable=checked5, command=check2,bg="Midnight Blue",fg="White")
    c6 = Checkbutton(frame, text='roof with hollow line ', variable=checked6, command=check3,bg="Midnight Blue",fg="White")
    # wall chkbuttons
    global c7
    global c8
    c7 = Checkbutton(frame, text='Straight Walls ', variable=checked7, command=checkwall,bg="Midnight Blue",fg="White")
    c8 = Checkbutton(frame, text='Crumbling walls ', variable=checked8, command=checkwal,bg="Midnight Blue",fg="White")
    # door chkbuttons
    global c9
    global c10
    global c11
    c9 = Checkbutton(frame, text='Open door', variable=checked9, command=checkdoor,bg="Midnight Blue",fg="White")
    c10 = Checkbutton(frame, text='Close door or curtains ,bars on the door ', variable=checked10, command=checkdoor1,bg="Midnight Blue",fg="White")
    c11 = Checkbutton(frame, text='very large door ', variable=checked11, command=checkdoor2,bg="Midnight Blue",fg="White")
    # window chkbuttons
    global c12
    global c13
    global c14
    c12 = Checkbutton(frame, text='windows are open and large', variable=checked12, command=checkwind,bg="Midnight Blue",fg="White")
    c13 = Checkbutton(frame, text='windows are closed', variable=checked13, command=checkwindo,bg="Midnight Blue",fg="White")
    c14 = Checkbutton(frame, text='no window', variable=checked14, command=checkwindow,bg="Midnight Blue",fg="White")
    # chimney chkbuttons
    global c30
    global c31
    global c32

    c30 = Checkbutton(frame, text='chimney in the house ', variable=checked30, command=checkchm,bg="Midnight Blue",fg="White")
    c31 = Checkbutton(frame, text='chimney with smoke', variable=checked31, command=checkchmn,bg="Midnight Blue",fg="White")
    c32= Checkbutton(frame, text='no chimney', variable=checked32, command=checkchmney,bg="Midnight Blue",fg="White")
    # side walk chkbuttons
    global c33
    global c34
    global c35
    c33 = Checkbutton(frame, text=' large side walk ', variable=checked33, command=checksw,bg="Midnight Blue",fg="White")
    c34 = Checkbutton(frame, text='winding side walk ', variable=checked34, command=checksw1,bg="Midnight Blue",fg="White")
    c35 = Checkbutton(frame, text='cars on side wallk', variable=checked35, command=checksw2,bg="Midnight Blue",fg="White")
    # house decor chkbuttons
    global c36
    global c37
    global c38
    c36 = Checkbutton(frame, text='decorate with light', variable=checked36, command=checkdec,bg="Midnight Blue",fg="White",)
    c37 = Checkbutton(frame, text='decorate with ground and tress', variable=checked37, command=checkdec1,bg="Midnight Blue",fg="White")
    c38 = Checkbutton(frame, text='vantilators in rooms', variable=checked38, command=checkdec2,bg="Midnight Blue",fg="White")
    global c16

    c16 = Checkbutton(frame, text='small trunk ', variable=checked16, command=tcheck, bg="Midnight Blue", fg="White")
    global c17
    c17 = Checkbutton(frame, text='tree split down the middle, as if hit by lightening', variable=checked17,
                      command=tcheckk, bg="Midnight Blue", fg="White")
    global c18
    c18 = Checkbutton(frame, text='Large Trunk ', variable=checked18, command=tcheckkk, bg="Midnight Blue", fg="White")
    # branches chkbuttons
    global c19
    global c20
    global c21
    global c28
    c19 = Checkbutton(frame, text='detached or small branches ', variable=checked19, command=bcheck, bg="Midnight Blue",
                      fg="White")
    c20 = Checkbutton(frame, text='big branches ', variable=checked20, command=bcheckk, bg="Midnight Blue", fg="White")
    c21 = Checkbutton(frame, text='pointy branches ', variable=checked21, command=bcheckkk, bg="Midnight Blue",
                      fg="White")
    c28 = Checkbutton(frame, text='dead branches ', variable=checked28, command=bcheckkkk, bg="Midnight Blue", fg="White")
    # leaves chkbuttons
    global c22
    global c23
    global c24
    c22 = Checkbutton(frame, text='drawing leaves ', variable=checked22, command=lcheck, bg="Midnight Blue", fg="White")
    c23 = Checkbutton(frame, text='no leaves ', variable=checked23, command=lcheckk, bg="Midnight Blue", fg="White")
    c24 = Checkbutton(frame, text=' detached leaves  ', variable=checked24, command=lcheckkk, bg="Midnight Blue",
                      fg="White")
    # root chkbuttons
    global c25
    global c26
    global c27
    global c29
    c25 = Checkbutton(frame, text='normal roots ', variable=checked25, command=rcheck, bg="Midnight Blue", fg="White")
    c26 = Checkbutton(frame, text='lack of roots ', variable=checked26, command=rcheckk, bg="Midnight Blue", fg="White")
    c27 = Checkbutton(frame, text=' exaggerated roots  ', variable=checked27, command=rcheckkk, bg="Midnight Blue",
                      fg="White")
    c29 = Checkbutton(frame, text=' dead roots ', variable=checked29, command=rcheckkkk, bg="Midnight Blue", fg="White")

    img1 = PhotoImage(file="E:/VP python project Images/pngimg/House/largeroof.png")
    img1Btn = Button(frame, image=img1)
    img1Btn.image = img1
    img2 = PhotoImage(file="E:/VP python project Images/pngimg/House/noroof.png")
    img2Btn = Button(frame, image=img2)
    img2Btn.image = img2
    img3 = PhotoImage(file="E:/VP python project Images/pngimg/House/incompleteroof.png")
    img3Btn = Button(frame, image=img3)
    img3Btn.image = img3
    img4 = PhotoImage(file="E:/VP python project Images/pngimg/House/windowonroof.png")
    img4Btn = Button(frame, image=img4)
    img4Btn.image = img4
    img5 = PhotoImage(file="E:/VP python project Images/pngimg/House/massiveline.png")
    img5Btn = Button(frame, image=img5)
    img5Btn.image = img5
    img6 = PhotoImage(file="E:/VP python project Images/pngimg/House/hollowline.png")
    img6Btn = Button(frame, image=img6)
    img6Btn.image = img6
    # walls
    img7 = PhotoImage(file="E:/VP python project Images/pngimg/House/straightwall.png")
    img7Btn = Button(frame, image=img7)
    img7Btn.image = img7
    img8 = PhotoImage(file="E:/VP python project Images/pngimg/House/crumblingwall.png")
    img8Btn = Button(frame, image=img8)
    img8Btn.image = img8
    # door
    img9 = PhotoImage(file="E:/VP python project Images/pngimg/House/opendoor.png")
    img9Btn = Button(frame, image=img9)
    img9Btn.image = img9
    img10 = PhotoImage(file="E:/VP python project Images/pngimg/House/closeddoorr.png")
    img10Btn = Button(frame, image=img10)
    img10Btn.image = img10
    img11 = PhotoImage(file="E:/VP python project Images/pngimg/House/largedoor.png")
    img11Btn = Button(frame, image=img11)
    img11Btn.image = img11
    # window
    img12 = PhotoImage(file="E:/VP python project Images/pngimg/House/openwindw.png")
    img12Btn = Button(frame, image=img12)
    img12Btn.image = img12
    img13 = PhotoImage(file="E:/VP python project Images/pngimg/House/closedwindow.png")
    img13Btn = Button(frame, image=img13)
    img13Btn.image = img13
    img14 = PhotoImage(file="E:/VP python project Images/pngimg/House/nowindow.png")
    img14Btn = Button(frame, image=img14)
    img14Btn.image = img14
    # chimney
    img15 = PhotoImage(file="E:/VP python project Images/pngimg/House/chimney.png")
    img15Btn = Button(frame, image=img15)
    img15Btn.image = img15
    img16 = PhotoImage(file="E:/VP python project Images/pngimg/House/chimneysmoke.png")
    img16Btn = Button(frame, image=img16)
    img16Btn.image = img16
    img17 = PhotoImage(file="E:/VP python project Images/pngimg/House/nochimney.png")
    img17Btn = Button(frame, image=img17)
    img17Btn.image = img17

    # sidewalk
    img18 = PhotoImage(file="E:/VP python project Images/pngimg/House/largesidewalk.png")
    img18Btn = Button(frame, image=img18)
    img18Btn.image = img18
    img19 = PhotoImage(file="E:/VP python project Images/pngimg/House/windingsidewalk.png")
    img19Btn = Button(frame, image=img19)
    img19Btn.image = img19
    img20 = PhotoImage(file="E:/VP python project Images/pngimg/House/caronsidewalk.png")
    img20Btn = Button(frame, image=img20)
    img20Btn.image = img20
    img21 = PhotoImage(file="E:/VP python project Images/pngimg/House/housewithlight.png")
    img21Btn = Button(frame, image=img21)
    img21Btn.image = img21
    img22 = PhotoImage(file="E:/VP python project Images/pngimg/House/treeandground.png")
    img22Btn = Button(frame, image=img22)
    img22Btn.image = img22
    img23 = PhotoImage(file="E:/VP python project Images/ventilator.png")
    img23Btn = Button(frame, image=img23)
    img23Btn.image = img23


    #HOUSE QUETIONS
    # roof questions (q:1)
    lLm = Label(frame, text='HOUSE Interpertation.....',font="Arial 14 bold",bg="Midnight Blue",fg="White")
    lLm.grid(row=0, column=0, sticky=W)
    l2 = Label(frame, text='ROOF .....',bg="Midnight Blue",fg="White")
    l2.grid(row=1, column=0, sticky=W)
    c1.grid(row=4, column=0, sticky=W)
    c2.grid(row=4, column=1, sticky=W)
    c3.grid(row=4, column=2, sticky=W)
    img1Btn.grid(row=3, column=0, sticky=W)
    img2Btn.grid(row=3, column=1, sticky=W)
    img3Btn.grid(row=3, column=2, sticky=W)
    #l1 = Label(toplevel, text="Your gender:")
    #l1.grid(row=0, sticky=W)
    # q:2
    l3 = Label(frame, text='Roof decoration',bg="Midnight Blue",fg="White")
    l3.grid(row=5, column=0, sticky=W)
    img4Btn.grid(row=6, column=0, sticky=W)
    img5Btn.grid(row=6, column=1, sticky=W)
    img6Btn.grid(row=6, column=2, sticky=W)
    c4.grid(row=7, column=0, sticky=W)
    c5.grid(row=7, column=1, sticky=W)
    c6.grid(row=7, column=2, sticky=W)
    # wall questions
    l4 = Label(frame, text='Walls',bg="Midnight Blue",fg="White")
    l4.grid(row=8, column=0, sticky=W)
    img7Btn.grid(row=9, column=0, sticky=W)
    img8Btn.grid(row=9, column=1, sticky=W)
    c7.grid(row=10, column=0, sticky=W)
    c8.grid(row=10, column=1, sticky=W)
    # door questions
    l5 = Label(frame, text='Door....')
    l5.grid(row=11, column=0, sticky=W)
    img9Btn.grid(row=12, column=0, sticky=W)
    img10Btn.grid(row=12, column=1, sticky=W)
    img11Btn.grid(row=12, column=2, sticky=W)
    c9.grid(row=13, column=0, sticky=W)
    c10.grid(row=13, column=1, sticky=W)
    c11.grid(row=13, column=2, sticky=W)

    l6 = Label(frame, text='Window....')
    l6.grid(row=14, column=0, sticky=W)
    img12Btn.grid(row=15, column=0, sticky=W)
    img13Btn.grid(row=15, column=1, sticky=W)
    img14Btn.grid(row=15, column=2, sticky=W)
    c12.grid(row=16, column=0, sticky=W)
    c13.grid(row=16, column=1, sticky=W)
    c14.grid(row=16, column=2, sticky=W)
     #chimney
    l7 = Label(frame, text='CHIMNEY...')
    l7.grid(row=17, column=0, sticky=W)
    img15Btn.grid(row=18, column=0, sticky=W)
    img16Btn.grid(row=18, column=1, sticky=W)
    img17Btn.grid(row=18, column=2, sticky=W)
    c30.grid(row=19, column=0, sticky=W)
    c31.grid(row=19, column=1, sticky=W)
    c32.grid(row=19, column=2, sticky=W)
    # sidewalk questions
    l8 = Label(frame, text='side walks...')
    l8.grid(row=20, column=0, sticky=W)
    img18Btn.grid(row=21, column=0, sticky=W)
    img19Btn.grid(row=21, column=1, sticky=W)
    img20Btn.grid(row=21, column=2, sticky=W)
    c33.grid(row=22, column=0, sticky=W)
    c34.grid(row=22, column=1, sticky=W)
    c35.grid(row=22, column=2, sticky=W)
    #DECORATION of house
    l9 = Label(frame, text='house decoration with...')
    l9.grid(row=23, column=0, sticky=W)
    img21Btn.grid(row=24, column=0, sticky=W)
    img22Btn.grid(row=24, column=1, sticky=W)
    img23Btn.grid(row=24, column=2, sticky=W)
    c36.grid(row=25, column=0, sticky=W)
    c37.grid(row=25, column=1, sticky=W)
    c38.grid(row=25, column=2, sticky=W)




    but2 = Button(frame, text="next", bg="Midnight Blue", fg="White", command=win4)
    but2.grid(row=28, column=0, sticky=E)

    root1.mainloop()

def win4():


    def myfunction(event):
        canvas.configure(scrollregion=canvas.bbox("all"), width=900, height=630)

    root1 = Toplevel()
    sizex = 1000
    sizey = 1080
    posx = 100
    posy = 100
    root1.wm_geometry("%dx%d+%d+%d" % (sizex, sizey, posx, posy))
    myframe = Frame(root1, relief=GROOVE, width=70, height=50, bd=1)
    myframe.place(x=10, y=15)

    canvas = Canvas(myframe)
    frame = Frame(canvas)
    myscrollbar = Scrollbar(myframe, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=myscrollbar.set)

    myscrollbar.pack(side="right", fill="y")
    canvas.pack(side="left")
    canvas.create_window((0, 0), window=frame, anchor='nw')
    frame.bind("<Configure>", myfunction)

    ########Tree Interpertation #########
    # trunk
    global checked16
    global checked17
    global checked18
    checked16 = IntVar()
    checked17 = IntVar()
    checked18 = IntVar()
    # Branches
    global checked19
    global checked20
    global checked21
    global checked28
    checked19 = IntVar()
    checked20 = IntVar()
    checked21 = IntVar()
    checked28 = IntVar()
    # Leaves
    global checked22
    global checked23
    global checked24
    checked22 = IntVar()
    checked23 = IntVar()
    checked24 = IntVar()
    # root
    global checked25
    global checked26
    global checked27

    global checked29
    checked25 = IntVar()
    checked26 = IntVar()
    checked27 = IntVar()
    checked29 = IntVar()

    ########Tree values #########
    ########trunk #########
    global c16_value
    global c17_value
    global c18_value
    c16_value = 'the person might have a weak ego .'
    c17_value = 'You have fragmented or split personality and serious mental illness, or a sign of organicity'
    c18_value = 'you have larger ego'
    # branches
    global c19_value
    global c20_value
    global c21_value
    global c28_value
    c19_value = 'the person might have difficulty communicate with others'
    c20_value = 'the person might connecting with others too much'
    c21_value = 'indicate hostility .'
    c28_value = 'represent desolation'
    # leaves
    global c22_value
    global c23_value
    global c24_value
    c22_value = 'represents successfully connecting with others, '
    c23_value = 'emptiness '
    c24_value = 'indicates a lack of nurturance.'
    # ROOT
    global c25_value
    global c26_value
    global c27_value
    global c29_value
    c25_value = 'grounded person. .'
    c26_value = 'instability'
    c27_value = 'indicate an obsession with examining reality '
    c29_value = 'represent feeling completely removed from reality.'

    ######## #########

            # TREE fUNCTIONS
            # trunk

    def tcheck():
         if checked16.get():
             c17.config(state=DISABLED)
             c18.config(state=DISABLED)

    def tcheckk():
        if checked17.get():
            c16.config(state=DISABLED)
            c18.config(state=DISABLED)

    def tcheckkk():
        if checked18.get():
            c16.config(state=DISABLED)
            c17.config(state=DISABLED)
            # branches


    def bcheck():
        if checked19.get():
            c20.config(state=DISABLED)
            c21.config(state=DISABLED)
            c28.config(state=DISABLED)

    def bcheckk():
        if checked20.get():
            c19.config(state=DISABLED)
            c21.config(state=DISABLED)
            c28.config(state=DISABLED)


    def bcheckkk():
        if checked21.get():
            c19.config(state=DISABLED)
            c20.config(state=DISABLED)
            c28.config(state=DISABLED)


    def bcheckkkk():
        if checked28.get():
            c19.config(state=DISABLED)
            c20.config(state=DISABLED)
            c21.config(state=DISABLED)

            # leaves

    def lcheck():
        if checked22.get():
            c23.config(state=DISABLED)
            c24.config(state=DISABLED)


    def lcheckk():
        if checked23.get():
            c22.config(state=DISABLED)
            c24.config(state=DISABLED)


    def lcheckkk():
        if checked24.get():
            c23.config(state=DISABLED)
            c22.config(state=DISABLED)

            # root

    def rcheck():
        if checked25.get():
            c26.config(state=DISABLED)
            c27.config(state=DISABLED)
            c29.config(state=DISABLED)

    def rcheckk():
        if checked26.get():
            c25.config(state=DISABLED)
            c27.config(state=DISABLED)

            c29.config(state=DISABLED)

    def rcheckkk():
        if checked27.get():
            c25.config(state=DISABLED)
            c26.config(state=DISABLED)
            c29.config(state=DISABLED)

    def rcheckkkk():
        if checked29.get():
            c25.config(state=DISABLED)
            c26.config(state=DISABLED)
            c27.config(state=DISABLED)


    #House checkButtons
    # roof chkbuttons

    global c16

    c16 = Checkbutton(frame, text='small trunk ', variable=checked16, command=tcheck, bg="Midnight Blue", fg="White")
    global c17
    c17 = Checkbutton(frame, text='tree split down the middle, as if hit by lightening', variable=checked17,
                      command=tcheckk, bg="Midnight Blue", fg="White")
    global c18
    c18 = Checkbutton(frame, text='Large Trunk ', variable=checked18, command=tcheckkk, bg="Midnight Blue", fg="White")
    # branches chkbuttons
    global c19
    global c20
    global c21
    global c28
    c19 = Checkbutton(frame, text='detached or small branches ', variable=checked19, command=bcheck, bg="Midnight Blue",
                      fg="White")
    c20 = Checkbutton(frame, text='big branches ', variable=checked20, command=bcheckk, bg="Midnight Blue", fg="White")
    c21 = Checkbutton(frame, text='pointy branches ', variable=checked21, command=bcheckkk, bg="Midnight Blue",
                      fg="White")
    c28 = Checkbutton(frame, text='dead branches ', variable=checked28, command=bcheckkkk, bg="Midnight Blue", fg="White")
    # leaves chkbuttons
    global c22
    global c23
    global c24
    c22 = Checkbutton(frame, text='drawing leaves ', variable=checked22, command=lcheck, bg="Midnight Blue", fg="White")
    c23 = Checkbutton(frame, text='no leaves ', variable=checked23, command=lcheckk, bg="Midnight Blue", fg="White")
    c24 = Checkbutton(frame, text=' detached leaves  ', variable=checked24, command=lcheckkk, bg="Midnight Blue",
                      fg="White")
    # root chkbuttons
    global c25
    global c26
    global c27
    global c29
    c25 = Checkbutton(frame, text='normal roots ', variable=checked25, command=rcheck, bg="Midnight Blue", fg="White")
    c26 = Checkbutton(frame, text='lack of roots ', variable=checked26, command=rcheckk, bg="Midnight Blue", fg="White")
    c27 = Checkbutton(frame, text=' exaggerated roots  ', variable=checked27, command=rcheckkk, bg="Midnight Blue",
                      fg="White")
    c29 = Checkbutton(frame, text=' dead roots ', variable=checked29, command=rcheckkkk, bg="Midnight Blue", fg="White")

    img1 = PhotoImage(file="E:/VP python project Images/tree/smalltrunk.png")
    img1Btn = Button(frame, image=img1)
    img1Btn.image = img1
    img2 = PhotoImage(file="E:/VP python project Images/tree/lightsplitttree.png")
    img2Btn = Button(frame, image=img2)
    img2Btn.image = img2
    # walls
    img3 = PhotoImage(file="E:/VP python project Images/tree/largetrunk.png")
    img3Btn = Button(frame, image=img3)
    img3Btn.image = img3

    img4= PhotoImage(file="E:/VP python project Images/tree/detacthedbranch.png")
    img4Btn = Button(frame, image=img4)
    img4Btn.image = img1
    img5 = PhotoImage(file="E:/VP python project Images/tree/largebranch.png")
    img5Btn = Button(frame, image=img5)
    img5Btn.image = img5
    img6 = PhotoImage(file="E:/VP python project Images/tree/pointedbranch.png")
    img6Btn = Button(frame, image=img6)
    img6Btn.image = img6
    img7 = PhotoImage(file="E:/VP python project Images/tree/deadbranch.png")
    img7Btn = Button(frame, image=img7)
    img7Btn.image = img7

    img8 = PhotoImage(file="E:/VP python project Images/tree/drawingleaves.png")
    img8Btn = Button(frame, image=img8)
    img8Btn.image = img8
    # door
    img9 = PhotoImage(file="E:/VP python project Images/tree/noleaves.png")
    img9Btn = Button(frame, image=img9)
    img9Btn.image = img9
    img10 = PhotoImage(file="E:/VP python project Images/tree/deattachleaves.png")
    img10Btn = Button(frame, image=img10)
    img10Btn.image = img10

    img11 = PhotoImage(file="E:/VP python project Images/tree/normalroot.png")
    img11Btn = Button(frame, image=img11)
    img11Btn.image = img11
    img12 = PhotoImage(file="E:/VP python project Images/tree/noroot.png")
    img12Btn = Button(frame, image=img12)
    img12Btn.image = img12
    img13 = PhotoImage(file="E:/VP python project Images/tree/exaggeratedroot.png")
    img13Btn = Button(frame, image=img13)
    img13Btn.image = img13
    img14 = PhotoImage(file="E:/VP python project Images/tree/deadroot.png")
    img14Btn = Button(frame, image=img14)
    img14Btn.image = img14


    #HOUSE QUETIONS
    # roof questions (q:1)
    lLm = Label(frame, text='Tree Interpertation.....',font="Arial 14 bold",bg="Midnight Blue",fg="White")
    lLm.grid(row=0, column=0, sticky=W)
    l2 = Label(frame, text='Trunk .....',bg="Midnight Blue",fg="White")
    l2.grid(row=1, column=0, sticky=W)
    c16.grid(row=4, column=0, sticky=W)
    c17.grid(row=4, column=1, sticky=W)
    c18.grid(row=4, column=2, sticky=W)
    img1Btn.grid(row=3, column=0, sticky=W)
    img2Btn.grid(row=3, column=1, sticky=W)
    img3Btn.grid(row=3, column=2, sticky=W)
    #l1 = Label(toplevel, text="Your gender:")
    #l1.grid(row=0, sticky=W)
    # q:2
    l3 = Label(frame, text='Branches',bg="Midnight Blue",fg="White")
    l3.grid(row=5, column=0, sticky=W)
    img4Btn.grid(row=6, column=0, sticky=W)
    img5Btn.grid(row=6, column=1, sticky=W)
    img6Btn.grid(row=6, column=2, sticky=W)
    img7Btn.grid(row=6, column=3, sticky=W)
    c19.grid(row=7, column=0, sticky=W)
    c20.grid(row=7, column=1, sticky=W)
    c21.grid(row=7, column=2, sticky=W)
    c28.grid(row=7, column=3, sticky=W)

    l9 = Label(frame, text='LEAVES', bg="Midnight Blue", fg="White")
    l9.grid(row=8, column=0, sticky=W)
    img8Btn.grid(row=9, column=0, sticky=W)
    img9Btn.grid(row=9, column=1, sticky=W)
    img10Btn.grid(row=9, column=2, sticky=W)
    c22.grid(row=10, column=0, sticky=W)
    c23.grid(row=10, column=1, sticky=W)
    c24.grid(row=10, column=2, sticky=W)

    l10 = Label(frame, text='ROOT....', bg="Midnight Blue", fg="White")
    l10.grid(row=11, column=0, sticky=W)
    img11Btn.grid(row=12, column=0, sticky=W)
    img12Btn.grid(row=12, column=1, sticky=W)
    img13Btn.grid(row=12, column=2, sticky=W)
    img14Btn.grid(row=12, column=3, sticky=W)
    c25.grid(row=13, column=0, sticky=W)
    c26.grid(row=13, column=1, sticky=W)
    c27.grid(row=13, column=2, sticky=W)
    c29.grid(row=13, column=3, sticky=W)




    but2 = Button(frame, text="next", bg="Midnight Blue", fg="White", command=win3)
    but2.grid(row=28, column=0, sticky=E)

    root1.mainloop()

def win3():





    def myfunction(event):
        canvas.configure(scrollregion=canvas.bbox("all"), width=900, height=630)

    root1 = Toplevel()
    sizex = 1000
    sizey = 1080
    posx = 100
    posy = 100
    root1.wm_geometry("%dx%d+%d+%d" % (sizex, sizey, posx, posy))
    myframe = Frame(root1, relief=GROOVE, width=70, height=50, bd=1)
    myframe.place(x=10, y=15)

    canvas = Canvas(myframe)
    frame = Frame(canvas)
    myscrollbar = Scrollbar(myframe, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=myscrollbar.set)

    myscrollbar.pack(side="right", fill="y")
    canvas.pack(side="left")
    canvas.create_window((0, 0), window=frame, anchor='nw')
    frame.bind("<Configure>", myfunction)
    ########House variables #########
    # head
    global checked41
    global checked42
    global checked43
    checked41 = IntVar()
    checked42 = IntVar()
    checked43 = IntVar()
    # hair
    global checked44
    global checked45
    global checked146
    checked44 = IntVar()
    checked45 = IntVar()
    checked46 = IntVar()

    # eyes
    global checked47
    global checked48
    global checked49
    checked47 = IntVar()
    checked48 = IntVar()
    checked49 = IntVar()
    # mouth
    global checked50
    global checked51
    global checked52
    checked50 = IntVar()
    checked51 = IntVar()
    checked52 = IntVar()
    # nose
    global checked53
    global checked54
    global checked55
    checked53 = IntVar()
    checked54 = IntVar()
    checked55 = IntVar()
    # hands
    global checked56
    global checked57
    global checked58
    checked56 = IntVar()
    checked57 = IntVar()
    checked58 = IntVar()
    # neck
    global checked59
    global checked60
    global checked61
    checked59 = IntVar()
    checked60 = IntVar()
    checked61 = IntVar()
    # arms
    global checked62
    global checked63
    global checked64
    checked62 = IntVar()
    checked63 = IntVar()
    checked64 = IntVar()
    # legs
    global checked65
    global checked66
    global checked67
    checked65 = IntVar()
    checked66 = IntVar()
    checked67 = IntVar()
    # feet
    global checked68
    global checked69
    global checked70
    checked68 = IntVar()
    checked69 = IntVar()
    checked70 = IntVar()
    # person values############
    # head
    global c41_value
    global c42_value
    global c43_value
    c41_value = 'emphasize phantasy as a source of satisfaction.'
    c42_value = 'are obsessive compulsive subjects.'
    c43_value = 'you forget the bad things.'
    # size
    global c44_value
    global c45_value
    global c46_value
    c44_value = 'low self-esteem, depression, and lack of energy. '
    c45_value = 'healthy self-esteem.'
    c46_value = 'an inflated ego and delusions of grandeur. '
    # eyes
    global c47_value
    c47_value = 'connote a desire to see as little as possible'
    global c48_value
    c48_value = 'stability and contact with reality.'
    global c49_value
    c49_value = 'you forget the bad things.'
    # mouth
    global c50_value
    global c51_value
    global c52_value
    c50_value = '  neediness,a greedy, devouring and possessive attitude.'
    c51_value = ' expresses disgust or depression, disappointment with the world'
    c52_value = 'have conventional smile, thus expressing a certain social conformism'
    # nose
    global c53_value
    global c54_value
    c53_value = 'welcome visitors or reveal prowlers.'
    c54_value = 'stability and contact with reality.'
    # hands
    global c56_value
    global c57_value
    global c58_value
    global c55_value

    c56_value = 'imply impulsivity and ineptitude in the more refined aspects of social intercourse.'
    c57_value = 'suggests a reluctance to make refined and intimate contacts in psycho-social- intercourse'
    c58_value = 'this indicates feelings of lack of adaptation and the sensation of being clumsy'
    c55_value = 'suggest aggression.  '
    # neck
    global c59_value
    global c60_value
    global c61_value
    c59_value = 'no separation.'
    c60_value = 'desire for more separation of the two.'
    c61_value = 'affective inhibitions attentive control of expressing emotions.'
    # arms
    global c62_value
    global c63_value
    global c64_value
    c62_value = 'over-ambitious striving.'
    c63_value = 'connote an absence of striving'
    c64_value = 'suggested a basic feeling of strength for striving'
    # legs
    global c65_value
    global c66_value
    global c67_value
    c65_value = 'connote a strong striving for autonomy and desire of independenc'
    c66_value = 'imply feelings of construction'
    c67_value = 'lack of confidence'
    # feet
    global c68_value
    global c69_value
    global c70_value
    c68_value = ' desire of independence'
    c69_value = 'lack of confidence'
    c70_value = ' signify the idea of ambition or escape of the subject from an environment perceived as frustrating'

    # function of person

    # head
    def hcheck():
        if checked41.get():
            c42.config(state=DISABLED)
            c43.config(state=DISABLED)

    def hcheckk():
        if checked42.get():
            c43.config(state=DISABLED)
            c41.config(state=DISABLED)

    def hcheckkk():
        if checked43.get():
            c42.config(state=DISABLED)
            c41.config(state=DISABLED)

            # hair

    def hacheck():
        if checked44.get():
            c45.config(state=DISABLED)
            c46.config(state=DISABLED)

    def hacheckk():
        if checked45.get():
            c44.config(state=DISABLED)
            c46.config(state=DISABLED)

    def hacheckkk():
        if checked46.get():
            c44.config(state=DISABLED)
            c45.config(state=DISABLED)


            # eyes

    def echeck():
        if checked47.get():
            c48.config(state=DISABLED)
            c49.config(state=DISABLED)

    def echeckk():
        if checked48.get():
            c49.config(state=DISABLED)
            c47.config(state=DISABLED)

    def echeckkk():
        if checked49.get():
            c47.config(state=DISABLED)
            c48.config(state=DISABLED)


            # mouth

    def mcheck():
        if checked50.get():
            c51.config(state=DISABLED)
            c52.config(state=DISABLED)

    def mcheckk():
        if checked51.get():
            c52.config(state=DISABLED)
            c50.config(state=DISABLED)

    def mcheckkk():
        if checked52.get():
            c51.config(state=DISABLED)
            c50.config(state=DISABLED)

            # nose

    def ncheck():
        if checked53.get():
            c54.config(state=DISABLED)
            c55.config(state=DISABLED)

    def ncheckk():
        if checked54.get():
            c55.config(state=DISABLED)
            c53.config(state=DISABLED)


            # hands

    def hancheck():
        if checked56.get():
            c57.config(state=DISABLED)
            c58.config(state=DISABLED)
            c55.config(state=DISABLED)

    def hancheckk():
        if checked57.get():
            c56.config(state=DISABLED)
            c58.config(state=DISABLED)
            c55.config(state=DISABLED)

    def hancheckkk():
        if checked58.get():
            c56.config(state=DISABLED)
            c57.config(state=DISABLED)
            c55.config(state=DISABLED)

    def hancheckkkk():
        if checked55.get():
            c58.config(state=DISABLED)
            c56.config(state=DISABLED)
            c57.config(state=DISABLED)
            # neck

    def necheck():
        if checked59.get():
            c60.config(state=DISABLED)
            c61.config(state=DISABLED)

    def necheckk():
        if checked60.get():
            c59.config(state=DISABLED)
            c61.config(state=DISABLED)

    def necheckkk():
        if checked61.get():
            c59.config(state=DISABLED)
            c60.config(state=DISABLED)

            # arms

    def archeck():
        if checked62.get():
            c63.config(state=DISABLED)
            c64.config(state=DISABLED)

    def archeckk():
        if checked63.get():
            c62.config(state=DISABLED)
            c64.config(state=DISABLED)

    def archeckkk():
        if checked64.get():
            c63.config(state=DISABLED)
            c62.config(state=DISABLED)

            # legs

    def lecheck():
        if checked65.get():
            c66.config(state=DISABLED)
            c67.config(state=DISABLED)

    def lecheckk():
        if checked66.get():
            c65.config(state=DISABLED)
            c67.config(state=DISABLED)

    def lecheckkk():
        if checked67.get():
            c65.config(state=DISABLED)
            c66.config(state=DISABLED)

            # feet

    def fecheck():
        if checked68.get():
            c69.config(state=DISABLED)
            c70.config(state=DISABLED)

    def fecheckk():
        if checked69.get():
            c68.config(state=DISABLED)
            c70.config(state=DISABLED)

    def fecheckkk():
        if checked70.get():
            c68.config(state=DISABLED)
            c69.config(state=DISABLED)
            # person chkbuttons
            # head

    c41 = Checkbutton(frame, text='oversized heads ', variable=checked41, command=hcheck, bg="Midnight Blue", fg="White")
    c42 = Checkbutton(frame, text='small head  ', variable=checked42, command=hcheckk, bg="Midnight Blue", fg="White")
    c43 = Checkbutton(frame, text=' large Head  ', variable=checked43, command=hcheckkk, bg="Midnight Blue", fg="White")
    # person size
    c44 = Checkbutton(frame, text='A smaller person', variable=checked44, command=hacheck, bg="Midnight Blue",
                      fg="White")
    c45 = Checkbutton(frame, text='An average size person', variable=checked45, command=hacheckk, bg="Midnight Blue",
                      fg="White")
    c46 = Checkbutton(frame, text=' A  larger person   ', variable=checked46, command=hacheckkk, bg="Midnight Blue",
                      fg="White")
    # eyes
    c47 = Checkbutton(frame, text='small eyes  ', variable=checked47, command=echeck, bg="Midnight Blue", fg="White")
    c48 = Checkbutton(frame, text='Unusually large or strongly reinforced eyes ', variable=checked48, command=echeckk,
                      bg="Midnight Blue", fg="White")
    c49 = Checkbutton(frame, text=' Unusually small or closed eyes ', variable=checked49, command=echeckkk,
                      bg="Midnight Blue", fg="White")
    # mouth
    c50 = Checkbutton(frame, text=' big or open  ', variable=checked50, command=mcheck, bg="Midnight Blue", fg="White")
    c51 = Checkbutton(frame, text='frowning mouth or having the corners down  ', variable=checked51, command=mcheckk,
                      bg="Midnight Blue", fg="White")
    c52 = Checkbutton(frame, text='drawn with the corners up ', variable=checked52, command=mcheckkk, bg="Midnight Blue",
                      fg="White")
    # nose
    c53 = Checkbutton(frame, text='Nose drawn as a button or a triangle.', variable=checked53, command=ncheck,
                      bg="Midnight Blue", fg="White")
    c54 = Checkbutton(frame, text='Sharply-pointed', variable=checked54, command=ncheckk, bg="Midnight Blue", fg="White")

    # hands
    c56 = Checkbutton(frame, text='Large hands  ', variable=checked56, command=hancheck, bg="Midnight Blue", fg="White")
    c57 = Checkbutton(frame, text='Tiny hand  ', variable=checked57, command=hancheckk, bg="Midnight Blue", fg="White")
    c58 = Checkbutton(frame, text='hands are missing  ', variable=checked58, command=hancheckkk, bg="Midnight Blue",
                      fg="White")
    c55 = Checkbutton(frame, text='Fingers drawn like claws or anyway pointed', variable=checked55, command=hancheckkkk,
                      bg="Midnight Blue", fg="White")
    # neck
    c59 = Checkbutton(frame, text='no neck  ', variable=checked59, command=necheck, bg="Midnight Blue", fg="White")
    c60 = Checkbutton(frame, text='long neck ', variable=checked60, command=necheckk, bg="Midnight Blue", fg="White")
    c61 = Checkbutton(frame, text='neck (collar, tie, necklace) ', variable=checked61, command=necheckkk,
                      bg="Midnight Blue", fg="White")
    # arms
    c62 = Checkbutton(frame, text='Overly long arms  ', variable=checked62, command=archeck, bg="Midnight Blue",
                      fg="White")
    c63 = Checkbutton(frame, text='Very short arms  ', variable=checked63, command=archeckk, bg="Midnight Blue",
                      fg="White")
    c64 = Checkbutton(frame, text=' •	Broad arms  ', variable=checked64, command=archeckkk, bg="Midnight Blue",
                      fg="White")
    # legs
    c65 = Checkbutton(frame, text='thick and long legs ', variable=checked65, command=lecheck, bg="Midnight Blue",
                      fg="White")
    c66 = Checkbutton(frame, text=' short, fragile legs  ', variable=checked66, command=lecheckk, bg="Midnight Blue",
                      fg="White")
    c67 = Checkbutton(frame, text=' thin legs  ', variable=checked67, command=lecheckkk, bg="Midnight Blue", fg="White")
    # feet
    c68 = Checkbutton(frame, text=' big foot', variable=checked68, command=fecheck, bg="Midnight Blue", fg="White")
    c69 = Checkbutton(frame, text='small foot ', variable=checked69, command=fecheckk, bg="Midnight Blue", fg="White")
    c70 = Checkbutton(frame, text=' tiptoes  ', variable=checked70, command=fecheckkk, bg="Midnight Blue", fg="White")
    # person QUETIONS

    img1 = PhotoImage(file="E:/VP python project Images/person/oversizedhead.png")
    img1Btn = Button(frame, image=img1)
    img1Btn.image = img1
    img2 = PhotoImage(file="E:/VP python project Images/person/smallheadandeyes.png")
    img2Btn = Button(frame, image=img2)
    img2Btn.image = img2
    # walls
    img3 = PhotoImage(file="E:/VP python project Images/person/largehead.png")
    img3Btn = Button(frame, image=img3)
    img3Btn.image = img3

    img4 = PhotoImage(file="E:/VP python project Images/person/smallperson.png")
    img4Btn = Button(frame, image=img4)
    img4Btn.image = img1
    img5 = PhotoImage(file="E:/VP python project Images/person/averageperson.png")
    img5Btn = Button(frame, image=img5)
    img5Btn.image = img5
    img6 = PhotoImage(file="E:/VP python project Images/person/largeperson.png")
    img6Btn = Button(frame, image=img6)
    img6Btn.image = img6
    img7 = PhotoImage(file="E:/VP python project Images/person/smalleyess.png")
    img7Btn = Button(frame, image=img7)
    img7Btn.image = img7

    img8 = PhotoImage(file="E:/VP python project Images/person/usuallylarge.png")
    img8Btn = Button(frame, image=img8)
    img8Btn.image = img8
    # door
    img9 = PhotoImage(file="E:/VP python project Images/person/closedeyes.png")
    img9Btn = Button(frame, image=img9)
    img9Btn.image = img9
    img10 = PhotoImage(file="E:/VP python project Images/person/bigopn.png")
    img10Btn = Button(frame, image=img10)
    img10Btn.image = img10

    img11 = PhotoImage(file="E:/VP python project Images/person/frwon.png")
    img11Btn = Button(frame, image=img11)
    img11Btn.image = img11
    img12 = PhotoImage(file="E:/VP python project Images/person/cornerup.png")
    img12Btn = Button(frame, image=img12)
    img12Btn.image = img12
    img13 = PhotoImage(file="E:/VP python project Images/person/trianglenose.png")
    img13Btn = Button(frame, image=img13)
    img13Btn.image = img13
    img14 = PhotoImage(file="E:/VP python project Images/person/sharppointed.png")
    img14Btn = Button(frame, image=img14)
    img14Btn.image = img14
    img15 = PhotoImage(file="E:/VP python project Images/person/largehand.png")
    img15Btn = Button(frame, image=img15)
    img15Btn.image = img15
    img16 = PhotoImage(file="E:/VP python project Images/person/smallhand.png")
    img16Btn = Button(frame, image=img16)
    img16Btn.image = img16
    img17 = PhotoImage(file="E:/VP python project Images/person/missinghand.png")
    img17Btn = Button(frame, image=img17)
    img17Btn.image = img17
    img19 = PhotoImage(file="E:/VP python project Images/person/clawslikefingers.png")
    img19Btn = Button(frame, image=img19)
    img19Btn.image = img19
    img20 = PhotoImage(file="E:/VP python project Images/person/noneck.png")
    img20Btn = Button(frame, image=img20)
    img20Btn.image = img20
    img21 = PhotoImage(file="E:/VP python project Images/person/longneck.png")
    img21Btn = Button(frame, image=img21)
    img21Btn.image = img21
    img22 = PhotoImage(file="E:/VP python project Images/person/tienecklace.png")
    img22Btn = Button(frame, image=img22)
    img22Btn.image = img22
    img23 = PhotoImage(file="E:/VP python project Images/person/longarm.png")
    img23Btn = Button(frame, image=img23)
    img23Btn.image = img23
    img24 = PhotoImage(file="E:/VP python project Images/person/missinghand.png")
    img24Btn = Button(frame, image=img24)
    img24Btn.image = img24
    img25 = PhotoImage(file="E:/VP python project Images/person/broadarm.png")
    img25Btn = Button(frame, image=img25)
    img25Btn.image = img25
    img26 = PhotoImage(file="E:/VP python project Images/person/longleg.png")
    img26Btn = Button(frame, image=img26)
    img26Btn.image = img26
    img27 = PhotoImage(file="E:/VP python project Images/person/shortfragilelegs.png")
    img27Btn = Button(frame, image=img27)
    img27Btn.image = img27
    img28 = PhotoImage(file="E:/VP python project Images/person/thinlegs.png")
    img28Btn = Button(frame, image=img28)
    img28Btn.image = img28
    img29 = PhotoImage(file="E:/VP python project Images/person/bigfoot.png")
    img29Btn = Button(frame, image=img29)
    img29Btn.image = img29
    img30 = PhotoImage(file="E:/VP python project Images/person/smallfoot.png")
    img30Btn = Button(frame, image=img30)
    img30Btn.image = img30
    img31 = PhotoImage(file="E:/VP python project Images/person/tiptoes.png")
    img31Btn = Button(frame, image=img31)
    img31Btn.image = img31


    lL1 = Label(frame, text='Person Interpertation.....', font="Arial 16 bold", bg="Midnight Blue", fg="White")
    lL1.grid(row=0, column=0, sticky=W)
    # head
    l41 = Label(frame, text='Head....', bg="Midnight Blue", fg="White")
    l41.grid(row=1, column=0, sticky=W)
    img1Btn.grid(row=3, column=0, sticky=W)
    img2Btn.grid(row=3, column=1, sticky=W)
    img3Btn.grid(row=3, column=2, sticky=W)
    c41.grid(row=4, column=0, sticky=W)
    c42.grid(row=4, column=1, sticky=W)
    c43.grid(row=4, column=2, sticky=W)



    # hair
    l42 = Label(frame, text='Hair....', bg="Midnight Blue", fg="White")
    l42.grid(row=5, column=0, sticky=W)
    img4Btn.grid(row=6, column=0, sticky=W)
    img5Btn.grid(row=6, column=1, sticky=W)
    img6Btn.grid(row=6, column=2, sticky=W)
    c44.grid(row=7, column=0, sticky=W)
    c45.grid(row=7, column=1, sticky=W)
    c46.grid(row=7, column=2, sticky=W)

    # eyes
    l43 = Label(frame, text='eyes....', bg="Midnight Blue", fg="White")
    l43.grid(row=8, column=0, sticky=W)
    img7Btn.grid(row=9, column=0, sticky=W)
    img8Btn.grid(row=9, column=1, sticky=W)
    img9Btn.grid(row=9, column=2, sticky=W)
    c47.grid(row=10, column=0, sticky=W)
    c48.grid(row=10, column=1, sticky=W)
    c49.grid(row=10, column=2, sticky=W)
    # mouth
    l44 = Label(frame, text='mouth....', bg="Midnight Blue", fg="White")
    l44.grid(row=11, column=0, sticky=W)
    img10Btn.grid(row=12, column=0, sticky=W)
    img11Btn.grid(row=12, column=1, sticky=W)
    img12Btn.grid(row=12, column=2, sticky=W)
    c50.grid(row=13, column=0, sticky=W)
    c51.grid(row=13, column=1, sticky=W)
    c52.grid(row=13, column=2, sticky=W)
    # nose
    l45 = Label(frame, text='nose....', bg="Midnight Blue", fg="White")
    l45.grid(row=14, column=0, sticky=W)
    img13Btn.grid(row=15, column=0, sticky=W)
    img14Btn.grid(row=15, column=1, sticky=W)
    c53.grid(row=16, column=0, sticky=W)
    c54.grid(row=16, column=1, sticky=W)

    # hands
    l46 = Label(frame, text='hands....', bg="Midnight Blue", fg="White")
    l46.grid(row=17, column=0, sticky=W)
    img15Btn.grid(row=18, column=0, sticky=W)
    img16Btn.grid(row=18, column=1, sticky=W)
    img17Btn.grid(row=18, column=2, sticky=W)
    img19Btn.grid(row=18, column=3, sticky=W)
    c56.grid(row=19, column=0, sticky=W)
    c57.grid(row=19, column=1, sticky=W)
    c58.grid(row=19, column=2, sticky=W)
    c55.grid(row=19, column=3, sticky=W)
    # neck
    l47 = Label(frame, text='neck....', bg="Midnight Blue", fg="White")
    l47.grid(row=20, column=0, sticky=W)
    img20Btn.grid(row=21, column=0, sticky=W)
    img21Btn.grid(row=21, column=1, sticky=W)
    img22Btn.grid(row=21, column=2, sticky=W)
    c59.grid(row=22, column=0, sticky=W)
    c60.grid(row=22, column=1, sticky=W)
    c61.grid(row=22, column=2, sticky=W)
    # arms
    l48 = Label(frame, text='arms....', bg="Midnight Blue", fg="White")
    l48.grid(row=23, column=0, sticky=W)
    img23Btn.grid(row=24, column=0, sticky=W)
    img24Btn.grid(row=24, column=1, sticky=W)
    img25Btn.grid(row=24, column=2, sticky=W)
    c62.grid(row=25, column=0, sticky=W)
    c63.grid(row=25, column=1, sticky=W)
    c64.grid(row=25, column=2, sticky=W)
    # legs
    l49 = Label(frame, text='legs....', bg="Midnight Blue", fg="White")
    l49.grid(row=26, column=0, sticky=W)
    img26Btn.grid(row=27, column=0, sticky=W)
    img27Btn.grid(row=27, column=1, sticky=W)
    img28Btn.grid(row=27, column=2, sticky=W)
    c65.grid(row=28, column=0, sticky=W)
    c66.grid(row=28, column=1, sticky=W)
    c67.grid(row=28, column=2, sticky=W)
    # feet
    l50 = Label(frame, text='feet....', bg="Midnight Blue", fg="White")
    l50.grid(row=29, column=0, sticky=W)
    img29Btn.grid(row=30, column=0, sticky=W)
    img30Btn.grid(row=30, column=1, sticky=W)
    img31Btn.grid(row=30, column=2, sticky=W)
    c68.grid(row=31, column=0, sticky=W)
    c69.grid(row=31, column=1, sticky=W)
    c70.grid(row=31, column=2, sticky=W)

    # l2 = Label(toplevel, text="Your sex:")
    # l2.grid(row=5, sticky=W)
    # result show in label
    labres = Label(frame, wraplength=600, justify=LEFT)
    labres.grid(row=70, column=0)

    # c1 = Checkbutton(toplevel, text="male", variable=checked1, )
    # c1.grid(row=1, sticky=W)
    # c2 = Checkbutton(toplevel, text="female", variable=checked2)
    # c2.grid(row=2, sticky=W)
    Button(frame, text='Quit', command=quit).grid(row=72, sticky=W, pady=4)

    def callback():
        value = c1_value * checked1.get() + c2_value * checked2.get() + c3_value * checked3.get() + c4_value * checked4.get() + c5_value * checked5.get() + c6_value * checked6.get() + c7_value * checked7.get() + c8_value * checked8.get() + c9_value * checked9.get() + c10_value * checked10.get() + c11_value * checked11.get() + c12_value * checked12.get() + c13_value * checked13.get() + c14_value * checked14.get() + c16_value * checked16.get() + c17_value * checked17.get() + c18_value * checked18.get() + c19_value * checked19.get() + c20_value * checked20.get() + c20_value * checked20.get() + c21_value * checked22.get() + c28_value * checked28.get() + c23_value * checked23.get() + c24_value * checked24.get() + c25_value * checked25.get() + c26_value * checked26.get() + c27_value * checked27.get() + c29_value * checked29.get() + c30_value * checked30.get() + c31_value * checked31.get() + c32_value * checked32.get() + c33_value * checked33.get() + c34_value * checked34.get() + c35_value * checked35.get() + c36_value * checked36.get() + c37_value * checked37.get() + c38_value * checked38.get() + c41_value * checked41.get() + c42_value * checked42.get() + c43_value * checked43.get() + c44_value * checked44.get() + c45_value * checked45.get() + c46_value * checked47.get() + c48_value * checked48.get() + c49_value * checked49.get() + c50_value * checked50.get() + c51_value * checked51.get() + c52_value * checked52.get() + c53_value * checked53.get() + c54_value * checked54.get() + c55_value * checked55.get() + c56_value * checked56.get() + c57_value * checked57.get() + c58_value * checked58.get() + c59_value * checked59.get() + c60_value * checked60.get() + c61_value * checked61.get() + c62_value * checked62.get() + c63_value * checked63.get() + c64_value * checked64.get() + c65_value * checked65.get() + c66_value * checked66.get() + c67_value * checked67.get() + c68_value * checked68.get() + c69_value * checked69.get() + c70_value * checked70.get()
        labres.config(text=str(value))

    buttcall = Button(frame, text='Show', command=callback)
    buttcall.grid(row=73, sticky=W, pady=4)


    root1.mainloop()






def screenshott():
    box = (0, 0, 1320, 770)
    im = ImageGrab.grab(box)
    im.save(os.getcwd() + '\\screenshot_' + str(int(time.time())) + '.png', 'PNG')


def paintt():
    toplevel = Toplevel()
    toplevel.title('HTP TEST')
    toplevel.config(background='Navy')
    w = 800  # width for the Tk root
    h = 780  # height for the Tk root

    # get screen width and height
    ws = toplevel.winfo_screenwidth()  # width of the screen
    hs = toplevel.winfo_screenheight()  # height of the screen

    # calculate x and y coordinates for the Tk root window
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)

    # set the dimensions of the screen
    # and where it is placed
    # self.root.geometry('%dx%d+%d+%d' % (w, h, x, y))
    ######mainwindow#########
    lab1 = Label(toplevel, text="""Believe it or not your favorite color says a lot about you,
        your strengths, your weakness, and how others perceive you! Let's find out
       what your favorite color says about you!""", font="ARIAL 14 bold", fg="#0000FF", background='black')
    lab1.grid()

    toplevel.focus_set()
    toplevel.grab_set()





class Paint(object):

    DEFAULT_PEN_SIZE = 5.0
    DEFAULT_COLOR = 'black'


    def __init__(self):


        self.initUI()


    def initUI(self):
        self.root = Tk()


        #w = 1405  # width for the Tk root
       # h = 780  # height for the Tk root

        # get screen width and height
       # ws = self.root.winfo_screenwidth()  # width of the screen
        #hs = self.root.winfo_screenheight()  # height of the screen

        # calculate x and y coordinates for the Tk root window
       # x = (ws / 2) - (w / 2)
#        y = (hs / 2) - (h / 2)

        # set the dimensions of the screen
        # and where it is placed
        #self.root.geometry('%dx%d+%d+%d' % (w, h, x, y))
        self.root.attributes('-fullscreen', True)
        self.root.title("Draw a person tree and house here")
        self.root.config(background='Midnight Blue')
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)



        lmain= Label(self.root, text='Draw a House,Tree and Person here',font="Arial 16 bold",bg="Midnight Blue",fg="White")
        lmain.grid(row=2, column=0)

        img1 = PhotoImage("E:/VP python project Images/pencil1.png")
        self.pen_button = Button(self.root,image=img1, text='pen',bg="Midnight Blue",fg="White", command=self.use_pen)
        self.pen_button.grid(row=1,column=1,sticky=E)

        img2 = PhotoImage(file="E:/VP python project Images/brush1.png")
        self.brush_button = Button(self.root,image=img2, text='brush',bg="Midnight Blue",fg="White", command=self.use_brush)
        self.brush_button.grid(row=1,column=2,sticky=E)

        img3 = PhotoImage(file="E:/VP python project Images/paint1.png")

        self.color_button = Button(self.root,image=img3, text='color',bg="Midnight Blue",fg="White", command=self.choose_color)
        self.color_button.grid(row=1,column=3,sticky=E)

        img4 = PhotoImage(file="E:/VP python project Images/eraser1.png")

        self.eraser_button = Button(self.root,image=img4, text='eraser',bg="Midnight Blue",fg="White", command=self.use_eraser)
        self.eraser_button.grid(row=1,column=4,sticky=E)


        self.choose_size_button = Scale(self.root, from_=1, to=10, orient=HORIZONTAL,bg="Midnight Blue",fg="White", width = 24)
        self.choose_size_button.grid(row=1,column=5,sticky=E)
        img5 = PhotoImage(file="E:/VP python project Images/ok1.png")

        self.but1 = Button(self.root,image=img5, text="Done",bg="Midnight Blue",fg="White", command=mhello22)
        self.but1.grid(row=4,column=1,sticky=E)
        img6 = PhotoImage(file="E:/VP python project Images/quit.png")
        self.but2 = Button(self.root,image=img6, text="quit",bg="Midnight Blue",fg="White", command=quit)
        self.but2.grid(row=4, column=2, sticky=E)
        self.c = Canvas(self.root, bg='white', width=1300, height=630)
        self.c.grid(row=3, columnspan=5)

        self.setup()
        self.root.mainloop()

    def setup(self):
        self.old_x = None
        self.old_y = None
        self.line_width = self.choose_size_button.get()
        self.color = self.DEFAULT_COLOR
        self.eraser_on = False
        self.active_button = self.pen_button
        self.c.bind('<B1-Motion>', self.paint)
        self.c.bind('<ButtonRelease-1>', self.reset)

    def use_pen(self):
        self.activate_button(self.pen_button)

    def use_brush(self):
        self.activate_button(self.brush_button)

    def choose_color(self):
        self.eraser_on = False
        self.color = askcolor(color=self.color)[1]

    def use_eraser(self):
        self.activate_button(self.eraser_button, eraser_mode=True)

    #TODO: reset canvas
    #TODO: undo and redo
    #TODO: draw triangle, rectangle, oval, text

    def activate_button(self, some_button, eraser_mode=False):
        self.active_button.config(relief=RAISED)
        some_button.config(relief=SUNKEN)
        self.active_button = some_button
        self.eraser_on = eraser_mode

    def paint(self, event):
        self.line_width = self.choose_size_button.get()
        paint_color = 'white' if self.eraser_on else self.color
        if self.old_x and self.old_y:
            self.c.create_line(self.old_x, self.old_y, event.x, event.y,
                               width=self.line_width, fill=paint_color,
                               capstyle=ROUND, smooth=TRUE, splinesteps=36)
        self.old_x = event.x
        self.old_y = event.y

    def reset(self, event):
        self.old_x, self.old_y = None, None


if __name__ == '__main__':
    ge = Paint()



