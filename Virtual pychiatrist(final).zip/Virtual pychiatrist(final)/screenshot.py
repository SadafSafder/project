import tkinter as tk
 # PIL
from PIL import ImageGrab



def key(event):
    """modified Tkinter keylogger"""
    if event.keysym == 'F7':
        root.bell()
        # don't show window, move to taskbar as icon
        root.iconify()
        # small delay to allow tk window to fade on LCDs
        for x in range(1000000):
            x = x + 77
        # this will grab the whole screen display and save it to a file
        img = ImageGrab.grab()
        img.save("screenImage1.jpg")
        # this will grab a 400 pixel wide and 300 pixel heigh partion
        # upper left corner screen coordinates x=0, y=0
        img = ImageGrab.grab((0, 0, 400, 300))
        img.save("screenImage2.jpg")
root = tk.Tk()
root.title('Screen Image Grabber')
str1 = """\
Key F7 will make this program move to the taskbar as an icon
and then take a image grab of the screen and save to a file
"""
tk.Label(root, text=str1, bg='yellow').pack()
root.bind_all('<Key>', key)
root.mainloop()