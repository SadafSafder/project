import tkinter as tk
 # PIL
from PIL import ImageGrab
import os
import time


def screenGrab():
    box = (0, 0, 1920, 1080)
    im = ImageGrab.grab(box)
    im.save(os.getcwd() + '\\screenshot_' + str(int(time.time())) + '.png', 'PNG')


def main():
    screenGrab()

if __name__ == '__main__':
    main()