from tkinter import *
from tkinter.colorchooser import *
import tkinter as tk
import os
import time
from PIL import ImageGrab
from PIL import Image, ImageTk
"""paint.py: not exactly a paint program.. just a smooth line drawing demo."""




class Paint(object):

    DEFAULT_PEN_SIZE = 5.0
    DEFAULT_COLOR = 'black'


    def __init__(self):


        self.initUI()


    def initUI(self):
        self.root = Tk()


        #w = 1405  # width for the Tk root
       # h = 780  # height for the Tk root

        # get screen width and height
       # ws = self.root.winfo_screenwidth()  # width of the screen
        #hs = self.root.winfo_screenheight()  # height of the screen

        # calculate x and y coordinates for the Tk root window
       # x = (ws / 2) - (w / 2)
#        y = (hs / 2) - (h / 2)

        # set the dimensions of the screen
        # and where it is placed
        #self.root.geometry('%dx%d+%d+%d' % (w, h, x, y))
        self.root.attributes('-fullscreen', True)
        self.root.title("Draw a person tree and house here")
        self.root.config(background='Midnight Blue')
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)



        lmain= Label(self.root, text='Draw a House,Tree and Person here',font="Arial 16 bold",bg="Midnight Blue",fg="White")
        lmain.grid(row=2, column=0)

        img1 = PhotoImage("E:/VP python project Images/pencil1.png")
        self.pen_button = Button(self.root,image=img1, text='pen',bg="Midnight Blue",fg="White", command=self.use_pen)
        self.pen_button.grid(row=1,column=1,sticky=E)

        img2 = PhotoImage(file="E:/VP python project Images/brush1.png")
        self.brush_button = Button(self.root,image=img2, text='brush',bg="Midnight Blue",fg="White", command=self.use_brush)
        self.brush_button.grid(row=1,column=2,sticky=E)

        img3 = PhotoImage(file="E:/VP python project Images/paint1.png")

        self.color_button = Button(self.root,image=img3, text='color',bg="Midnight Blue",fg="White", command=self.choose_color)
        self.color_button.grid(row=1,column=3,sticky=E)

        img4 = PhotoImage(file="E:/VP python project Images/eraser1.png")

        self.eraser_button = Button(self.root,image=img4, text='eraser',bg="Midnight Blue",fg="White", command=self.use_eraser)
        self.eraser_button.grid(row=1,column=4,sticky=E)


        self.choose_size_button = Scale(self.root, from_=1, to=10, orient=HORIZONTAL,bg="Midnight Blue",fg="White", width = 24)
        self.choose_size_button.grid(row=1,column=5,sticky=E)
        img5 = PhotoImage(file="E:/VP python project Images/ok1.png")

        self.but1 = Button(self.root,image=img5, text="Done",bg="Midnight Blue",fg="White")
        self.but1.grid(row=4,column=1,sticky=E)
        img6 = PhotoImage(file="E:/VP python project Images/quit.png")
        self.but2 = Button(self.root,image=img6, text="quit",bg="Midnight Blue",fg="White", command=quit)
        self.but2.grid(row=4, column=2, sticky=E)
        self.c = Canvas(self.root, bg='white', width=1300, height=630)
        self.c.grid(row=3, columnspan=5)

        self.setup()
        self.root.mainloop()

    def setup(self):
        self.old_x = None
        self.old_y = None
        self.line_width = self.choose_size_button.get()
        self.color = self.DEFAULT_COLOR
        self.eraser_on = False
        self.active_button = self.pen_button
        self.c.bind('<B1-Motion>', self.paint)
        self.c.bind('<ButtonRelease-1>', self.reset)

    def use_pen(self):
        self.activate_button(self.pen_button)

    def use_brush(self):
        self.activate_button(self.brush_button)

    def choose_color(self):
        self.eraser_on = False
        self.color = askcolor(color=self.color)[1]

    def use_eraser(self):
        self.activate_button(self.eraser_button, eraser_mode=True)

    #TODO: reset canvas
    #TODO: undo and redo
    #TODO: draw triangle, rectangle, oval, text

    def activate_button(self, some_button, eraser_mode=False):
        self.active_button.config(relief=RAISED)
        some_button.config(relief=SUNKEN)
        self.active_button = some_button
        self.eraser_on = eraser_mode

    def paint(self, event):
        self.line_width = self.choose_size_button.get()
        paint_color = 'white' if self.eraser_on else self.color
        if self.old_x and self.old_y:
            self.c.create_line(self.old_x, self.old_y, event.x, event.y,
                               width=self.line_width, fill=paint_color,
                               capstyle=ROUND, smooth=TRUE, splinesteps=36)
        self.old_x = event.x
        self.old_y = event.y

    def reset(self, event):
        self.old_x, self.old_y = None, None

firstWindow = Tk()
firstWindow.config(background='black')  # for background color
# root["bg"] = "black"
firstWindow.state('zoomed')

img3 = PhotoImage(file="E:/VP python project Images/paint1.png")
but1 = Button(firstWindow, image=img3, text='color', bg="Midnight Blue", fg="White", command=lambda:Paint.initUI)
but1.grid(row=1, column=3, sticky=E)

firstWindow.title("Choose Your Favourite Color")
firstWindow.mainloop()
