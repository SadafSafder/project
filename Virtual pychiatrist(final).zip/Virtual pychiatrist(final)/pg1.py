from tkinter import *
from tkinter.colorchooser import *
from PIL import Image, ImageTk



b1 = "up"
xold, yold = None, None


def mhello22():
    toplevel = Toplevel()
    toplevel.title('Another window')

    ########House Interpertation #########
    #roof
    checked1 = IntVar()
    checked2 = IntVar()
    checked3 = IntVar()
    # roof1
    checked4 = IntVar()
    checked5 = IntVar()
    checked6 = IntVar()
    # wall
    checked7 = IntVar()
    checked8 = IntVar()
    # door
    checked9 = IntVar()
    checked10 = IntVar()
    checked11 = IntVar()
    # window
    checked12 = IntVar()
    checked13 = IntVar()
    checked14 = IntVar()
    #chimney
    checked30 = IntVar()
    checked31 = IntVar()
    checked32 = IntVar()
    # side walk
    checked33 = IntVar()
    checked34 = IntVar()
    checked35 = IntVar()
    # house decor
    checked36 = IntVar()
    checked37 = IntVar()
    checked38 = IntVar()

    ########Tree Interpertation #########
       #trunk
    checked16 = IntVar()
    checked17 = IntVar()
    checked18= IntVar()
    # Branches
    checked19 = IntVar()
    checked20 = IntVar()
    checked21 = IntVar()
    checked28 = IntVar()
    # Leaves
    checked22 = IntVar()
    checked23 = IntVar()
    checked24 = IntVar()
    #root
    checked25 = IntVar()
    checked26 = IntVar()
    checked27 = IntVar()
    checked29 = IntVar()
    ########House variables #########
    #head
    checked41 = IntVar()
    checked42 = IntVar()
    checked43 = IntVar()
    #hair
    checked44 = IntVar()
    checked45 = IntVar()
    checked46 = IntVar()

    #eyes
    checked47 = IntVar()
    checked48= IntVar()
    checked49 = IntVar()
    #mouth
    checked50 = IntVar()
    checked51 = IntVar()
    checked52 = IntVar()
    #nose
    checked53 = IntVar()
    checked54 = IntVar()
    checked55 = IntVar()
    #hands
    checked56 = IntVar()
    checked57= IntVar()
    checked58= IntVar()
    #neck
    checked59 = IntVar()
    checked60 = IntVar()
    checked61 = IntVar()
    #arms
    checked62 = IntVar()
    checked63= IntVar()
    checked64= IntVar()
    #legs
    checked65 = IntVar()
    checked66 = IntVar()
    checked67= IntVar()
    #feet
    checked68 = IntVar()
    checked69 = IntVar()
    checked70 = IntVar()

    #roof
    c1_value = 'The subjects devotes much of his time to phantasy, presumably seeking satisfaction therein.'
    c2_value = 'A highly constricted, concrete orientation.'
    c3_value = 'can indicate avoidance of overpowering and frightening fantasies.'
    # roof value1
    c4_value = 'the person might tend to view the environment through a world of fantasy images. .'
    c5_value = 'It shows axiety and depression.'
    c6_value = 'like phantasy as well as reality.'
    # wall value
    c7_value = 'weaknesses in the ego.'
    c8_value = 'problems with anxiety and a need to reinforce boundaries.'
    # door value
    c9_value = 'the person strong needs to engage others. .'
    c10_value = 'some unwillingness to reveal much about yourself '
    c11_value = 'you’re very dependent.'
    # windows value
    c12_value = 'the person might willingness to interact with others and could be exhibitionistic desires. '
    c13_value = 'It shows the persoson want to conceal himself from others'
    c14_value = 'they feel insecure.'
    # chemney value
    c30_value = 'the person might show his affective and sexual life. '
    c31_value = 'It shows his affective and sexual life and also his internal tension.'
    c32_value = ' you concel your feelings from others'
    # sidewalk value
    c33_value = 'openness, access to your intimate family life..'
    c34_value = 'some unwillingness to reveal much about yourself .'
    c35_value = 'visitors coming or people in the home leaving.'
    # house decor value
    c36_value = 'welcome visitors or reveal prowlers.'
    c37_value = 'stability and contact with reality.'
    c38_value = 'you forget the bad things.'

    #person values############
    #head
    c41_value = 'emphasize phantasy as a source of satisfaction.'
    c42_value = 'are obsessive compulsive subjects.'
    c43_value = 'you forget the bad things.'
    #size
    c44_value = 'low self-esteem, depression, and lack of energy. '
    c45_value = 'healthy self-esteem.'
    c46_value = 'an inflated ego and delusions of grandeur. '
    #eyes
    c47_value = 'connote a desire to see as little as possible'
    c48_value = 'stability and contact with reality.'
    c49_value = 'you forget the bad things.'
    #mouth
    c50_value = '  neediness,a greedy, devouring and possessive attitude.'
    c51_value = ' expresses disgust or depression, disappointment with the world'
    c52_value = 'have conventional smile, thus expressing a certain social conformism'
    #nose
    c53_value = 'welcome visitors or reveal prowlers.'
    c54_value = 'stability and contact with reality.'
    #hands

    c56_value = 'imply impulsivity and ineptitude in the more refined aspects of social intercourse.'
    c57_value = 'suggests a reluctance to make refined and intimate contacts in psycho-social- intercourse'
    c58_value = 'this indicates feelings of lack of adaptation and the sensation of being clumsy'
    c55_value = 'suggest aggression.  '
    #neck
    c59_value = 'no separation.'
    c60_value = 'desire for more separation of the two.'
    c61_value = 'affective inhibitions attentive control of expressing emotions.'
    #arms
    c62_value = 'over-ambitious striving.'
    c63_value = 'connote an absence of striving'
    c64_value = 'suggested a basic feeling of strength for striving'
    #legs
    c65_value = 'connote a strong striving for autonomy and desire of independenc'
    c66_value = 'imply feelings of construction'
    c67_value = 'lack of confidence'
    #feet
    c68_value = ' desire of independence'
    c69_value = 'lack of confidence'
    c70_value = ' signify the idea of ambition or escape of the subject from an environment perceived as frustrating'


    ########Tree values #########
    ########trunk #########
    c16_value = 'the person might have a weak ego .'
    c17_value = 'You have fragmented or split personality and serious mental illness, or a sign of organicity'
    c18_value = 'you have larger ego'
    #branches
    c19_value = 'the person might have difficulty communicate with others'
    c20_value = 'the person might connecting with others too much'
    c21_value = 'indicate hostility .'
    c28_value = 'represent desolation'
    #leaves
    c22_value = 'represents successfully connecting with others, '
    c23_value = 'emptiness '
    c24_value = 'indicates a lack of nurturance.'
    #ROOT
    c25_value = 'grounded person. .'
    c26_value = 'instability'
    c27_value = 'indicate an obsession with examining reality '
    c29_value = 'represent feeling completely removed from reality.'


    ######## #########

    #HOUSE fUNCTION
    # roof
    def check():
        if checked1.get():
            c2.config(state=DISABLED)
            c3.config(state=DISABLED)

    def checkk():
        if checked2.get():
            c1.config(state=DISABLED)
            c3.config(state=DISABLED)

    def checkkk():
        if checked3.get():
            c1.config(state=DISABLED)
            c2.config(state=DISABLED)

            # roof1
    def check1():
        if checked4.get():
            c5.config(state=DISABLED)
            c6.config(state=DISABLED)

    def check2():
        if checked5.get():
            c4.config(state=DISABLED)
            c6.config(state=DISABLED)

    def check3():
        if checked6.get():
            c4.config(state=DISABLED)
            c5.config(state=DISABLED)

    # wall
    def checkwall():
        if checked7.get():
            c8.config(state=DISABLED)
    def checkwal():
        if checked8.get():
            c7.config(state=DISABLED)
    # door

    def checkdoor():
        if checked9.get():
            c10.config(state=DISABLED)
            c11.config(state=DISABLED)
    def checkdoor1():
        if checked10.get():
            c9.config(state=DISABLED)
            c11.config(state=DISABLED)

    def checkdoor2():
        if checked11.get():
            c9.config(state=DISABLED)
            c10.config(state=DISABLED)

            # door

    def checkwind():
        if checked12.get():
            c13.config(state=DISABLED)
            c14.config(state=DISABLED)

    def checkwindo():
        if checked13.get():
            c12.config(state=DISABLED)
            c14.config(state=DISABLED)

    def checkwindow():
        if checked14.get():
            c12.config(state=DISABLED)
            c14.config(state=DISABLED)
    # chimney
    def checkchm():
        if checked30.get():
            c31.config(state=DISABLED)
            c32.config(state=DISABLED)

    def checkchmn():
        if checked31.get():
            c30.config(state=DISABLED)
            c32.config(state=DISABLED)

    def checkchmney():
        if checked32.get():
            c30.config(state=DISABLED)
            c31.config(state=DISABLED)
    # side walk
    def checksw():
        if checked33.get():
            c34.config(state=DISABLED)
            c35.config(state=DISABLED)

    def checksw1():
        if checked34.get():
            c33.config(state=DISABLED)
            c35.config(state=DISABLED)

    def checksw2():
        if checked35.get():
            c33.config(state=DISABLED)
            c34.config(state=DISABLED)
    # house decor
    def checkdec():
        if checked36.get():
            c37.config(state=DISABLED)
            c38.config(state=DISABLED)

    def checkdec1():
        if checked37.get():
            c36.config(state=DISABLED)
            c38.config(state=DISABLED)

    def checkdec2():
        if checked38.get():
            c36.config(state=DISABLED)
            c37.config(state=DISABLED)
    #TREE fUNCTIONS
    #trunk
    def tcheck():
        if checked16.get():
            c17.config(state=DISABLED)
            c18.config(state=DISABLED)

    def tcheckk():
        if checked17.get():
            c16.config(state=DISABLED)
            c18.config(state=DISABLED)

    def tcheckkk():
        if checked18.get():
            c16.config(state=DISABLED)
            c17.config(state=DISABLED)
            # branches

    def bcheck():
            if checked19.get():
                c20.config(state=DISABLED)
                c21.config(state=DISABLED)
            c28.config(state=DISABLED)
    def bcheckk():
            if checked20.get():
                c19.config(state=DISABLED)
                c21.config(state=DISABLED)
            c28.config(state=DISABLED)
    def bcheckkk():
            if checked21.get():
                c19.config(state=DISABLED)
                c20.config(state=DISABLED)
                c28.config(state=DISABLED)
    def bcheckkkk():
            if checked28.get():
                c19.config(state=DISABLED)
                c20.config(state=DISABLED)
                c21.config(state=DISABLED)
                # leaves

    def lcheck():
                if checked22.get():
                    c23.config(state=DISABLED)
                    c24.config(state=DISABLED)

    def lcheckk():
                if checked23.get():
                    c22.config(state=DISABLED)
                    c24.config(state=DISABLED)

    def lcheckkk():
                if checked24.get():
                    c23.config(state=DISABLED)
                    c22.config(state=DISABLED)
                    # root

    def rcheck():
                    if checked25.get():
                        c26.config(state=DISABLED)
                        c27.config(state=DISABLED)
                        c29.config(state=DISABLED)

    def rcheckk():
                    if checked26.get():
                        c25.config(state=DISABLED)
                        c27.config(state=DISABLED)
                        c29.config(state=DISABLED)

    def rcheckkk():
                    if checked27.get():
                        c25.config(state=DISABLED)
                        c26.config(state=DISABLED)
                        c29.config(state=DISABLED)

    def rcheckkkk():
                    if checked29.get():
                        c25.config(state=DISABLED)
                        c26.config(state=DISABLED)
                        c27.config(state=DISABLED)
      # function of person
    #head
    def hcheck():
        if checked41.get():
            c42.config(state=DISABLED)
            c43.config(state=DISABLED)

    def hcheckk():
            if checked42.get():
             c43.config(state=DISABLED)
            c41.config(state=DISABLED)

    def hcheckkk():
            if checked43.get():
             c42.config(state=DISABLED)
             c41.config(state=DISABLED)

#hair
    def hacheck():
                    if checked44.get():
                        c45.config(state=DISABLED)
                        c46.config(state=DISABLED)

    def hacheckk():
                        if checked45.get():
                            c44.config(state=DISABLED)
                            c46.config(state=DISABLED)

    def hacheckkk():
                        if checked46.get():
                            c44.config(state=DISABLED)
                            c45.config(state=DISABLED)

#eyes

    def echeck():
                     if checked47.get():
                        c48.config(state=DISABLED)
                        c49.config(state=DISABLED)


    def echeckk():
                    if checked48.get():
                        c49.config(state=DISABLED)
                        c47.config(state=DISABLED)


    def echeckkk():
                     if checked49.get():
                         c47.config(state=DISABLED)
                         c48.config(state=DISABLED)

         # mouth
    def mcheck():
                 if checked50.get():
                         c51.config(state=DISABLED)
                         c52.config(state=DISABLED)


    def mcheckk():
        if checked51.get():
            c52.config(state=DISABLED)
            c50.config(state=DISABLED)

    def mcheckkk():
        if checked52.get():
            c51.config(state=DISABLED)
            c50.config(state=DISABLED)

                        # nose
    def ncheck():
                if checked53.get():
                        c54.config(state=DISABLED)
                        c55.config(state=DISABLED)


    def ncheckk():
        if checked54.get():
            c55.config(state=DISABLED)
            c53.config(state=DISABLED)


                        # hands
    def hancheck():
                 if checked56.get():
                        c57.config(state=DISABLED)
                        c58.config(state=DISABLED)
                        c55.config(state=DISABLED)

    def hancheckk():
        if checked57.get():
            c56.config(state=DISABLED)
            c58.config(state=DISABLED)
            c55.config(state=DISABLED)
    def hancheckkk():
        if checked58.get():
            c56.config(state=DISABLED)
            c57.config(state=DISABLED)
            c55.config(state=DISABLED)

    def hancheckkkk():
        if checked55.get():
            c58.config(state=DISABLED)
            c56.config(state=DISABLED)
            c57.config(state=DISABLED)
                        # neck
    def necheck():
                if checked59.get():
                        c60.config(state=DISABLED)
                        c61.config(state=DISABLED)


    def necheckk():
        if checked60.get():
            c59.config(state=DISABLED)
            c61.config(state=DISABLED)

    def necheckkk():
        if checked61.get():
            c59.config(state=DISABLED)
            c60.config(state=DISABLED)

                        # arms
    def archeck():
                if checked62.get():
                        c63.config(state=DISABLED)
                        c64.config(state=DISABLED)


    def archeckk():
        if checked63.get():
            c62.config(state=DISABLED)
            c64.config(state=DISABLED)

    def archeckkk():
        if checked64.get():
            c63.config(state=DISABLED)
            c62.config(state=DISABLED)

                        # legs
    def lecheck():
                if checked65.get():
                        c66.config(state=DISABLED)
                        c67.config(state=DISABLED)


    def lecheckk():
        if checked66.get():
            c65.config(state=DISABLED)
            c67.config(state=DISABLED)

    def lecheckkk():
        if checked67.get():
            c65.config(state=DISABLED)
            c66.config(state=DISABLED)

                        # feet

    def fecheck():
        if checked68.get():
            c69.config(state=DISABLED)
            c70.config(state=DISABLED)


    def fecheckk():
        if checked69.get():
            c68.config(state=DISABLED)
            c70.config(state=DISABLED)

    def fecheckkk():
        if checked70.get():
            c68.config(state=DISABLED)
            c69.config(state=DISABLED)


    #House checkButtons
    # roof chkbuttons

    c1 = Checkbutton(toplevel, text='large roof', variable=checked1, command=check)
    c2 = Checkbutton(toplevel, text='Absence of roof', variable=checked2, command=checkk)
    c3 = Checkbutton(toplevel, text=' incomplete, tiny, or burning roofs ', variable=checked3,command=checkkk)
    # roof chkbuttons1
    c4 = Checkbutton(toplevel, text='windows are drawn on the roof', variable=checked4, command=check1)
    c5 = Checkbutton(toplevel, text='roof with massive lines ', variable=checked5, command=check2)
    c6 = Checkbutton(toplevel, text='roof with hollow line ', variable=checked6, command=check3)
    # wall chkbuttons
    c7 = Checkbutton(toplevel, text='Straight Walls ', variable=checked7, command=checkwall)
    c8 = Checkbutton(toplevel, text='Crumbling walls ', variable=checked8, command=checkwal)
    # door chkbuttons
    c9 = Checkbutton(toplevel, text='Open door', variable=checked9, command=checkdoor)
    c10 = Checkbutton(toplevel, text='Close door or curtains ,bars on the door ', variable=checked10, command=checkdoor1)
    c11 = Checkbutton(toplevel, text='very large door ', variable=checked11, command=checkdoor2)
    # window chkbuttons
    c12 = Checkbutton(toplevel, text='windows are open and large', variable=checked12, command=checkwind)
    c13 = Checkbutton(toplevel, text='windows are closed', variable=checked13, command=checkwindo)
    c14 = Checkbutton(toplevel, text='no window', variable=checked14, command=checkwindow)
    # chimney chkbuttons
    c30 = Checkbutton(toplevel, text='chimney in the house ', variable=checked30, command=checkchm)
    c31 = Checkbutton(toplevel, text='chimney with smoke', variable=checked31, command=checkchmn)
    c32= Checkbutton(toplevel, text='no chimney', variable=checked32, command=checkchmney)
    # side walk chkbuttons
    c33 = Checkbutton(toplevel, text=' large side walk ', variable=checked33, command=checksw)
    c34 = Checkbutton(toplevel, text='winding side walk ', variable=checked34, command=checksw1)
    c35 = Checkbutton(toplevel, text='cars on side wallk', variable=checked35, command=checksw2)
    # house decor chkbuttons
    c36 = Checkbutton(toplevel, text='decorate with light', variable=checked36, command=checkdec)
    c37 = Checkbutton(toplevel, text='decorate with ground and tress', variable=checked37, command=checkdec1)
    c38 = Checkbutton(toplevel, text='vantilators in rooms', variable=checked38, command=checkdec2)
    # tree checkButtons
    # trunk chkbuttons
    c16 = Checkbutton(toplevel, text='small trunk ', variable=checked16, command=tcheck)
    c17 = Checkbutton(toplevel, text='tree split down the middle, as if hit by lightening', variable=checked17, command=tcheckk)
    c18 = Checkbutton(toplevel, text='Large Trunk ', variable=checked18, command=tcheckkk)
    # branches chkbuttons
    c19 = Checkbutton(toplevel, text='detached or small branches ', variable=checked19, command=bcheck)
    c20 = Checkbutton(toplevel, text='big branches ', variable=checked20, command=bcheckk)
    c21 = Checkbutton(toplevel, text='pointy branches ', variable=checked21, command=bcheckkk)
    c28 = Checkbutton(toplevel, text='dead branches ', variable=checked28, command=bcheckkkk)
    # leaves chkbuttons
    c22 = Checkbutton(toplevel, text='drawing leaves ', variable=checked22, command=lcheck)
    c23 = Checkbutton(toplevel, text='no leaves ', variable=checked23, command=lcheckk)
    c24 = Checkbutton(toplevel, text=' detached leaves  ', variable=checked24, command=lcheckkk)
    # root chkbuttons
    c25 = Checkbutton(toplevel, text='normal roots ', variable=checked25, command=rcheck)
    c26 = Checkbutton(toplevel, text='lack of roots ', variable=checked26, command=rcheckk)
    c27 = Checkbutton(toplevel, text=' exaggerated roots  ', variable=checked27, command=rcheckkk)
    c29 = Checkbutton(toplevel, text=' dead roots ', variable=checked29, command=rcheckkkk)
     # person chkbuttons
     #head
    c41 = Checkbutton(toplevel, text='oversized heads ', variable=checked41, command=hcheck)
    c42 = Checkbutton(toplevel, text='small head  ', variable=checked42, command=hcheckk)
    c43 = Checkbutton(toplevel, text=' large Head  ', variable=checked43, command=hcheckkk)
    #person size
    c44 = Checkbutton(toplevel, text='A smaller person', variable=checked44, command=hacheck)
    c45 = Checkbutton(toplevel, text='An average size person', variable=checked45, command=hacheckk)
    c46 = Checkbutton(toplevel, text=' A  larger person   ', variable=checked46, command=hacheckkk)
    #eyes
    c47 = Checkbutton(toplevel, text='small eyes  ', variable=checked47, command=echeck)
    c48 = Checkbutton(toplevel, text='Unusually large or strongly reinforced eyes ', variable=checked48, command=echeckk)
    c49 = Checkbutton(toplevel, text=' Unusually small or closed eyes ', variable=checked49, command=echeckkk)
    #mouth
    c50 = Checkbutton(toplevel, text=' big or open  ', variable=checked50, command=mcheck)
    c51 = Checkbutton(toplevel, text='frowning mouth or having the corners down  ', variable=checked51, command=mcheckk)
    c52 = Checkbutton(toplevel, text='drawn with the corners up ', variable=checked52, command=mcheckkk)
    #nose
    c53 = Checkbutton(toplevel, text='Nose drawn as a button or a triangle.', variable=checked53, command=ncheck)
    c54 = Checkbutton(toplevel, text='Sharply-pointed', variable=checked54, command=ncheckk)

    #hands
    c56 = Checkbutton(toplevel, text='Large hands  ', variable=checked56, command=hancheck)
    c57 = Checkbutton(toplevel, text='Tiny hand  ', variable=checked57, command=hancheckk)
    c58 = Checkbutton(toplevel, text='hands are missing  ', variable=checked58, command=hancheckkk)
    c55 = Checkbutton(toplevel, text='Fingers drawn like claws or anyway pointed', variable=checked55, command=hancheckkkk)
    #neck
    c59 = Checkbutton(toplevel, text='no neck  ', variable=checked59, command=necheck)
    c60 = Checkbutton(toplevel, text='long neck ', variable=checked60, command=necheckk)
    c61 = Checkbutton(toplevel, text='neck (collar, tie, necklace) ', variable=checked61, command=necheckkk)
    #arms
    c62 = Checkbutton(toplevel, text='Overly long arms  ', variable=checked62, command=archeck)
    c63 = Checkbutton(toplevel, text='Very short arms  ', variable=checked63, command=archeckk)
    c64 = Checkbutton(toplevel, text=' •	Broad arms  ', variable=checked64, command=archeckkk)
    #legs
    c65 = Checkbutton(toplevel, text='thick and long legs ', variable=checked65, command=lecheck)
    c66 = Checkbutton(toplevel, text=' short, fragile legs  ', variable=checked66, command=lecheckk)
    c67 = Checkbutton(toplevel, text=' thin legs  ', variable=checked67, command=lecheckkk)
    #feet
    c68 = Checkbutton(toplevel, text=' big foot', variable=checked68, command=fecheck)
    c69 = Checkbutton(toplevel, text='small foot ', variable=checked69, command=fecheckk)
    c70 = Checkbutton(toplevel, text=' tiptoes  ', variable=checked70, command=fecheckkk)

#images on labels
    #house
    #roof
    img1 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/largeroof.png")
    img1Btn = Button(toplevel, image=img1)
    img1Btn.image = img1
    img2 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/noroof.png")
    img2Btn = Button(toplevel, image=img2)
    img2Btn.image = img2
    img3 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/incompleteroof.png")
    img3Btn = Button(toplevel, image=img3)
    img3Btn.image = img3
    img4 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/windowonroof.png")
    img4Btn = Button(toplevel, image=img4)
    img4Btn.image = img4
    img5 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/massiveline.png")
    img5Btn = Button(toplevel, image=img5)
    img5Btn.image = img5
    img6 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/hollowline.png")
    img6Btn = Button(toplevel, image=img6)
    img6Btn.image = img6
    #walls
    img7 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/straightwall.png")
    img7Btn = Button(toplevel, image=img7)
    img7Btn.image = img7
    img8= PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/crumblingwall.png")
    img8Btn = Button(toplevel, image=img8)
    img8Btn.image = img8
    #door
    img9 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/opendoor.png")
    img9Btn = Button(toplevel, image=img9)
    img9Btn.image = img9
    img10 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/closeddoorr.png")
    img10Btn = Button(toplevel, image=img10)
    img10Btn.image = img10
    img11 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/largedoor.png")
    img11Btn = Button(toplevel, image=img11)
    img11Btn.image = img11
    #window
    img12 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/openwindw.png")
    img12Btn = Button(toplevel, image=img12)
    img12Btn.image = img12
    img13 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/closedwindow.png")
    img13Btn = Button(toplevel, image=img13)
    img13Btn.image = img13
    img14 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/nowindow.png")
    img14Btn = Button(toplevel, image=img14)
    img14Btn.image = img14
    #chimney
    img15 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/chimney.png")
    img15Btn = Button(toplevel, image=img15)
    img15Btn.image = img15
    img16 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/chimneysmoke.png")
    img16Btn = Button(toplevel, image=img16)
    img16Btn.image = img16
    img17 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/nochimney.png")
    img17Btn = Button(toplevel, image=img17)
    img17Btn.image = img17

    #sidewalk
    img18 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/largesidewalk.png")
    img18Btn = Button(toplevel, image=img18)
    img18Btn.image = img18
    img19 = PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/windingsidewalk.png")
    img19Btn = Button(toplevel, image=img19)
    img19Btn.image = img19
    img20= PhotoImage(file="E:/Python Projects/Project/images/pngimg/House/caronsidewalk.png")
    img20Btn = Button(toplevel, image=img20)
    img20Btn.image = img20


    #HOUSE QUETIONS
    l1 = Label(toplevel, text="Choose which you Draw:")
    l1.grid(row=0, sticky=W)

    # roof questions (q:1)
    l2 = Label(toplevel, text='ROOF .....')
    l2.grid(row=1, column=0, sticky=W)
    l3 = Label(toplevel, text='Roof decoration')
    l3.grid(row=2, column=0, sticky=W)
    img1Btn.grid(row=3, column=0, sticky=W)
    img2Btn.grid(row=3, column=1, sticky=W)
    img3Btn.grid(row=3, column=2, sticky=W)

    c1.grid(row=4, column=0, sticky=W)
    c2.grid(row=4, column=1, sticky=W)
    c3.grid(row=4, column=2, sticky=W)


   #roof walls
    img4Btn.grid(row=6, column=0, sticky=W)
    img5Btn.grid(row=6, column=1, sticky=W)
    img6Btn.grid(row=6, column=2, sticky=W)
    c4.grid(row=7, column=0, sticky=W)
    c5.grid(row=7, column=1, sticky=W)
    c6.grid(row=7, column=2, sticky=W)

    # q:2
    # wall questions
    l4 = Label(toplevel, text='Walls')
    l4.grid(row=8, column=0, sticky=W)
    img7Btn.grid(row=9, column=0, sticky=W)
    img8Btn.grid(row=9, column=1, sticky=W)

    c7.grid(row=10, column=0, sticky=W)
    c8.grid(row=10, column=1, sticky=W)
    # door questions
    l5 = Label(toplevel, text='Door....')
    l5.grid(row=11, column=0, sticky=W)
    img9Btn.grid(row=12, column=0, sticky=W)
    img10Btn.grid(row=12, column=1, sticky=W)
    img11Btn.grid(row=12, column=2, sticky=W)
    c9.grid(row=13, column=0, sticky=W)
    c10.grid(row=13, column=1, sticky=W)
    c11.grid(row=13, column=2, sticky=W)

    l6 = Label(toplevel, text='Window....')
    l6.grid(row=14, column=0, sticky=W)
    img12Btn.grid(row=15, column=0, sticky=W)
    img13Btn.grid(row=15, column=1, sticky=W)
    img14Btn.grid(row=15, column=2, sticky=W)
    c12.grid(row=16, column=0, sticky=W)
    c13.grid(row=16, column=1, sticky=W)
    c14.grid(row=16, column=2, sticky=W)

    # chimney questions
    l7 = Label(toplevel, text='CHIMNEY...')

    l7.grid(row=17, column=0, sticky=W)
    img15Btn.grid(row=18, column=0, sticky=W)
    img16Btn.grid(row=18, column=1, sticky=W)
    img17Btn.grid(row=18, column=2, sticky=W)
    c30.grid(row=19, column=0, sticky=W)
    c31.grid(row=19, column=1, sticky=W)
    c32.grid(row=19, column=2, sticky=W)


    #l2 = Label(toplevel, text="Your sex:")
    #l2.grid(row=5, sticky=W)
    # result show in label
    labres = Label(toplevel, wraplength=300, justify=LEFT)
    labres.grid(row=70, column=0)

    #c1 = Checkbutton(toplevel, text="male", variable=checked1, )
    #c1.grid(row=1, sticky=W)
    #c2 = Checkbutton(toplevel, text="female", variable=checked2)
    #c2.grid(row=2, sticky=W)
    Button(toplevel, text='Quit', command=quit).grid(row=72, sticky=W, pady=4)

    def callback():
        value = c1_value * checked1.get() + c2_value * checked2.get()+ c3_value * checked3.get()+c4_value * checked4.get() + c5_value * checked5.get()+ c6_value * checked6.get()+c7_value * checked7.get() + c8_value * checked8.get()+ c9_value * checked9.get()+c10_value * checked10.get() +c11_value * checked11.get()+ c12_value * checked12.get()+c13_value * checked13.get() +c14_value * checked14.get()+c16_value * checked16.get()+c17_value * checked17.get()+c18_value * checked18.get()+c19_value * checked19.get()+c20_value * checked20.get()+c20_value * checked20.get()+c21_value * checked22.get()+c28_value * checked28.get()+c23_value * checked23.get()+c24_value * checked24.get()+c25_value * checked25.get()+c26_value * checked26.get()+c27_value * checked27.get()+c29_value * checked29.get()+c30_value * checked30.get()+c31_value * checked31.get()+c32_value * checked32.get()+c33_value * checked33.get()+c34_value * checked34.get()+c35_value * checked35.get()+c36_value * checked36.get()+c37_value * checked37.get()+c38_value * checked38.get()+c41_value * checked41.get()+c42_value * checked42.get()+c43_value * checked43.get()+c44_value * checked44.get()+c45_value * checked45.get()+c46_value * checked47.get()+c48_value * checked48.get()+c49_value * checked49.get()+c50_value * checked50.get()+c51_value * checked51.get()+c52_value * checked52.get()+c53_value * checked53.get()+c54_value * checked54.get()+c55_value * checked55.get()+c56_value * checked56.get()+c57_value * checked57.get()+c58_value * checked58.get()+c59_value * checked59.get()+c60_value * checked60.get()+c61_value * checked61.get()+c62_value * checked62.get()+c63_value * checked63.get()+c64_value * checked64.get()+c65_value * checked65.get()+c66_value * checked66.get()+c67_value * checked67.get()+c68_value * checked68.get()+c69_value * checked69.get()+c70_value * checked70.get()
        labres.config(text=str(value))

    Button(toplevel, text='Show', command=callback).grid(row=73, sticky=W, pady=4)
    toplevel.focus_set()
    toplevel.grab_set()


class Paint(object):
    DEFAULT_PEN_SIZE = 5.0
    DEFAULT_COLOR = 'black'

    def __init__(self):
        self.root = Tk()

        self.pen_button = Button(self.root, text='pen', command=self.use_pen)
        self.pen_button.grid(row=0, column=0)

        self.brush_button = Button(self.root, text='brush', command=self.use_brush)
        self.brush_button.grid(row=0, column=1)

        self.color_button = Button(self.root, text='color', command=self.choose_color)
        self.color_button.grid(row=0, column=2)

        self.eraser_button = Button(self.root, text='eraser', command=self.use_eraser)
        self.eraser_button.grid(row=0, column=3)

        self.choose_size_button = Scale(self.root, from_=1, to=10, orient=HORIZONTAL)
        self.choose_size_button.grid(row=0, column=3)



        self.c = Canvas(self.root, bg='white', width=600, height=600)
        self.c.grid(row=1, columnspan=5)
        self.but1 = Button(self.root,text="done" ,command=mhello22)
        self.but1.grid(row=2, columnspan=3)

        self.setup()
        self.root.mainloop()

    def setup(self):
        self.old_x = None
        self.old_y = None
        self.line_width = self.choose_size_button.get()
        self.color = self.DEFAULT_COLOR
        self.eraser_on = False
        self.active_button = self.pen_button
        self.c.bind('<B1-Motion>', self.paint)
        self.c.bind('<ButtonRelease-1>', self.reset)

    def use_pen(self):
        self.activate_button(self.pen_button)

    def use_brush(self):
        self.activate_button(self.brush_button)

    def choose_color(self):
        self.eraser_on = False
        self.color = askcolor(color=self.color)[1]

    def use_eraser(self):
        self.activate_button(self.eraser_button, eraser_mode=True)

    # TODO: reset canvas
    # TODO: undo and redo
    # TODO: draw triangle, rectangle, oval, text

    def activate_button(self, some_button, eraser_mode=False):
        self.active_button.config(relief=RAISED)
        some_button.config(relief=SUNKEN)
        self.active_button = some_button
        self.eraser_on = eraser_mode

    def paint(self, event):
        self.line_width = self.choose_size_button.get()
        paint_color = 'white' if self.eraser_on else self.color
        if self.old_x and self.old_y:
            self.c.create_line(self.old_x, self.old_y, event.x, event.y,
                               width=self.line_width, fill=paint_color,
                               capstyle=ROUND, smooth=TRUE, splinesteps=36)
        self.old_x = event.x
        self.old_y = event.y

    def reset(self, event):
        self.old_x, self.old_y = None, None


if __name__ == '__main__':
    ge = Paint()