﻿
Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Public Class Frmterm2

    Dim con As New SqlClient.SqlConnection
    Dim cmd As New SqlClient.SqlCommand


    Dim dt2 As New DataTable
    Dim dt As New DataTable
    Dim ds As New DataSet
    Dim dsView As New DataView
    Dim bs As New BindingSource
    Dim ad As Boolean
    Dim delt As Boolean
    Dim edt As Boolean
    Dim fillinfo As Boolean
    Dim ob As String
    Dim ful As String
    Dim per As String


    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As SqlConnection = New SqlConnection

    Dim da As SqlDataAdapter
    Dim tables As DataTableCollection = ds.Tables
    Dim source1 As New BindingSource()
    Private Sub dbaccessconnection()
        'Acces DataBase Connectivity and for MS Access 2003 PROVIDER=Microsoft.Jet.OLEDB.4.0
        Try
            con.ConnectionString = "Data Source=RANAALI\SQLEXPRESS;Initial Catalog=school;Integrated Security=True"
            cmd.Connection = con

        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try
    End Sub
    Private Sub fillgrid()

        Try
            con.Open()
            dt.Clear()
            Dim dasql As New SqlDataAdapter("select * from term2 order by sname  ", con)
            dasql.Fill(dt)
            Me.DataGridView1.DataSource = dt
            Me.DataGridView1.Refresh()
            con.Close()
        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try

    End Sub
    Public Sub addrecord()
        con.Open()
        cmd.CommandText = "insert into term2(cnic,sname,fname,term,class,subject1,subj1marks,subject2,subj2marks,subject3,subj3marks,subject4,subj4marks,subject5,subj5marks,subject6,subj6marks,subject7,subj7marks,obmarks,fulmarks,percentage,grade,photo)values('" & Txtcnic.Text & "','" & Txtnme.Text & "','" & Txtfnme.Text & "','" & Txtterm.Text & "','" & Txtcls.Text & "','" & Txtsubj1.Text & "','" & Val(Txtmark1.Text) & "','" & Txtsubj2.Text & "','" & Val(Txtmark2.Text) & "','" & Txtsubj3.Text & "','" & Val(Txtmark3.Text) & "', '" & Txtsubj4.Text & "', '" & Val(Txtmark4.Text) & "','" & Txtsubj5.Text & _
            "','" & Val(Txtmark5.Text) & "','" & Txtsubj6.Text & "','" & Val(Txtmark6.Text) & "','" & Txtsubj7.Text & "','" & Val(Txtmark7.Text) & "','" & Val(Txtobtained.Text) & "','" & Val(Txtful.Text) & "','" & Txtper.Text & "','" & Txtgrad.Text & "',@d1 )"
        Dim ms As New MemoryStream()
        Dim bmpImage As New Bitmap(PictureBox2.Image)
        bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
        Dim data As Byte() = ms.GetBuffer()
        Dim p As New SqlParameter("@d1", SqlDbType.Image)
        p.Value = data
        cmd.Parameters.Add(p)

        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Private Sub clear()
        Txtcnic.Clear()
        Txtnme.Clear()
        Txtfnme.Clear()
        Txtterm.Text = ""
        Txtcls.Text = ""

        Txtsubj1.Text = ""
        Txtsubj2.Clear()
        Txtsubj3.Clear()
        Txtsubj4.Clear()
        Txtsubj4.Clear()
        Txtsubj5.Clear()
        Txtsubj6.Clear()
        Txtsubj7.Clear()
        Txtmark1.Clear()
        Txtmark2.Clear()
        Txtmark3.Clear()
        Txtmark4.Clear()
        Txtmark5.Clear()
        Txtmark6.Clear()
        Txtmark7.Clear()
        Txtobtained.Clear()
        Txtful.Clear()
        Txtper.Clear()
        Txtgrad.Clear()
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
    End Sub
    Private Sub remove()
        Try
            'Dim str1 As String = "Delete * from reges where [reges.cnic]= '" & DataGridView1.SelectedCells(0).Value.ToString & "'"
            'Dim cmd1 As New SqlCommand(str1, con)

            con.Open()
            cmd.CommandText = "delete from term2 where cnic ='" & Txtcnic.Text & "'"
            cmd.ExecuteNonQuery()

            con.Close()
            fillgrid()
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    'Private Sub fill()





    'End Sub
    Private Sub frmrslt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbaccessconnection()
        
        fillgrid()
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Txtterm.Enabled = False
        Txtcls.Enabled = False

        Txtsubj1.Enabled = False
        Txtsubj2.Enabled = False
        Txtsubj3.Enabled = False
        Txtsubj4.Enabled = False
        Txtsubj5.Enabled = False
        Txtsubj6.Enabled = False
        Txtsubj7.Enabled = False
        Txtmark1.Enabled = False
        Txtmark2.Enabled = False
        Txtmark3.Enabled = False
        Txtmark4.Enabled = False
        Txtmark5.Enabled = False
        Txtmark6.Enabled = False
        Txtmark7.Enabled = False
        Txtobtained.Enabled = False
        Txtful.Enabled = False
        Txtper.Enabled = False
        Txtgrad.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Me.Txtsearch.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString
    End Sub

    Private Sub Txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txtsearch.TextChanged
        con.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        Dim da As New SqlDataAdapter
        ds.Tables.Add(dt)
        da = New SqlDataAdapter("select * from term2 where  sname like '%" & Txtsearch.Text & "%'", con)
        da.Fill(dt)
        DataGridView1.DataSource = dt.DefaultView

        con.Close()
    End Sub

    Private Sub Btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnadd.Click
        ad = True
        edt = False
        delt = False
        dt.Clear()



       
        'fill()

        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True

        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Txtterm.Enabled = True
        Txtcls.Enabled = True

        Txtsubj1.Enabled = True
        Txtsubj2.Enabled = True
        Txtsubj3.Enabled = True
        Txtsubj4.Enabled = True
        Txtsubj5.Enabled = True
        Txtsubj6.Enabled = True
        Txtsubj7.Enabled = True
        Txtmark1.Enabled = True
        Txtmark2.Enabled = True
        Txtmark3.Enabled = True
        Txtmark4.Enabled = True
        Txtmark5.Enabled = True
        Txtmark6.Enabled = True
        Txtmark7.Enabled = True
        Txtobtained.Enabled = True
        Txtful.Enabled = True
        Txtper.Enabled = True
        Txtgrad.Enabled = True
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub Btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btndel.Click
        edt = False
        delt = True
        ad = False
        'fillinfo = False
        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Txtterm.Enabled = True
        Txtcls.Enabled = True

        Txtsubj1.Enabled = True
        Txtsubj2.Enabled = True
        Txtsubj3.Enabled = True
        Txtsubj4.Enabled = True
        Txtsubj5.Enabled = True
        Txtsubj6.Enabled = True
        Txtsubj7.Enabled = True
        Txtmark1.Enabled = True
        Txtmark2.Enabled = True
        Txtmark3.Enabled = True
        Txtmark4.Enabled = True
        Txtmark5.Enabled = True
        Txtmark6.Enabled = True
        Txtmark7.Enabled = True
        Txtobtained.Enabled = True
        Txtful.Enabled = True
        Txtper.Enabled = True
        Txtgrad.Enabled = True
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

    Private Sub Btnedt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnedt.Click
        edt = True
        delt = False
        ad = False
        'fillinfo = False
        Btnadd.Enabled = False
        Btndel.Enabled = False
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        edt = True
        delt = False
        ad = False
        'fillinfo = False
        Btnadd.Enabled = False
        Btndel.Enabled = False
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Txtterm.Enabled = True
        Txtcls.Enabled = True

        Txtsubj1.Enabled = True
        Txtsubj2.Enabled = True
        Txtsubj3.Enabled = True
        Txtsubj4.Enabled = True
        Txtsubj5.Enabled = True
        Txtsubj6.Enabled = True
        Txtsubj7.Enabled = True
        Txtmark1.Enabled = True
        Txtmark2.Enabled = True
        Txtmark3.Enabled = True
        Txtmark4.Enabled = True
        Txtmark5.Enabled = True
        Txtmark6.Enabled = True
        Txtmark7.Enabled = True
        Txtobtained.Enabled = True
        Txtful.Enabled = True
        Txtper.Enabled = True
        Txtgrad.Enabled = True

        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

    Private Sub Btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnsave.Click
        If (ad = "True") Then
            addrecord()
            fillgrid()
            MessageBox.Show("record is add")
        End If
        If (delt = "true") Then
            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to permanently delete " & DataGridView1.SelectedCells(0).Value & "?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
            If dr = Windows.Forms.DialogResult.Cancel Then
                MessageBox.Show("Action aborted!", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information)
                DataGridView1.ClearSelection()
                Exit Sub
            Else
                remove()
                'fillgrid()
            End If
        End If

        If (edt = "true") Then

            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to Update?", "Change Details", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
            If dr = Windows.Forms.DialogResult.OK Then
                If con.State = ConnectionState.Closed Then con.Open()
                Dim st As String = "UPDATE [term2] SET sname  = '" & Txtnme.Text & "', fname = '" & Txtfnme.Text & _
                                    "', term = '" & Txtterm.Text & "',class = '" & Txtcls.Text & "',subject1 = '" & Txtsubj1.Text & "', subj1marks = '" & Val(Txtmark1.Text) & _
                                    "',subject2 = '" & Txtsubj2.Text & "',subj2marks = '" & Val(Txtmark2.Text) & "',subject3 = '" & Txtsubj3.Text & "',subj3marks = '" & Val(Txtmark3.Text) & "',subject4 = '" & Txtsubj4.Text & "',subj4marks = '" & Val(Txtmark4.Text) & "',subject5 = '" & Txtsubj5.Text & "',subj5marks = '" & Val(Txtmark5.Text) & "',subject6 = '" & Txtsubj6.Text & "',subj6marks = '" & Val(Txtmark6.Text) & "',subject7 = '" & Txtsubj7.Text & "',subj7marks = '" & Val(Txtmark7.Text) & "',obmarks = '" & Val(Txtobtained.Text) & "',fulmarks = '" & Val(Txtful.Text) & "',percentage = '" & Txtper.Text & "',grade = '" & Txtgrad.Text & "' WHERE cnic = '" & DataGridView1.SelectedCells(0).Value & "'"
                MessageBox.Show("Process Successful!", "Edit", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Dim cmd As New SqlCommand(st, con)
                cmd.ExecuteNonQuery()
                con.Close()
                fillgrid()

            End If



        End If
        'fillgrid()
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Txtterm.Enabled = False
        Txtcls.Enabled = False

        Txtsubj1.Enabled = False
        Txtsubj2.Enabled = False
        Txtsubj3.Enabled = False
        Txtsubj4.Enabled = False
        Txtsubj5.Enabled = False
        Txtsubj6.Enabled = False
        Txtsubj7.Enabled = False
        Txtmark1.Enabled = False
        Txtmark2.Enabled = False
        Txtmark3.Enabled = False
        Txtmark4.Enabled = False
        Txtmark5.Enabled = False
        Txtmark6.Enabled = False
        Txtmark7.Enabled = False
        Txtobtained.Enabled = False
        Txtful.Enabled = False
        Txtper.Enabled = False
        Txtgrad.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person



        'for clear boxes
        clear()
    End Sub

    Private Sub Btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnclear.Click
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Txtterm.Enabled = False
        Txtcls.Enabled = False

        Txtsubj1.Enabled = False
        Txtsubj2.Enabled = False
        Txtsubj3.Enabled = False
        Txtsubj4.Enabled = False
        Txtsubj5.Enabled = False
        Txtsubj6.Enabled = False
        Txtsubj7.Enabled = False
        Txtmark1.Enabled = False
        Txtmark2.Enabled = False
        Txtmark3.Enabled = False
        Txtmark4.Enabled = False
        Txtmark5.Enabled = False
        Txtmark6.Enabled = False
        Txtmark7.Enabled = False
        Txtobtained.Enabled = False
        Txtful.Enabled = False
        Txtper.Enabled = False
        Txtgrad.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
        clear()
        fillgrid()
    End Sub

    Private Sub Btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexit.Click
        Me.Close()
    End Sub

    Private Sub Btnbrows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnbrows.Click
        Try
            With OpenFileDialog1
                .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
                .FilterIndex = 4
            End With
            'Clear the file name
            OpenFileDialog1.FileName = ""
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                PictureBox2.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub DataGridView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.Click
        Me.Txtcnic.Text = DataGridView1.SelectedCells(0).Value.ToString()
        Me.Txtnme.Text = DataGridView1.SelectedCells(1).Value.ToString()
        Me.Txtfnme.Text = DataGridView1.SelectedCells(2).Value.ToString()
        Me.Txtterm.Text = DataGridView1.SelectedCells(3).Value.ToString()
        Me.Txtcls.Text = DataGridView1.SelectedCells(4).Value.ToString()

        Me.Txtsubj1.Text = DataGridView1.SelectedCells(5).Value.ToString()
        Me.Txtmark1.Text = DataGridView1.SelectedCells(6).Value.ToString()
        Me.Txtsubj2.Text = DataGridView1.SelectedCells(7).Value.ToString()
        Me.Txtmark2.Text = DataGridView1.SelectedCells(8).Value.ToString()
        Me.Txtsubj3.Text = DataGridView1.SelectedCells(9).Value.ToString()
        Me.Txtmark3.Text = DataGridView1.SelectedCells(10).Value.ToString()
        Me.Txtsubj4.Text = DataGridView1.SelectedCells(11).Value.ToString()
        Me.Txtmark4.Text = DataGridView1.SelectedCells(12).Value.ToString()
        Me.Txtsubj5.Text = DataGridView1.SelectedCells(13).Value.ToString()
        Me.Txtmark5.Text = DataGridView1.SelectedCells(14).Value.ToString()
        Me.Txtsubj6.Text = DataGridView1.SelectedCells(15).Value.ToString()
        Me.Txtmark6.Text = DataGridView1.SelectedCells(16).Value.ToString()
        Me.Txtsubj7.Text = DataGridView1.SelectedCells(17).Value.ToString()
        Me.Txtmark7.Text = DataGridView1.SelectedCells(18).Value.ToString()
        Me.Txtobtained.Text = DataGridView1.SelectedCells(19).Value.ToString()
        Me.Txtful.Text = DataGridView1.SelectedCells(20).Value.ToString()
        Me.Txtper.Text = DataGridView1.SelectedCells(21).Value.ToString()
        Me.Txtgrad.Text = DataGridView1.SelectedCells(22).Value.ToString()





        Frmterm3.Txtcnic.Text = DataGridView1.SelectedCells(0).Value.ToString()
        Frmterm3.Txtnme.Text = DataGridView1.SelectedCells(1).Value.ToString()
        Frmterm3.Txtfnme.Text = DataGridView1.SelectedCells(2).Value.ToString()
        Frmterm3.Txtterm.Text = DataGridView1.SelectedCells(3).Value.ToString()
        Frmterm3.Txtcls.Text = DataGridView1.SelectedCells(4).Value.ToString()

        Frmterm3.Txtsubj1.Text = DataGridView1.SelectedCells(5).Value.ToString()

        Frmterm3.Txtsubj2.Text = DataGridView1.SelectedCells(7).Value.ToString()

        Frmterm3.Txtsubj3.Text = DataGridView1.SelectedCells(9).Value.ToString()

        Frmterm3.Txtsubj4.Text = DataGridView1.SelectedCells(11).Value.ToString()

        Frmterm3.Txtsubj5.Text = DataGridView1.SelectedCells(13).Value.ToString()

        Frmterm3.Txtsubj6.Text = DataGridView1.SelectedCells(15).Value.ToString()

        Frmterm3.Txtsubj7.Text = DataGridView1.SelectedCells(17).Value.ToString()

        Frmgrand.Txtterm2.Text = DataGridView1.SelectedCells(19).Value.ToString()



        con.Open()
        cmd = New SqlCommand("SELECT photo FROM term2 WHERE cnic=" & DataGridView1.SelectedCells(0).Value, con)
        Dim ms As New MemoryStream(CType(cmd.ExecuteScalar, Byte()))
        PictureBox2.Image = Image.FromStream(ms)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        cmd.Dispose()
        con.Close()
        
    End Sub
    Private Sub reslt()
        ob = Val(Txtobtained.Text)
        ful = Val(Txtful.Text)
        Txtper.Text = ob / ful * 100
    End Sub
    Private Sub grad()
        If (Txtper.Text >= 90 & Txtper.Text <= 100) Then
            Txtgrad.Text = "Your grade is A"
        ElseIf (Txtper.Text >= 79.5 & Txtper.Text < 90) Then
            Txtgrad.Text = "Your grade is B+"
        ElseIf (Txtper.Text >= 75.5 & Txtper.Text < 79.5) Then
            Txtgrad.Text = "Your grade is B"
        ElseIf (Txtper.Text >= 70.5 & Txtper.Text < 75.5) Then
            Txtgrad.Text = "Your grade is B-"
        ElseIf (Txtper.Text >= 65.5 & Txtper.Text < 70.5) Then
            Txtper.Text = "Your grade is C+"
        ElseIf (Txtper.Text >= 60.5 & Txtper.Text < 65.5) Then
            Txtgrad.Text = "Your grade is C"
        ElseIf (Txtper.Text >= 50.5 & Txtper.Text < 60.5) Then
            Txtgrad.Text = "Your grade is C- "
        ElseIf (Txtper.Text >= 33.0 & Txtper.Text < 50.5) Then

            Txtgrad.Text = "Your grade is D"
        Else
            Txtgrad.Text = "you are failed"
        End If
    End Sub
    Private Sub reslt1()
        Txtobtained.Text = Val(Txtmark1.Text) + Val(Txtmark2.Text) + Val(Txtmark3.Text) + Val(Txtmark3.Text) + Val(Txtmark4.Text) + Val(Txtmark5.Text) + Val(Txtmark6.Text) + Val(Txtmark7.Text)
    End Sub
    Private Sub Txtper_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtper.Click
        reslt()
    End Sub

    Private Sub Txtgrad_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtgrad.Click
        grad()
    End Sub

    Private Sub Txtobtained_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtobtained.Click
        reslt1()
    End Sub




End Class