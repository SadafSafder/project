﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmrslt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Txtfnme = New System.Windows.Forms.TextBox()
        Me.Txtnme = New System.Windows.Forms.TextBox()
        Me.Txtcnic = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Txtmark7 = New System.Windows.Forms.TextBox()
        Me.Txtmark6 = New System.Windows.Forms.TextBox()
        Me.Txtmark5 = New System.Windows.Forms.TextBox()
        Me.Txtmark4 = New System.Windows.Forms.TextBox()
        Me.Txtmark3 = New System.Windows.Forms.TextBox()
        Me.Txtmark2 = New System.Windows.Forms.TextBox()
        Me.Txtmark1 = New System.Windows.Forms.TextBox()
        Me.Txtsubj7 = New System.Windows.Forms.TextBox()
        Me.Txtsubj6 = New System.Windows.Forms.TextBox()
        Me.Txtsubj5 = New System.Windows.Forms.TextBox()
        Me.Txtsubj4 = New System.Windows.Forms.TextBox()
        Me.Txtsubj3 = New System.Windows.Forms.TextBox()
        Me.Txtsubj2 = New System.Windows.Forms.TextBox()
        Me.Txtsubj1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Txtgrad = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txtper = New System.Windows.Forms.TextBox()
        Me.Txtful = New System.Windows.Forms.TextBox()
        Me.Txtobtained = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Txtcls = New System.Windows.Forms.TextBox()
        Me.Txtterm = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btnbrows = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Txtsearch = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnedt = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txtfnme)
        Me.GroupBox1.Controls.Add(Me.Txtnme)
        Me.GroupBox1.Controls.Add(Me.Txtcnic)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 159)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(271, 106)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Txtfnme
        '
        Me.Txtfnme.Location = New System.Drawing.Point(93, 76)
        Me.Txtfnme.Name = "Txtfnme"
        Me.Txtfnme.Size = New System.Drawing.Size(172, 20)
        Me.Txtfnme.TabIndex = 5
        '
        'Txtnme
        '
        Me.Txtnme.Location = New System.Drawing.Point(93, 44)
        Me.Txtnme.Name = "Txtnme"
        Me.Txtnme.Size = New System.Drawing.Size(172, 20)
        Me.Txtnme.TabIndex = 4
        '
        'Txtcnic
        '
        Me.Txtcnic.Location = New System.Drawing.Point(93, 16)
        Me.Txtcnic.Name = "Txtcnic"
        Me.Txtcnic.Size = New System.Drawing.Size(172, 20)
        Me.Txtcnic.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Father Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "cnic"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txtmark7)
        Me.GroupBox2.Controls.Add(Me.Txtmark6)
        Me.GroupBox2.Controls.Add(Me.Txtmark5)
        Me.GroupBox2.Controls.Add(Me.Txtmark4)
        Me.GroupBox2.Controls.Add(Me.Txtmark3)
        Me.GroupBox2.Controls.Add(Me.Txtmark2)
        Me.GroupBox2.Controls.Add(Me.Txtmark1)
        Me.GroupBox2.Controls.Add(Me.Txtsubj7)
        Me.GroupBox2.Controls.Add(Me.Txtsubj6)
        Me.GroupBox2.Controls.Add(Me.Txtsubj5)
        Me.GroupBox2.Controls.Add(Me.Txtsubj4)
        Me.GroupBox2.Controls.Add(Me.Txtsubj3)
        Me.GroupBox2.Controls.Add(Me.Txtsubj2)
        Me.GroupBox2.Controls.Add(Me.Txtsubj1)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(295, 159)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(303, 242)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Txtmark7
        '
        Me.Txtmark7.Location = New System.Drawing.Point(173, 209)
        Me.Txtmark7.Name = "Txtmark7"
        Me.Txtmark7.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark7.TabIndex = 17
        '
        'Txtmark6
        '
        Me.Txtmark6.Location = New System.Drawing.Point(173, 183)
        Me.Txtmark6.Name = "Txtmark6"
        Me.Txtmark6.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark6.TabIndex = 16
        '
        'Txtmark5
        '
        Me.Txtmark5.Location = New System.Drawing.Point(173, 157)
        Me.Txtmark5.Name = "Txtmark5"
        Me.Txtmark5.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark5.TabIndex = 15
        '
        'Txtmark4
        '
        Me.Txtmark4.Location = New System.Drawing.Point(173, 131)
        Me.Txtmark4.Name = "Txtmark4"
        Me.Txtmark4.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark4.TabIndex = 14
        '
        'Txtmark3
        '
        Me.Txtmark3.Location = New System.Drawing.Point(173, 105)
        Me.Txtmark3.Name = "Txtmark3"
        Me.Txtmark3.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark3.TabIndex = 13
        '
        'Txtmark2
        '
        Me.Txtmark2.Location = New System.Drawing.Point(173, 79)
        Me.Txtmark2.Name = "Txtmark2"
        Me.Txtmark2.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark2.TabIndex = 12
        '
        'Txtmark1
        '
        Me.Txtmark1.Location = New System.Drawing.Point(173, 53)
        Me.Txtmark1.Name = "Txtmark1"
        Me.Txtmark1.Size = New System.Drawing.Size(109, 20)
        Me.Txtmark1.TabIndex = 11
        '
        'Txtsubj7
        '
        Me.Txtsubj7.Location = New System.Drawing.Point(9, 209)
        Me.Txtsubj7.Name = "Txtsubj7"
        Me.Txtsubj7.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj7.TabIndex = 10
        '
        'Txtsubj6
        '
        Me.Txtsubj6.Location = New System.Drawing.Point(9, 183)
        Me.Txtsubj6.Name = "Txtsubj6"
        Me.Txtsubj6.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj6.TabIndex = 9
        '
        'Txtsubj5
        '
        Me.Txtsubj5.Location = New System.Drawing.Point(9, 157)
        Me.Txtsubj5.Name = "Txtsubj5"
        Me.Txtsubj5.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj5.TabIndex = 8
        '
        'Txtsubj4
        '
        Me.Txtsubj4.Location = New System.Drawing.Point(9, 131)
        Me.Txtsubj4.Name = "Txtsubj4"
        Me.Txtsubj4.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj4.TabIndex = 7
        '
        'Txtsubj3
        '
        Me.Txtsubj3.Location = New System.Drawing.Point(9, 105)
        Me.Txtsubj3.Name = "Txtsubj3"
        Me.Txtsubj3.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj3.TabIndex = 5
        '
        'Txtsubj2
        '
        Me.Txtsubj2.Location = New System.Drawing.Point(9, 79)
        Me.Txtsubj2.Name = "Txtsubj2"
        Me.Txtsubj2.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj2.TabIndex = 4
        '
        'Txtsubj1
        '
        Me.Txtsubj1.Location = New System.Drawing.Point(9, 53)
        Me.Txtsubj1.Name = "Txtsubj1"
        Me.Txtsubj1.Size = New System.Drawing.Size(109, 20)
        Me.Txtsubj1.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(207, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Marks"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Subjects"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Txtgrad)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Txtper)
        Me.GroupBox3.Controls.Add(Me.Txtful)
        Me.GroupBox3.Controls.Add(Me.Txtobtained)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 271)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(271, 130)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'Txtgrad
        '
        Me.Txtgrad.Location = New System.Drawing.Point(93, 104)
        Me.Txtgrad.Name = "Txtgrad"
        Me.Txtgrad.ReadOnly = True
        Me.Txtgrad.Size = New System.Drawing.Size(172, 20)
        Me.Txtgrad.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 104)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(36, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Grade"
        '
        'Txtper
        '
        Me.Txtper.Location = New System.Drawing.Point(93, 76)
        Me.Txtper.Name = "Txtper"
        Me.Txtper.ReadOnly = True
        Me.Txtper.Size = New System.Drawing.Size(172, 20)
        Me.Txtper.TabIndex = 5
        '
        'Txtful
        '
        Me.Txtful.Location = New System.Drawing.Point(93, 44)
        Me.Txtful.Name = "Txtful"
        Me.Txtful.Size = New System.Drawing.Size(172, 20)
        Me.Txtful.TabIndex = 4
        '
        'Txtobtained
        '
        Me.Txtobtained.Location = New System.Drawing.Point(93, 16)
        Me.Txtobtained.Name = "Txtobtained"
        Me.Txtobtained.ReadOnly = True
        Me.Txtobtained.Size = New System.Drawing.Size(172, 20)
        Me.Txtobtained.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 79)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Percentage"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Full marks"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "obtained marks"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Txtcls)
        Me.GroupBox4.Controls.Add(Me.Txtterm)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Location = New System.Drawing.Point(604, 159)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(182, 92)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        '
        'Txtcls
        '
        Me.Txtcls.Location = New System.Drawing.Point(54, 50)
        Me.Txtcls.Name = "Txtcls"
        Me.Txtcls.Size = New System.Drawing.Size(122, 20)
        Me.Txtcls.TabIndex = 13
        '
        'Txtterm
        '
        Me.Txtterm.Location = New System.Drawing.Point(54, 19)
        Me.Txtterm.Name = "Txtterm"
        Me.Txtterm.Size = New System.Drawing.Size(122, 20)
        Me.Txtterm.TabIndex = 12
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 53)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(32, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Class"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Term"
        '
        'Btnbrows
        '
        Me.Btnbrows.Location = New System.Drawing.Point(736, 271)
        Me.Btnbrows.Name = "Btnbrows"
        Me.Btnbrows.Size = New System.Drawing.Size(50, 96)
        Me.Btnbrows.TabIndex = 8
        Me.Btnbrows.Text = "Add Photo"
        Me.Btnbrows.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Btnexit)
        Me.GroupBox5.Controls.Add(Me.Btnclear)
        Me.GroupBox5.Controls.Add(Me.Btnsave)
        Me.GroupBox5.Controls.Add(Me.Btnedt)
        Me.GroupBox5.Controls.Add(Me.Btndel)
        Me.GroupBox5.Controls.Add(Me.Btnadd)
        Me.GroupBox5.Location = New System.Drawing.Point(286, 407)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(500, 79)
        Me.GroupBox5.TabIndex = 9
        Me.GroupBox5.TabStop = False
        '
        'Txtsearch
        '
        Me.Txtsearch.Location = New System.Drawing.Point(1, 443)
        Me.Txtsearch.Multiline = True
        Me.Txtsearch.Name = "Txtsearch"
        Me.Txtsearch.Size = New System.Drawing.Size(178, 41)
        Me.Txtsearch.TabIndex = 11
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(1, 490)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(794, 87)
        Me.DataGridView1.TabIndex = 14
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label12.Location = New System.Drawing.Point(8, 117)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 24)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Result "
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Btnsearch
        '
        Me.Btnsearch.Image = Global.school_management_system.My.Resources.Resources.images__1_
        Me.Btnsearch.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsearch.Location = New System.Drawing.Point(182, 443)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 41)
        Me.Btnsearch.TabIndex = 12
        Me.Btnsearch.Text = "Search"
        Me.Btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btnsearch.UseVisualStyleBackColor = True
        '
        'Btnexit
        '
        Me.Btnexit.Image = Global.school_management_system.My.Resources.Resources.Log_Out
        Me.Btnexit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnexit.Location = New System.Drawing.Point(409, 9)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(75, 70)
        Me.Btnexit.TabIndex = 14
        Me.Btnexit.Text = "Exit"
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnexit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Image = Global.school_management_system.My.Resources.Resources.delete1
        Me.Btnclear.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnclear.Location = New System.Drawing.Point(328, 9)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 70)
        Me.Btnclear.TabIndex = 13
        Me.Btnclear.Text = "Dispose"
        Me.Btnclear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'Btnsave
        '
        Me.Btnsave.Image = Global.school_management_system.My.Resources.Resources.Save
        Me.Btnsave.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsave.Location = New System.Drawing.Point(244, 9)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(75, 70)
        Me.Btnsave.TabIndex = 3
        Me.Btnsave.Text = "Save"
        Me.Btnsave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnedt
        '
        Me.Btnedt.Image = Global.school_management_system.My.Resources.Resources.download__4_
        Me.Btnedt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnedt.Location = New System.Drawing.Point(168, 7)
        Me.Btnedt.Name = "Btnedt"
        Me.Btnedt.Size = New System.Drawing.Size(75, 70)
        Me.Btnedt.TabIndex = 2
        Me.Btnedt.Text = "Edit"
        Me.Btnedt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnedt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnedt.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Image = Global.school_management_system.My.Resources.Resources.Remove
        Me.Btndel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btndel.Location = New System.Drawing.Point(87, 7)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(75, 70)
        Me.Btndel.TabIndex = 1
        Me.Btndel.Text = "Delete"
        Me.Btndel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btndel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Image = Global.school_management_system.My.Resources.Resources.download__3_
        Me.Btnadd.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnadd.Location = New System.Drawing.Point(6, 9)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(75, 70)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "New"
        Me.Btnadd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Image = Global.school_management_system.My.Resources.Resources.person
        Me.PictureBox2.Location = New System.Drawing.Point(604, 257)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(126, 138)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.school_management_system.My.Resources.Resources.schoolmanagement4
        Me.PictureBox1.Location = New System.Drawing.Point(1, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(801, 151)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'frmrslt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(798, 581)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.Txtsearch)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Btnbrows)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmrslt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmrslt"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtfnme As System.Windows.Forms.TextBox
    Friend WithEvents Txtnme As System.Windows.Forms.TextBox
    Friend WithEvents Txtcnic As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtmark7 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark6 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark5 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark4 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark3 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark2 As System.Windows.Forms.TextBox
    Friend WithEvents Txtmark1 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj7 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj6 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj5 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj4 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj3 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj2 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtgrad As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txtper As System.Windows.Forms.TextBox
    Friend WithEvents Txtful As System.Windows.Forms.TextBox
    Friend WithEvents Txtobtained As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtcls As System.Windows.Forms.TextBox
    Friend WithEvents Txtterm As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Btnbrows As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnedt As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btnclear As System.Windows.Forms.Button
    Friend WithEvents Btnsearch As System.Windows.Forms.Button
    Friend WithEvents Txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
