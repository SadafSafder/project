﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Public Class frmfaclty
    Dim con As New SqlClient.SqlConnection
    Dim cmd As New SqlClient.SqlCommand


    Dim dt2 As New DataTable
    Dim dt As New DataTable
    Dim ds As New DataSet
    Dim dsView As New DataView
    Dim bs As New BindingSource
    Dim ad As Boolean
    Dim delt As Boolean
    Dim edt As Boolean

    Dim fillinfo As Boolean
    Private Sub dbaccessconnection()
        'Acces DataBase Connectivity and for MS Access 2003 PROVIDER=Microsoft.Jet.OLEDB.4.0
        Try
            con.ConnectionString = "Data Source=RANAALI\SQLEXPRESS;Initial Catalog=school;Integrated Security=True"
            cmd.Connection = con

        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try
    End Sub
    Private Sub fillgrid()

        Try
            con.Open()
            dt.Clear()
            Dim dasql As New SqlDataAdapter("select * from fclty order by sname  ", con)
            dasql.Fill(dt)
            Me.DataGridView1.DataSource = dt
            Me.DataGridView1.Refresh()
            con.Close()
        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try

    End Sub
    Public Sub addrecord()
        con.Open()
        cmd.CommandText = "insert into fclty(cnic,sname,fname,gender,clas,dob,subject,cell,address,email,cv,photo)values('" & Txtcnic.Text & "','" & Txtnme.Text & "','" & Txtfnme.Text & "','" & Cmbgender.Text & "','" & Txtcls.Text & "','" & DateTimePicker1.Text & "','" & Txtsubject.Text & "','" & Txtcell.Text & "','" & Txtaddress.Text & "','" & Txtemail.Text & "','" & Txtcv.Text & "',@d1 )"
        Dim ms As New MemoryStream()
        Dim bmpImage As New Bitmap(PictureBox2.Image)
        bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
        Dim data As Byte() = ms.GetBuffer()
        Dim p As New SqlParameter("@d1", SqlDbType.Image)
        p.Value = data
        cmd.Parameters.Add(p)

        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Private Sub clear()
        Txtcnic.Clear()
        Txtnme.Clear()
        Txtfnme.Clear()
        Cmbgender.Text = ""
        Txtcls.Text = ""

        DateTimePicker1.Text = ""
        Txtsubject.Clear()
        Txtcell.Clear()
        Txtaddress.Clear()
        Txtemail.Clear()
        Txtcv.Clear()
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
    End Sub
    Private Sub remove()
        Try
            'Dim str1 As String = "Delete * from reges where [reges.cnic]= '" & DataGridView1.SelectedCells(0).Value.ToString & "'"
            'Dim cmd1 As New SqlCommand(str1, con)

            con.Open()
            cmd.CommandText = "delete from fclty where cnic ='" & Txtcnic.Text & "'"
            cmd.ExecuteNonQuery()

            con.Close()
            fillgrid()
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    Private Sub frmfaclty_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbaccessconnection()
        fillgrid()
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Cmbgender.Enabled = False
        Txtcls.Enabled = False

        DateTimePicker1.Enabled = False
        Txtsubject.Enabled = False
        Txtcell.Enabled = False
        Txtaddress.Enabled = False
        Txtemail.Enabled = False
        Txtcv.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Me.Txtsearch.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString
    End Sub

   

    Private Sub Txtsearch_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txtsearch.TextChanged
        con.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        Dim da As New SqlDataAdapter
        ds.Tables.Add(dt)
        da = New SqlDataAdapter("select * from fclty where  sname like '%" & Txtsearch.Text & "%'", con)
        da.Fill(dt)
        DataGridView1.DataSource = dt.DefaultView

        con.Close()
    End Sub

    Private Sub Btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnadd.Click
        ad = True
        edt = False
        delt = False
        dt.Clear()
        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True

        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Cmbgender.Enabled = True
        Txtcls.Enabled = True

        DateTimePicker1.Enabled = True
        Txtsubject.Enabled = True
        Txtcell.Enabled = True
        Txtaddress.Enabled = True
        Txtemail.Enabled = True
        Txtcv.Enabled = True
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
        clear()
    End Sub

    Private Sub Btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btndel.Click
        edt = False
        delt = True
        ad = False
        'fillinfo = False
        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Cmbgender.Enabled = True
        Txtcls.Enabled = True

        DateTimePicker1.Enabled = True
        Txtsubject.Enabled = True
        Txtcell.Enabled = True
        Txtaddress.Enabled = True
        Txtemail.Enabled = True
        Txtcv.Enabled = True
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

    Private Sub Btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnsave.Click
        If (ad = "True") Then
            addrecord()
            fillgrid()
            MessageBox.Show("record is add")
        End If
        If (delt = "true") Then
            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to permanently delete " & DataGridView1.SelectedCells(0).Value & "?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
            If dr = Windows.Forms.DialogResult.Cancel Then
                MessageBox.Show("Action aborted!", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information)
                DataGridView1.ClearSelection()
                Exit Sub
            Else
                remove()
                'fillgrid()
            End If
        End If

        If (edt = "true") Then

            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to Update?", "Change Details", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
            If dr = Windows.Forms.DialogResult.OK Then
                If con.State = ConnectionState.Closed Then con.Open()
                Dim st As String = "UPDATE [fclty] SET sname  = '" & Txtnme.Text & "', fname = '" & Txtfnme.Text & _
                                    "', gender = '" & Cmbgender.Text & "',clas = '" & Txtcls.Text & "',dob = '" & DateTimePicker1.Text & "', subject = '" & Txtsubject.Text & _
                                    "',cell = '" & Txtcell.Text & "',address = '" & Txtaddress.Text & "',email = '" & Txtemail.Text & "',cv = '" & Txtcv.Text & "' WHERE cnic = '" & DataGridView1.SelectedCells(0).Value & "'"
                MessageBox.Show("Process Successful!", "Edit", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Dim cmd As New SqlCommand(st, con)
                cmd.ExecuteNonQuery()
                con.Close()
                fillgrid()

            End If



        End If
        'fillgrid()
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Cmbgender.Enabled = False
        Txtcls.Enabled = False

        DateTimePicker1.Enabled = False
        Txtsubject.Enabled = False
        Txtcell.Enabled = False
        Txtaddress.Enabled = False
        Txtemail.Enabled = False
        Txtcv.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person


        'for clear boxes
        clear()
    End Sub

    Private Sub Btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnclear.Click
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        Txtcnic.Enabled = False
        Txtnme.Enabled = False
        Txtfnme.Enabled = False
        Cmbgender.Enabled = False
        Txtcls.Enabled = False

        DateTimePicker1.Enabled = False
        Txtsubject.Enabled = False
        Txtcell.Enabled = False
        Txtaddress.Enabled = False
        Txtemail.Enabled = False
        Txtcv.Enabled = False
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
        clear()
        fillgrid()
    End Sub

    Private Sub Btnbrows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnbrows.Click
        Try
            With OpenFileDialog1
                .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
                .FilterIndex = 4
            End With
            'Clear the file name
            OpenFileDialog1.FileName = ""
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                PictureBox2.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub


    Private Sub Btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexit.Click
        Me.Close()
    End Sub

    Private Sub Btnedt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnedt.Click
        edt = True
        delt = False
        ad = False
        'fillinfo = False
        Btnadd.Enabled = False
        Btndel.Enabled = False
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = True
        Txtnme.Enabled = True
        Txtfnme.Enabled = True
        Cmbgender.Enabled = True
        Txtcls.Enabled = True

        DateTimePicker1.Enabled = True
        Txtsubject.Enabled = True
        Txtcell.Enabled = True
        Txtaddress.Enabled = True
        Txtemail.Enabled = True
        Txtcv.Enabled = True
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

   
    Private Sub DataGridView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.Click
        Txtcnic.Text = DataGridView1.SelectedCells(0).Value.ToString()
        Txtnme.Text = DataGridView1.SelectedCells(1).Value.ToString()
        Txtfnme.Text = DataGridView1.SelectedCells(2).Value.ToString()
        Cmbgender.Text = DataGridView1.SelectedCells(3).Value.ToString()
        Txtcls.Text = DataGridView1.SelectedCells(4).Value.ToString()

        DateTimePicker1.Text = DataGridView1.SelectedCells(5).Value.ToString()
        Txtsubject.Text = DataGridView1.SelectedCells(6).Value.ToString()
        Txtcell.Text = DataGridView1.SelectedCells(7).Value.ToString()
        Txtaddress.Text = DataGridView1.SelectedCells(8).Value.ToString()
        Txtemail.Text = DataGridView1.SelectedCells(9).Value.ToString()
        Txtcv.Text = DataGridView1.SelectedCells(10).Value.ToString()
        con.Open()
        cmd = New SqlCommand("SELECT photo FROM fclty WHERE cnic=" & DataGridView1.SelectedCells(0).Value, con)
        Dim ms As New MemoryStream(CType(cmd.ExecuteScalar, Byte()))
        PictureBox2.Image = Image.FromStream(ms)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        cmd.Dispose()
        con.Close()
    End Sub
End Class