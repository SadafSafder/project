﻿
Public Class Frmdict

    Private Sub Frmdict_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListBox1.Items.Add("abase")
        ListBox1.Items.Add("abhorrent")
        ListBox1.Items.Add("abnegate")
        ListBox1.Items.Add("aback")
        ListBox1.Items.Add("abacus")
        ListBox1.Items.Add("abomination")
        ListBox1.Items.Add("acetate")
        ListBox1.Items.Add("achromatic")
        ListBox1.Items.Add("acme")
        ListBox1.Items.Add("acquaint")
        ListBox1.Items.Add("admissible")
        ListBox1.Items.Add("admonition")
        ListBox1.Items.Add("adoration")
        ListBox1.Items.Add("abasement")
        ListBox1.Items.Add("abash")
        ListBox1.Items.Add("advent")
        ListBox1.Items.Add("advert")
        ListBox1.Items.Add("aerial")
        ListBox1.Items.Add("alchemy")
        ListBox1.Sorted = True

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim Item As String = TextBox1.Text.ToString()
        Dim index As Integer = ListBox1.FindString(Item)
        If index = -1 Then
            ListBox1.SelectedIndex = ListBox1.SelectedIndex
        Else
            ListBox1.SetSelected(index, True)
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "abacus" Then
            TextBox2.Text = "A manual computing device consisting of a frame holding parallel rods strung with movable counters."
        ElseIf TextBox1.Text = "abash" Then
            TextBox2.Text = "To make ashamed or uneasy; disconcert."
        ElseIf TextBox1.Text = "abase" Then
            TextBox2.Text = "To lower in position, estimation, or the like; degrade.."
        ElseIf TextBox1.Text = "abhorrent" Then
            TextBox2.Text = "Very repugnant; hateful."
        ElseIf TextBox1.Text = "abnegate" Then
            TextBox2.Text = "To renounce (a right or privilege).."

        ElseIf TextBox1.Text = "abomination" Then
            TextBox2.Text = "A very detestable act or practice.."
        ElseIf TextBox1.Text = "acetate" Then
            TextBox2.Text = "A salt of acetic acid.."
        ElseIf TextBox1.Text = "achromatic" Then
            TextBox2.Text = "Colorless,."
        ElseIf TextBox1.Text = "acme" Then
            TextBox2.Text = "The highest point, or summit.."
        ElseIf TextBox1.Text = "acquaint" Then
            TextBox2.Text = "To make familiar or conversant.."
        ElseIf TextBox1.Text = "admissible" Then
            TextBox2.Text = "Having the right or privilege of entry.."
        ElseIf TextBox1.Text = "admonition" Then
            TextBox2.Text = "Gentle reproof.."
        ElseIf TextBox1.Text = "adoration" Then
            TextBox2.Text = "Profound devotion.."
        ElseIf TextBox1.Text = "advent" Then
            TextBox2.Text = "The coming or arrival, as of any important change, event, state, or personage.."
        ElseIf TextBox1.Text = "advert" Then
            TextBox2.Text = "To refer incidentally.."
        ElseIf TextBox1.Text = "aerial" Then
            TextBox2.Text = "Of, pertaining to, or like the air.."
        ElseIf TextBox1.Text = "alchemy" Then
            TextBox2.Text = "Chemistry of the middle ages, characterized by the pursuit of changing base metals to gold.."
       

        Else
            'A message box will show up if the entered word is not found
            MsgBox("No mathcing results where found")

        End If

    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        TextBox1.Text = ListBox1.SelectedItem
        Button1.PerformClick()

    End Sub

   
    
End Class