﻿Public Class Frmcalender

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub MonthCalendar1_DateChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateChanged
        Me.Label1.Text = CStr(Me.MonthCalendar1.SelectionRange.Start)
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnquit.Click
        If MsgBox("Are you sure you want to Quit?", vbYesNo) = vbYes Then
            Me.Close()

        Else
            Exit Sub
        End If
    End Sub
End Class