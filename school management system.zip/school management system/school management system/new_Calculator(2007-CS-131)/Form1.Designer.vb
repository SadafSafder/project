﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.displayText = New System.Windows.Forms.TextBox
        Me.btn1 = New System.Windows.Forms.Button
        Me.btn2 = New System.Windows.Forms.Button
        Me.btn3 = New System.Windows.Forms.Button
        Me.btn4 = New System.Windows.Forms.Button
        Me.btn5 = New System.Windows.Forms.Button
        Me.btn6 = New System.Windows.Forms.Button
        Me.btn7 = New System.Windows.Forms.Button
        Me.btn8 = New System.Windows.Forms.Button
        Me.btn9 = New System.Windows.Forms.Button
        Me.btn0 = New System.Windows.Forms.Button
        Me.btnAdd = New System.Windows.Forms.Button
        Me.btnSub = New System.Windows.Forms.Button
        Me.btnMult = New System.Windows.Forms.Button
        Me.btnDiv = New System.Windows.Forms.Button
        Me.btnEqual = New System.Windows.Forms.Button
        Me.btnDecimal = New System.Windows.Forms.Button
        Me.btnSign = New System.Windows.Forms.Button
        Me.btnClearAll = New System.Windows.Forms.Button
        Me.btnBackSpace = New System.Windows.Forms.Button
        Me.btnMenu = New System.Windows.Forms.Button
        Me.btnTime = New System.Windows.Forms.Button
        Me.lblTime = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btnClose = New System.Windows.Forms.Button
        Me.btnColour = New System.Windows.Forms.Button
        Me.btna = New System.Windows.Forms.Button
        Me.btnb = New System.Windows.Forms.Button
        Me.btnc = New System.Windows.Forms.Button
        Me.gbMain1 = New System.Windows.Forms.GroupBox
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.btnDate = New System.Windows.Forms.Button
        Me.btnInverse = New System.Windows.Forms.Button
        Me.btnModulus = New System.Windows.Forms.Button
        Me.btnPower = New System.Windows.Forms.Button
        Me.btnPI = New System.Windows.Forms.Button
        Me.btnTanh = New System.Windows.Forms.Button
        Me.btnCosh = New System.Windows.Forms.Button
        Me.btnSinh = New System.Windows.Forms.Button
        Me.btnlog = New System.Windows.Forms.Button
        Me.btnln = New System.Windows.Forms.Button
        Me.btne = New System.Windows.Forms.Button
        Me.btnex = New System.Windows.Forms.Button
        Me.btnsqrt = New System.Windows.Forms.Button
        Me.btnRound = New System.Windows.Forms.Button
        Me.btnCeil = New System.Windows.Forms.Button
        Me.btnFloor = New System.Windows.Forms.Button
        Me.btnFact = New System.Windows.Forms.Button
        Me.btnPerm = New System.Windows.Forms.Button
        Me.btnComb = New System.Windows.Forms.Button
        Me.btnTruncate = New System.Windows.Forms.Button
        Me.btnSquare = New System.Windows.Forms.Button
        Me.btnCube = New System.Windows.Forms.Button
        Me.btnxPower4 = New System.Windows.Forms.Button
        Me.btnM = New System.Windows.Forms.Button
        Me.btnClearTextbox = New System.Windows.Forms.Button
        Me.btnMplus = New System.Windows.Forms.Button
        Me.btnMminus = New System.Windows.Forms.Button
        Me.btnAnd = New System.Windows.Forms.Button
        Me.btnOr = New System.Windows.Forms.Button
        Me.btnNot = New System.Windows.Forms.Button
        Me.btnXor = New System.Windows.Forms.Button
        Me.btnTan = New System.Windows.Forms.Button
        Me.btnCos = New System.Windows.Forms.Button
        Me.btnSin = New System.Windows.Forms.Button
        Me.btnPowerFunctions = New System.Windows.Forms.Button
        Me.btnTrignometric = New System.Windows.Forms.Button
        Me.btnHyperbolicTrig = New System.Windows.Forms.Button
        Me.btnOtherFuncs = New System.Windows.Forms.Button
        Me.btnConstants = New System.Windows.Forms.Button
        Me.btnLogicalFuncs = New System.Windows.Forms.Button
        Me.btnScientificMode = New System.Windows.Forms.Button
        Me.btnMemFuncs = New System.Windows.Forms.Button
        Me.btnInvSin = New System.Windows.Forms.Button
        Me.btnInvCos = New System.Windows.Forms.Button
        Me.btnInvTan = New System.Windows.Forms.Button
        Me.btnInverseTrigFuncs = New System.Windows.Forms.Button
        Me.gbMain1.SuspendLayout()
        Me.SuspendLayout()
        '
        'displayText
        '
        Me.displayText.BackColor = System.Drawing.Color.Silver
        Me.displayText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.displayText.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.displayText.Location = New System.Drawing.Point(227, 157)
        Me.displayText.Name = "displayText"
        Me.displayText.Size = New System.Drawing.Size(507, 31)
        Me.displayText.TabIndex = 0
        Me.displayText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.DimGray
        Me.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn1.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.ForeColor = System.Drawing.Color.White
        Me.btn1.Location = New System.Drawing.Point(415, 329)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(52, 36)
        Me.btn1.TabIndex = 1
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.DimGray
        Me.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn2.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.ForeColor = System.Drawing.Color.White
        Me.btn2.Location = New System.Drawing.Point(465, 329)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(52, 36)
        Me.btn2.TabIndex = 2
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.DimGray
        Me.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn3.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.ForeColor = System.Drawing.Color.White
        Me.btn3.Location = New System.Drawing.Point(515, 329)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(52, 36)
        Me.btn3.TabIndex = 3
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.DimGray
        Me.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn4.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.ForeColor = System.Drawing.Color.White
        Me.btn4.Location = New System.Drawing.Point(415, 294)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(52, 36)
        Me.btn4.TabIndex = 4
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.DimGray
        Me.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn5.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.ForeColor = System.Drawing.Color.White
        Me.btn5.Location = New System.Drawing.Point(465, 294)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(52, 36)
        Me.btn5.TabIndex = 5
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.DimGray
        Me.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn6.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.ForeColor = System.Drawing.Color.White
        Me.btn6.Location = New System.Drawing.Point(515, 294)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(52, 36)
        Me.btn6.TabIndex = 6
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.DimGray
        Me.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn7.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.ForeColor = System.Drawing.Color.White
        Me.btn7.Location = New System.Drawing.Point(415, 259)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(52, 36)
        Me.btn7.TabIndex = 7
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.DimGray
        Me.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn8.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.ForeColor = System.Drawing.Color.White
        Me.btn8.Location = New System.Drawing.Point(465, 259)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(52, 36)
        Me.btn8.TabIndex = 8
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.DimGray
        Me.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn9.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.ForeColor = System.Drawing.Color.White
        Me.btn9.Location = New System.Drawing.Point(515, 259)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(52, 36)
        Me.btn9.TabIndex = 9
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.Color.DimGray
        Me.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn0.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.ForeColor = System.Drawing.Color.White
        Me.btn0.Location = New System.Drawing.Point(415, 364)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(52, 36)
        Me.btn0.TabIndex = 0
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.DimGray
        Me.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdd.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAdd.Location = New System.Drawing.Point(567, 364)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(55, 36)
        Me.btnAdd.TabIndex = 10
        Me.btnAdd.Text = "+"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'btnSub
        '
        Me.btnSub.BackColor = System.Drawing.Color.DimGray
        Me.btnSub.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSub.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSub.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSub.Location = New System.Drawing.Point(567, 329)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(55, 36)
        Me.btnSub.TabIndex = 11
        Me.btnSub.Text = "-"
        Me.btnSub.UseVisualStyleBackColor = False
        '
        'btnMult
        '
        Me.btnMult.BackColor = System.Drawing.Color.DimGray
        Me.btnMult.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMult.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMult.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnMult.Location = New System.Drawing.Point(567, 294)
        Me.btnMult.Name = "btnMult"
        Me.btnMult.Size = New System.Drawing.Size(55, 36)
        Me.btnMult.TabIndex = 12
        Me.btnMult.Text = "*"
        Me.btnMult.UseVisualStyleBackColor = False
        '
        'btnDiv
        '
        Me.btnDiv.BackColor = System.Drawing.Color.DimGray
        Me.btnDiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDiv.Font = New System.Drawing.Font("Courier New", 18.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDiv.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDiv.Location = New System.Drawing.Point(567, 259)
        Me.btnDiv.Name = "btnDiv"
        Me.btnDiv.Size = New System.Drawing.Size(55, 36)
        Me.btnDiv.TabIndex = 13
        Me.btnDiv.Text = "/"
        Me.btnDiv.UseVisualStyleBackColor = False
        '
        'btnEqual
        '
        Me.btnEqual.BackColor = System.Drawing.Color.White
        Me.btnEqual.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEqual.ForeColor = System.Drawing.Color.Black
        Me.btnEqual.Location = New System.Drawing.Point(227, 406)
        Me.btnEqual.Name = "btnEqual"
        Me.btnEqual.Size = New System.Drawing.Size(509, 38)
        Me.btnEqual.TabIndex = 14
        Me.btnEqual.Text = "EQUATE"
        Me.btnEqual.UseVisualStyleBackColor = False
        '
        'btnDecimal
        '
        Me.btnDecimal.BackColor = System.Drawing.Color.DimGray
        Me.btnDecimal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDecimal.Font = New System.Drawing.Font("Courier New", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDecimal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDecimal.Location = New System.Drawing.Point(465, 364)
        Me.btnDecimal.Name = "btnDecimal"
        Me.btnDecimal.Size = New System.Drawing.Size(52, 36)
        Me.btnDecimal.TabIndex = 15
        Me.btnDecimal.Text = "."
        Me.btnDecimal.UseVisualStyleBackColor = False
        '
        'btnSign
        '
        Me.btnSign.BackColor = System.Drawing.Color.DimGray
        Me.btnSign.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSign.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSign.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSign.Location = New System.Drawing.Point(515, 364)
        Me.btnSign.Name = "btnSign"
        Me.btnSign.Size = New System.Drawing.Size(52, 36)
        Me.btnSign.TabIndex = 16
        Me.btnSign.Text = "+/-"
        Me.btnSign.UseVisualStyleBackColor = False
        '
        'btnClearAll
        '
        Me.btnClearAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearAll.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearAll.ForeColor = System.Drawing.Color.White
        Me.btnClearAll.Location = New System.Drawing.Point(625, 216)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(109, 37)
        Me.btnClearAll.TabIndex = 17
        Me.btnClearAll.Text = "Clear All"
        Me.btnClearAll.UseVisualStyleBackColor = False
        '
        'btnBackSpace
        '
        Me.btnBackSpace.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBackSpace.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBackSpace.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackSpace.ForeColor = System.Drawing.Color.White
        Me.btnBackSpace.Location = New System.Drawing.Point(350, 216)
        Me.btnBackSpace.Name = "btnBackSpace"
        Me.btnBackSpace.Size = New System.Drawing.Size(167, 37)
        Me.btnBackSpace.TabIndex = 18
        Me.btnBackSpace.Text = "BACKSPACE"
        Me.btnBackSpace.UseVisualStyleBackColor = False
        '
        'btnMenu
        '
        Me.btnMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMenu.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenu.ForeColor = System.Drawing.Color.Black
        Me.btnMenu.Location = New System.Drawing.Point(12, 157)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(199, 31)
        Me.btnMenu.TabIndex = 19
        Me.btnMenu.Text = "MENU"
        Me.btnMenu.UseVisualStyleBackColor = False
        '
        'btnTime
        '
        Me.btnTime.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTime.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTime.Location = New System.Drawing.Point(7, 12)
        Me.btnTime.Name = "btnTime"
        Me.btnTime.Size = New System.Drawing.Size(80, 27)
        Me.btnTime.TabIndex = 20
        Me.btnTime.Text = "TIME"
        Me.btnTime.UseVisualStyleBackColor = False
        Me.btnTime.Visible = False
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lblTime.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblTime.Location = New System.Drawing.Point(93, 12)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(553, 26)
        Me.lblTime.TabIndex = 21
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblTime.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClose.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(652, 10)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(70, 28)
        Me.btnClose.TabIndex = 22
        Me.btnClose.Text = "DONE"
        Me.btnClose.UseVisualStyleBackColor = False
        Me.btnClose.Visible = False
        '
        'btnColour
        '
        Me.btnColour.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnColour.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnColour.Location = New System.Drawing.Point(7, 48)
        Me.btnColour.Name = "btnColour"
        Me.btnColour.Size = New System.Drawing.Size(79, 27)
        Me.btnColour.TabIndex = 23
        Me.btnColour.Text = "COLOUR"
        Me.btnColour.UseVisualStyleBackColor = False
        Me.btnColour.Visible = False
        '
        'btna
        '
        Me.btna.BackColor = System.Drawing.Color.Gray
        Me.btna.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btna.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btna.Location = New System.Drawing.Point(93, 48)
        Me.btna.Name = "btna"
        Me.btna.Size = New System.Drawing.Size(19, 27)
        Me.btna.TabIndex = 24
        Me.btna.UseVisualStyleBackColor = False
        Me.btna.Visible = False
        '
        'btnb
        '
        Me.btnb.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnb.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnb.Location = New System.Drawing.Point(122, 48)
        Me.btnb.Name = "btnb"
        Me.btnb.Size = New System.Drawing.Size(19, 27)
        Me.btnb.TabIndex = 25
        Me.btnb.UseVisualStyleBackColor = False
        Me.btnb.Visible = False
        '
        'btnc
        '
        Me.btnc.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnc.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnc.Location = New System.Drawing.Point(150, 48)
        Me.btnc.Name = "btnc"
        Me.btnc.Size = New System.Drawing.Size(19, 27)
        Me.btnc.TabIndex = 26
        Me.btnc.UseVisualStyleBackColor = False
        Me.btnc.Visible = False
        '
        'gbMain1
        '
        Me.gbMain1.Controls.Add(Me.DateTimePicker1)
        Me.gbMain1.Controls.Add(Me.btnDate)
        Me.gbMain1.Controls.Add(Me.btnTime)
        Me.gbMain1.Controls.Add(Me.btnClose)
        Me.gbMain1.Controls.Add(Me.btnc)
        Me.gbMain1.Controls.Add(Me.btnb)
        Me.gbMain1.Controls.Add(Me.btnColour)
        Me.gbMain1.Controls.Add(Me.btna)
        Me.gbMain1.Controls.Add(Me.lblTime)
        Me.gbMain1.Location = New System.Drawing.Point(12, 1)
        Me.gbMain1.Name = "gbMain1"
        Me.gbMain1.Size = New System.Drawing.Size(724, 128)
        Me.gbMain1.TabIndex = 27
        Me.gbMain1.TabStop = False
        Me.gbMain1.Visible = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Location = New System.Drawing.Point(92, 85)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(554, 27)
        Me.DateTimePicker1.TabIndex = 28
        '
        'btnDate
        '
        Me.btnDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnDate.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDate.Location = New System.Drawing.Point(7, 85)
        Me.btnDate.Name = "btnDate"
        Me.btnDate.Size = New System.Drawing.Size(79, 27)
        Me.btnDate.TabIndex = 27
        Me.btnDate.Text = "DATE"
        Me.btnDate.UseVisualStyleBackColor = False
        '
        'btnInverse
        '
        Me.btnInverse.BackColor = System.Drawing.Color.DimGray
        Me.btnInverse.Enabled = False
        Me.btnInverse.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInverse.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInverse.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnInverse.Location = New System.Drawing.Point(350, 329)
        Me.btnInverse.Name = "btnInverse"
        Me.btnInverse.Size = New System.Drawing.Size(65, 36)
        Me.btnInverse.TabIndex = 28
        Me.btnInverse.Text = "1/x"
        Me.btnInverse.UseVisualStyleBackColor = False
        '
        'btnModulus
        '
        Me.btnModulus.BackColor = System.Drawing.Color.DimGray
        Me.btnModulus.Enabled = False
        Me.btnModulus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnModulus.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnModulus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnModulus.Location = New System.Drawing.Point(350, 364)
        Me.btnModulus.Name = "btnModulus"
        Me.btnModulus.Size = New System.Drawing.Size(65, 36)
        Me.btnModulus.TabIndex = 29
        Me.btnModulus.Text = "%"
        Me.btnModulus.UseVisualStyleBackColor = False
        '
        'btnPower
        '
        Me.btnPower.BackColor = System.Drawing.Color.DimGray
        Me.btnPower.Enabled = False
        Me.btnPower.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPower.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPower.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnPower.Location = New System.Drawing.Point(618, 259)
        Me.btnPower.Name = "btnPower"
        Me.btnPower.Size = New System.Drawing.Size(60, 36)
        Me.btnPower.TabIndex = 33
        Me.btnPower.Text = "x^"
        Me.btnPower.UseVisualStyleBackColor = False
        '
        'btnPI
        '
        Me.btnPI.BackColor = System.Drawing.Color.DimGray
        Me.btnPI.Enabled = False
        Me.btnPI.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPI.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPI.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnPI.Location = New System.Drawing.Point(285, 259)
        Me.btnPI.Name = "btnPI"
        Me.btnPI.Size = New System.Drawing.Size(65, 36)
        Me.btnPI.TabIndex = 34
        Me.btnPI.Text = "PI"
        Me.btnPI.UseVisualStyleBackColor = False
        '
        'btnTanh
        '
        Me.btnTanh.BackColor = System.Drawing.Color.DimGray
        Me.btnTanh.Enabled = False
        Me.btnTanh.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTanh.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTanh.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnTanh.Location = New System.Drawing.Point(652, 450)
        Me.btnTanh.Name = "btnTanh"
        Me.btnTanh.Size = New System.Drawing.Size(82, 30)
        Me.btnTanh.TabIndex = 38
        Me.btnTanh.Text = "tanh"
        Me.btnTanh.UseVisualStyleBackColor = False
        '
        'btnCosh
        '
        Me.btnCosh.BackColor = System.Drawing.Color.DimGray
        Me.btnCosh.Enabled = False
        Me.btnCosh.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCosh.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCosh.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCosh.Location = New System.Drawing.Point(569, 450)
        Me.btnCosh.Name = "btnCosh"
        Me.btnCosh.Size = New System.Drawing.Size(82, 30)
        Me.btnCosh.TabIndex = 37
        Me.btnCosh.Text = "cosh"
        Me.btnCosh.UseVisualStyleBackColor = False
        '
        'btnSinh
        '
        Me.btnSinh.BackColor = System.Drawing.Color.DimGray
        Me.btnSinh.Enabled = False
        Me.btnSinh.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSinh.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSinh.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSinh.Location = New System.Drawing.Point(486, 450)
        Me.btnSinh.Name = "btnSinh"
        Me.btnSinh.Size = New System.Drawing.Size(82, 30)
        Me.btnSinh.TabIndex = 36
        Me.btnSinh.Text = "sinh"
        Me.btnSinh.UseVisualStyleBackColor = False
        '
        'btnlog
        '
        Me.btnlog.BackColor = System.Drawing.Color.DimGray
        Me.btnlog.Enabled = False
        Me.btnlog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlog.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlog.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnlog.Location = New System.Drawing.Point(285, 364)
        Me.btnlog.Name = "btnlog"
        Me.btnlog.Size = New System.Drawing.Size(65, 36)
        Me.btnlog.TabIndex = 42
        Me.btnlog.Text = "log"
        Me.btnlog.UseVisualStyleBackColor = False
        '
        'btnln
        '
        Me.btnln.BackColor = System.Drawing.Color.DimGray
        Me.btnln.Enabled = False
        Me.btnln.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnln.Font = New System.Drawing.Font("Courier New", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnln.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnln.Location = New System.Drawing.Point(350, 293)
        Me.btnln.Name = "btnln"
        Me.btnln.Size = New System.Drawing.Size(65, 36)
        Me.btnln.TabIndex = 43
        Me.btnln.Text = "ln"
        Me.btnln.UseVisualStyleBackColor = False
        '
        'btne
        '
        Me.btne.BackColor = System.Drawing.Color.DimGray
        Me.btne.Enabled = False
        Me.btne.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btne.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btne.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btne.Location = New System.Drawing.Point(285, 328)
        Me.btne.Name = "btne"
        Me.btne.Size = New System.Drawing.Size(65, 37)
        Me.btne.TabIndex = 44
        Me.btne.Text = "e"
        Me.btne.UseVisualStyleBackColor = False
        '
        'btnex
        '
        Me.btnex.BackColor = System.Drawing.Color.DimGray
        Me.btnex.Enabled = False
        Me.btnex.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnex.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnex.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnex.Location = New System.Drawing.Point(350, 259)
        Me.btnex.Name = "btnex"
        Me.btnex.Size = New System.Drawing.Size(65, 36)
        Me.btnex.TabIndex = 45
        Me.btnex.Text = "e^x"
        Me.btnex.UseVisualStyleBackColor = False
        '
        'btnsqrt
        '
        Me.btnsqrt.BackColor = System.Drawing.Color.DimGray
        Me.btnsqrt.Enabled = False
        Me.btnsqrt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsqrt.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsqrt.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnsqrt.Location = New System.Drawing.Point(285, 295)
        Me.btnsqrt.Name = "btnsqrt"
        Me.btnsqrt.Size = New System.Drawing.Size(65, 34)
        Me.btnsqrt.TabIndex = 46
        Me.btnsqrt.Text = "sqrt"
        Me.btnsqrt.UseVisualStyleBackColor = False
        '
        'btnRound
        '
        Me.btnRound.BackColor = System.Drawing.Color.DimGray
        Me.btnRound.Enabled = False
        Me.btnRound.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRound.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRound.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnRound.Location = New System.Drawing.Point(227, 486)
        Me.btnRound.Name = "btnRound"
        Me.btnRound.Size = New System.Drawing.Size(82, 30)
        Me.btnRound.TabIndex = 47
        Me.btnRound.Text = "Round"
        Me.btnRound.UseVisualStyleBackColor = False
        '
        'btnCeil
        '
        Me.btnCeil.BackColor = System.Drawing.Color.DimGray
        Me.btnCeil.Enabled = False
        Me.btnCeil.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCeil.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCeil.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCeil.Location = New System.Drawing.Point(486, 486)
        Me.btnCeil.Name = "btnCeil"
        Me.btnCeil.Size = New System.Drawing.Size(82, 30)
        Me.btnCeil.TabIndex = 48
        Me.btnCeil.Text = "Ceil"
        Me.btnCeil.UseVisualStyleBackColor = False
        '
        'btnFloor
        '
        Me.btnFloor.BackColor = System.Drawing.Color.DimGray
        Me.btnFloor.Enabled = False
        Me.btnFloor.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFloor.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFloor.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnFloor.Location = New System.Drawing.Point(310, 486)
        Me.btnFloor.Name = "btnFloor"
        Me.btnFloor.Size = New System.Drawing.Size(82, 30)
        Me.btnFloor.TabIndex = 49
        Me.btnFloor.Text = "Floor"
        Me.btnFloor.UseVisualStyleBackColor = False
        '
        'btnFact
        '
        Me.btnFact.BackColor = System.Drawing.Color.DimGray
        Me.btnFact.Enabled = False
        Me.btnFact.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFact.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFact.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnFact.Location = New System.Drawing.Point(227, 293)
        Me.btnFact.Name = "btnFact"
        Me.btnFact.Size = New System.Drawing.Size(58, 36)
        Me.btnFact.TabIndex = 50
        Me.btnFact.Text = "x!"
        Me.btnFact.UseVisualStyleBackColor = False
        '
        'btnPerm
        '
        Me.btnPerm.BackColor = System.Drawing.Color.DimGray
        Me.btnPerm.Enabled = False
        Me.btnPerm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPerm.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPerm.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnPerm.Location = New System.Drawing.Point(227, 328)
        Me.btnPerm.Name = "btnPerm"
        Me.btnPerm.Size = New System.Drawing.Size(58, 44)
        Me.btnPerm.TabIndex = 51
        Me.btnPerm.Text = "nPr"
        Me.btnPerm.UseVisualStyleBackColor = False
        '
        'btnComb
        '
        Me.btnComb.BackColor = System.Drawing.Color.DimGray
        Me.btnComb.Enabled = False
        Me.btnComb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnComb.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnComb.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnComb.Location = New System.Drawing.Point(227, 364)
        Me.btnComb.Name = "btnComb"
        Me.btnComb.Size = New System.Drawing.Size(58, 36)
        Me.btnComb.TabIndex = 52
        Me.btnComb.Text = "nCr"
        Me.btnComb.UseVisualStyleBackColor = False
        '
        'btnTruncate
        '
        Me.btnTruncate.BackColor = System.Drawing.Color.DimGray
        Me.btnTruncate.Enabled = False
        Me.btnTruncate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTruncate.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTruncate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnTruncate.Location = New System.Drawing.Point(393, 486)
        Me.btnTruncate.Name = "btnTruncate"
        Me.btnTruncate.Size = New System.Drawing.Size(82, 30)
        Me.btnTruncate.TabIndex = 53
        Me.btnTruncate.Text = "Trunc"
        Me.btnTruncate.UseVisualStyleBackColor = False
        '
        'btnSquare
        '
        Me.btnSquare.BackColor = System.Drawing.Color.DimGray
        Me.btnSquare.Enabled = False
        Me.btnSquare.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSquare.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSquare.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSquare.Location = New System.Drawing.Point(618, 295)
        Me.btnSquare.Name = "btnSquare"
        Me.btnSquare.Size = New System.Drawing.Size(60, 35)
        Me.btnSquare.TabIndex = 54
        Me.btnSquare.Text = "x^2"
        Me.btnSquare.UseVisualStyleBackColor = False
        '
        'btnCube
        '
        Me.btnCube.BackColor = System.Drawing.Color.DimGray
        Me.btnCube.Enabled = False
        Me.btnCube.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCube.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCube.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCube.Location = New System.Drawing.Point(618, 329)
        Me.btnCube.Name = "btnCube"
        Me.btnCube.Size = New System.Drawing.Size(60, 36)
        Me.btnCube.TabIndex = 55
        Me.btnCube.Text = "x^3"
        Me.btnCube.UseVisualStyleBackColor = False
        '
        'btnxPower4
        '
        Me.btnxPower4.BackColor = System.Drawing.Color.DimGray
        Me.btnxPower4.Enabled = False
        Me.btnxPower4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnxPower4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnxPower4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnxPower4.Location = New System.Drawing.Point(618, 364)
        Me.btnxPower4.Name = "btnxPower4"
        Me.btnxPower4.Size = New System.Drawing.Size(60, 36)
        Me.btnxPower4.TabIndex = 56
        Me.btnxPower4.Text = "x^4"
        Me.btnxPower4.UseVisualStyleBackColor = False
        '
        'btnM
        '
        Me.btnM.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnM.Enabled = False
        Me.btnM.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnM.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnM.ForeColor = System.Drawing.Color.White
        Me.btnM.Location = New System.Drawing.Point(285, 216)
        Me.btnM.Name = "btnM"
        Me.btnM.Size = New System.Drawing.Size(65, 37)
        Me.btnM.TabIndex = 57
        Me.btnM.Text = "M"
        Me.btnM.UseVisualStyleBackColor = False
        '
        'btnClearTextbox
        '
        Me.btnClearTextbox.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnClearTextbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClearTextbox.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearTextbox.ForeColor = System.Drawing.Color.White
        Me.btnClearTextbox.Location = New System.Drawing.Point(515, 216)
        Me.btnClearTextbox.Name = "btnClearTextbox"
        Me.btnClearTextbox.Size = New System.Drawing.Size(110, 37)
        Me.btnClearTextbox.TabIndex = 58
        Me.btnClearTextbox.Text = "CE"
        Me.btnClearTextbox.UseVisualStyleBackColor = False
        '
        'btnMplus
        '
        Me.btnMplus.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMplus.Enabled = False
        Me.btnMplus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMplus.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMplus.ForeColor = System.Drawing.Color.White
        Me.btnMplus.Location = New System.Drawing.Point(227, 216)
        Me.btnMplus.Name = "btnMplus"
        Me.btnMplus.Size = New System.Drawing.Size(58, 37)
        Me.btnMplus.TabIndex = 59
        Me.btnMplus.Text = "M+"
        Me.btnMplus.UseVisualStyleBackColor = False
        '
        'btnMminus
        '
        Me.btnMminus.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMminus.Enabled = False
        Me.btnMminus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMminus.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMminus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnMminus.Location = New System.Drawing.Point(227, 259)
        Me.btnMminus.Name = "btnMminus"
        Me.btnMminus.Size = New System.Drawing.Size(58, 36)
        Me.btnMminus.TabIndex = 60
        Me.btnMminus.Text = "M-"
        Me.btnMminus.UseVisualStyleBackColor = False
        '
        'btnAnd
        '
        Me.btnAnd.BackColor = System.Drawing.Color.DimGray
        Me.btnAnd.Enabled = False
        Me.btnAnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnd.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAnd.ForeColor = System.Drawing.Color.White
        Me.btnAnd.Location = New System.Drawing.Point(677, 259)
        Me.btnAnd.Name = "btnAnd"
        Me.btnAnd.Size = New System.Drawing.Size(57, 36)
        Me.btnAnd.TabIndex = 61
        Me.btnAnd.Text = "And"
        Me.btnAnd.UseVisualStyleBackColor = False
        '
        'btnOr
        '
        Me.btnOr.BackColor = System.Drawing.Color.DimGray
        Me.btnOr.Enabled = False
        Me.btnOr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOr.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOr.ForeColor = System.Drawing.Color.White
        Me.btnOr.Location = New System.Drawing.Point(677, 295)
        Me.btnOr.Name = "btnOr"
        Me.btnOr.Size = New System.Drawing.Size(57, 35)
        Me.btnOr.TabIndex = 62
        Me.btnOr.Text = "Or"
        Me.btnOr.UseVisualStyleBackColor = False
        '
        'btnNot
        '
        Me.btnNot.BackColor = System.Drawing.Color.DimGray
        Me.btnNot.Enabled = False
        Me.btnNot.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNot.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNot.ForeColor = System.Drawing.Color.White
        Me.btnNot.Location = New System.Drawing.Point(677, 329)
        Me.btnNot.Name = "btnNot"
        Me.btnNot.Size = New System.Drawing.Size(57, 36)
        Me.btnNot.TabIndex = 63
        Me.btnNot.Text = "Not"
        Me.btnNot.UseVisualStyleBackColor = False
        '
        'btnXor
        '
        Me.btnXor.BackColor = System.Drawing.Color.DimGray
        Me.btnXor.Enabled = False
        Me.btnXor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnXor.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnXor.ForeColor = System.Drawing.Color.White
        Me.btnXor.Location = New System.Drawing.Point(677, 364)
        Me.btnXor.Name = "btnXor"
        Me.btnXor.Size = New System.Drawing.Size(57, 36)
        Me.btnXor.TabIndex = 64
        Me.btnXor.Text = "Xor"
        Me.btnXor.UseVisualStyleBackColor = False
        '
        'btnTan
        '
        Me.btnTan.BackColor = System.Drawing.Color.DimGray
        Me.btnTan.Enabled = False
        Me.btnTan.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTan.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnTan.Location = New System.Drawing.Point(393, 450)
        Me.btnTan.Name = "btnTan"
        Me.btnTan.Size = New System.Drawing.Size(82, 30)
        Me.btnTan.TabIndex = 32
        Me.btnTan.Text = "tan"
        Me.btnTan.UseVisualStyleBackColor = False
        '
        'btnCos
        '
        Me.btnCos.BackColor = System.Drawing.Color.DimGray
        Me.btnCos.Enabled = False
        Me.btnCos.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCos.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCos.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCos.Location = New System.Drawing.Point(310, 450)
        Me.btnCos.Name = "btnCos"
        Me.btnCos.Size = New System.Drawing.Size(82, 30)
        Me.btnCos.TabIndex = 31
        Me.btnCos.Text = "cos"
        Me.btnCos.UseVisualStyleBackColor = False
        '
        'btnSin
        '
        Me.btnSin.BackColor = System.Drawing.Color.DimGray
        Me.btnSin.Enabled = False
        Me.btnSin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSin.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSin.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnSin.Location = New System.Drawing.Point(227, 450)
        Me.btnSin.Name = "btnSin"
        Me.btnSin.Size = New System.Drawing.Size(82, 30)
        Me.btnSin.TabIndex = 30
        Me.btnSin.Text = "sin"
        Me.btnSin.UseVisualStyleBackColor = False
        '
        'btnPowerFunctions
        '
        Me.btnPowerFunctions.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPowerFunctions.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPowerFunctions.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPowerFunctions.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnPowerFunctions.Location = New System.Drawing.Point(12, 295)
        Me.btnPowerFunctions.Name = "btnPowerFunctions"
        Me.btnPowerFunctions.Size = New System.Drawing.Size(199, 41)
        Me.btnPowerFunctions.TabIndex = 65
        Me.btnPowerFunctions.Text = "POWER FUNCTIONS >"
        Me.btnPowerFunctions.UseVisualStyleBackColor = False
        '
        'btnTrignometric
        '
        Me.btnTrignometric.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnTrignometric.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTrignometric.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTrignometric.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnTrignometric.Location = New System.Drawing.Point(12, 371)
        Me.btnTrignometric.Name = "btnTrignometric"
        Me.btnTrignometric.Size = New System.Drawing.Size(199, 38)
        Me.btnTrignometric.TabIndex = 66
        Me.btnTrignometric.Text = "SIMPLE TRIGNOMETRIC FUNCTIONS >"
        Me.btnTrignometric.UseVisualStyleBackColor = False
        '
        'btnHyperbolicTrig
        '
        Me.btnHyperbolicTrig.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnHyperbolicTrig.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnHyperbolicTrig.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHyperbolicTrig.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnHyperbolicTrig.Location = New System.Drawing.Point(12, 406)
        Me.btnHyperbolicTrig.Name = "btnHyperbolicTrig"
        Me.btnHyperbolicTrig.Size = New System.Drawing.Size(199, 38)
        Me.btnHyperbolicTrig.TabIndex = 67
        Me.btnHyperbolicTrig.Text = "HYPERBOLIC TRIGNOMETRIC FUNCTIONS >"
        Me.btnHyperbolicTrig.UseVisualStyleBackColor = False
        '
        'btnOtherFuncs
        '
        Me.btnOtherFuncs.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnOtherFuncs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnOtherFuncs.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOtherFuncs.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnOtherFuncs.Location = New System.Drawing.Point(12, 478)
        Me.btnOtherFuncs.Name = "btnOtherFuncs"
        Me.btnOtherFuncs.Size = New System.Drawing.Size(199, 38)
        Me.btnOtherFuncs.TabIndex = 68
        Me.btnOtherFuncs.Text = "OTHER FUNCTIONS >"
        Me.btnOtherFuncs.UseVisualStyleBackColor = False
        '
        'btnConstants
        '
        Me.btnConstants.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnConstants.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnConstants.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConstants.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnConstants.Location = New System.Drawing.Point(12, 514)
        Me.btnConstants.Name = "btnConstants"
        Me.btnConstants.Size = New System.Drawing.Size(199, 38)
        Me.btnConstants.TabIndex = 69
        Me.btnConstants.Text = "CONSTANT's VALUES >"
        Me.btnConstants.UseVisualStyleBackColor = False
        '
        'btnLogicalFuncs
        '
        Me.btnLogicalFuncs.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogicalFuncs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogicalFuncs.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogicalFuncs.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnLogicalFuncs.Location = New System.Drawing.Point(12, 335)
        Me.btnLogicalFuncs.Name = "btnLogicalFuncs"
        Me.btnLogicalFuncs.Size = New System.Drawing.Size(199, 37)
        Me.btnLogicalFuncs.TabIndex = 70
        Me.btnLogicalFuncs.Text = "LOGICAL FUNCTIONS >"
        Me.btnLogicalFuncs.UseVisualStyleBackColor = False
        '
        'btnScientificMode
        '
        Me.btnScientificMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnScientificMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnScientificMode.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnScientificMode.ForeColor = System.Drawing.Color.Black
        Me.btnScientificMode.Location = New System.Drawing.Point(12, 215)
        Me.btnScientificMode.Name = "btnScientificMode"
        Me.btnScientificMode.Size = New System.Drawing.Size(199, 38)
        Me.btnScientificMode.TabIndex = 71
        Me.btnScientificMode.Text = "SCIENTIFIC MODE"
        Me.btnScientificMode.UseVisualStyleBackColor = False
        '
        'btnMemFuncs
        '
        Me.btnMemFuncs.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnMemFuncs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMemFuncs.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMemFuncs.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnMemFuncs.Location = New System.Drawing.Point(12, 259)
        Me.btnMemFuncs.Name = "btnMemFuncs"
        Me.btnMemFuncs.Size = New System.Drawing.Size(199, 40)
        Me.btnMemFuncs.TabIndex = 72
        Me.btnMemFuncs.Text = "MEMORY FUNCTIONS >"
        Me.btnMemFuncs.UseVisualStyleBackColor = False
        '
        'btnInvSin
        '
        Me.btnInvSin.BackColor = System.Drawing.Color.DimGray
        Me.btnInvSin.Enabled = False
        Me.btnInvSin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInvSin.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInvSin.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnInvSin.Location = New System.Drawing.Point(227, 522)
        Me.btnInvSin.Name = "btnInvSin"
        Me.btnInvSin.Size = New System.Drawing.Size(82, 30)
        Me.btnInvSin.TabIndex = 73
        Me.btnInvSin.Text = "sin-1"
        Me.btnInvSin.UseVisualStyleBackColor = False
        '
        'btnInvCos
        '
        Me.btnInvCos.BackColor = System.Drawing.Color.DimGray
        Me.btnInvCos.Enabled = False
        Me.btnInvCos.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInvCos.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInvCos.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnInvCos.Location = New System.Drawing.Point(310, 522)
        Me.btnInvCos.Name = "btnInvCos"
        Me.btnInvCos.Size = New System.Drawing.Size(82, 30)
        Me.btnInvCos.TabIndex = 74
        Me.btnInvCos.Text = "cos-1"
        Me.btnInvCos.UseVisualStyleBackColor = False
        '
        'btnInvTan
        '
        Me.btnInvTan.BackColor = System.Drawing.Color.DimGray
        Me.btnInvTan.Enabled = False
        Me.btnInvTan.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInvTan.Font = New System.Drawing.Font("Courier New", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInvTan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnInvTan.Location = New System.Drawing.Point(393, 522)
        Me.btnInvTan.Name = "btnInvTan"
        Me.btnInvTan.Size = New System.Drawing.Size(82, 30)
        Me.btnInvTan.TabIndex = 75
        Me.btnInvTan.Text = "tan-1"
        Me.btnInvTan.UseVisualStyleBackColor = False
        '
        'btnInverseTrigFuncs
        '
        Me.btnInverseTrigFuncs.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnInverseTrigFuncs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInverseTrigFuncs.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInverseTrigFuncs.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.btnInverseTrigFuncs.Location = New System.Drawing.Point(12, 442)
        Me.btnInverseTrigFuncs.Name = "btnInverseTrigFuncs"
        Me.btnInverseTrigFuncs.Size = New System.Drawing.Size(199, 38)
        Me.btnInverseTrigFuncs.TabIndex = 76
        Me.btnInverseTrigFuncs.Text = "INVERSE TRIGNOMETRIC FUNCTIONS >"
        Me.btnInverseTrigFuncs.UseVisualStyleBackColor = False
        '
        'frmCalculator
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(746, 636)
        Me.Controls.Add(Me.btnInverseTrigFuncs)
        Me.Controls.Add(Me.btnInvSin)
        Me.Controls.Add(Me.btnInvCos)
        Me.Controls.Add(Me.btnInvTan)
        Me.Controls.Add(Me.btnMemFuncs)
        Me.Controls.Add(Me.btnScientificMode)
        Me.Controls.Add(Me.btnLogicalFuncs)
        Me.Controls.Add(Me.btnConstants)
        Me.Controls.Add(Me.btnOtherFuncs)
        Me.Controls.Add(Me.btnHyperbolicTrig)
        Me.Controls.Add(Me.btnTrignometric)
        Me.Controls.Add(Me.btnPowerFunctions)
        Me.Controls.Add(Me.btnSinh)
        Me.Controls.Add(Me.btnCosh)
        Me.Controls.Add(Me.btnSin)
        Me.Controls.Add(Me.btnTanh)
        Me.Controls.Add(Me.btnCos)
        Me.Controls.Add(Me.btnXor)
        Me.Controls.Add(Me.btnTan)
        Me.Controls.Add(Me.btnNot)
        Me.Controls.Add(Me.btnOr)
        Me.Controls.Add(Me.btnAnd)
        Me.Controls.Add(Me.btnMminus)
        Me.Controls.Add(Me.btnMplus)
        Me.Controls.Add(Me.btnClearTextbox)
        Me.Controls.Add(Me.btnM)
        Me.Controls.Add(Me.btnxPower4)
        Me.Controls.Add(Me.btnCube)
        Me.Controls.Add(Me.btnSquare)
        Me.Controls.Add(Me.btnTruncate)
        Me.Controls.Add(Me.btnComb)
        Me.Controls.Add(Me.btnPerm)
        Me.Controls.Add(Me.btnFact)
        Me.Controls.Add(Me.btnFloor)
        Me.Controls.Add(Me.btnCeil)
        Me.Controls.Add(Me.btnRound)
        Me.Controls.Add(Me.btnsqrt)
        Me.Controls.Add(Me.btnex)
        Me.Controls.Add(Me.btne)
        Me.Controls.Add(Me.btnln)
        Me.Controls.Add(Me.btnlog)
        Me.Controls.Add(Me.btnPI)
        Me.Controls.Add(Me.btnPower)
        Me.Controls.Add(Me.btnModulus)
        Me.Controls.Add(Me.btnInverse)
        Me.Controls.Add(Me.gbMain1)
        Me.Controls.Add(Me.btnMenu)
        Me.Controls.Add(Me.btnBackSpace)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnSign)
        Me.Controls.Add(Me.btnDecimal)
        Me.Controls.Add(Me.btnEqual)
        Me.Controls.Add(Me.btnDiv)
        Me.Controls.Add(Me.btnMult)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.displayText)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(754, 670)
        Me.MinimumSize = New System.Drawing.Size(754, 670)
        Me.Name = "frmCalculator"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Calculator"
        Me.gbMain1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents displayText As System.Windows.Forms.TextBox
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn5 As System.Windows.Forms.Button
    Friend WithEvents btn6 As System.Windows.Forms.Button
    Friend WithEvents btn7 As System.Windows.Forms.Button
    Friend WithEvents btn8 As System.Windows.Forms.Button
    Friend WithEvents btn9 As System.Windows.Forms.Button
    Friend WithEvents btn0 As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnSub As System.Windows.Forms.Button
    Friend WithEvents btnMult As System.Windows.Forms.Button
    Friend WithEvents btnDiv As System.Windows.Forms.Button
    Friend WithEvents btnEqual As System.Windows.Forms.Button
    Friend WithEvents btnDecimal As System.Windows.Forms.Button
    Friend WithEvents btnSign As System.Windows.Forms.Button
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents btnBackSpace As System.Windows.Forms.Button
    Friend WithEvents btnMenu As System.Windows.Forms.Button
    Friend WithEvents btnTime As System.Windows.Forms.Button
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnColour As System.Windows.Forms.Button
    Friend WithEvents btna As System.Windows.Forms.Button
    Friend WithEvents btnb As System.Windows.Forms.Button
    Friend WithEvents btnc As System.Windows.Forms.Button
    Friend WithEvents gbMain1 As System.Windows.Forms.GroupBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnDate As System.Windows.Forms.Button
    Friend WithEvents btnInverse As System.Windows.Forms.Button
    Friend WithEvents btnModulus As System.Windows.Forms.Button
    Friend WithEvents btnPower As System.Windows.Forms.Button
    Friend WithEvents btnPI As System.Windows.Forms.Button
    Friend WithEvents btnTanh As System.Windows.Forms.Button
    Friend WithEvents btnCosh As System.Windows.Forms.Button
    Friend WithEvents btnSinh As System.Windows.Forms.Button
    Friend WithEvents btnlog As System.Windows.Forms.Button
    Friend WithEvents btnln As System.Windows.Forms.Button
    Friend WithEvents btne As System.Windows.Forms.Button
    Friend WithEvents btnex As System.Windows.Forms.Button
    Friend WithEvents btnsqrt As System.Windows.Forms.Button
    Friend WithEvents btnRound As System.Windows.Forms.Button
    Friend WithEvents btnCeil As System.Windows.Forms.Button
    Friend WithEvents btnFloor As System.Windows.Forms.Button
    Friend WithEvents btnFact As System.Windows.Forms.Button
    Friend WithEvents btnPerm As System.Windows.Forms.Button
    Friend WithEvents btnComb As System.Windows.Forms.Button
    Friend WithEvents btnTruncate As System.Windows.Forms.Button
    Friend WithEvents btnSquare As System.Windows.Forms.Button
    Friend WithEvents btnCube As System.Windows.Forms.Button
    Friend WithEvents btnxPower4 As System.Windows.Forms.Button
    Friend WithEvents btnM As System.Windows.Forms.Button
    Friend WithEvents btnClearTextbox As System.Windows.Forms.Button
    Friend WithEvents btnMplus As System.Windows.Forms.Button
    Friend WithEvents btnMminus As System.Windows.Forms.Button
    Friend WithEvents btnAnd As System.Windows.Forms.Button
    Friend WithEvents btnOr As System.Windows.Forms.Button
    Friend WithEvents btnNot As System.Windows.Forms.Button
    Friend WithEvents btnXor As System.Windows.Forms.Button
    Friend WithEvents btnTan As System.Windows.Forms.Button
    Friend WithEvents btnCos As System.Windows.Forms.Button
    Friend WithEvents btnSin As System.Windows.Forms.Button
    Friend WithEvents btnPowerFunctions As System.Windows.Forms.Button
    Friend WithEvents btnTrignometric As System.Windows.Forms.Button
    Friend WithEvents btnHyperbolicTrig As System.Windows.Forms.Button
    Friend WithEvents btnOtherFuncs As System.Windows.Forms.Button
    Friend WithEvents btnConstants As System.Windows.Forms.Button
    Friend WithEvents btnLogicalFuncs As System.Windows.Forms.Button
    Friend WithEvents btnScientificMode As System.Windows.Forms.Button
    Friend WithEvents btnMemFuncs As System.Windows.Forms.Button
    Friend WithEvents btnInvSin As System.Windows.Forms.Button
    Friend WithEvents btnInvCos As System.Windows.Forms.Button
    Friend WithEvents btnInvTan As System.Windows.Forms.Button
    Friend WithEvents btnInverseTrigFuncs As System.Windows.Forms.Button

End Class
