﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmsubj
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Txtsectn = New System.Windows.Forms.TextBox()
        Me.Txtclassnme = New System.Windows.Forms.TextBox()
        Me.Txtclassid = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Txtsubj7 = New System.Windows.Forms.TextBox()
        Me.Txtsubj6 = New System.Windows.Forms.TextBox()
        Me.Txtsubj5 = New System.Windows.Forms.TextBox()
        Me.Txtsubj4 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txtsubj3 = New System.Windows.Forms.TextBox()
        Me.Txtsubj2 = New System.Windows.Forms.TextBox()
        Me.Txtsubj1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnedt = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Txtsearch = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label11 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.school_management_system.My.Resources.Resources.schoolmanagement6
        Me.PictureBox1.Location = New System.Drawing.Point(3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(803, 149)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txtsectn)
        Me.GroupBox1.Controls.Add(Me.Txtclassnme)
        Me.GroupBox1.Controls.Add(Me.Txtclassid)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 169)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(261, 122)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Txtsectn
        '
        Me.Txtsectn.Location = New System.Drawing.Point(108, 89)
        Me.Txtsectn.Name = "Txtsectn"
        Me.Txtsectn.Size = New System.Drawing.Size(135, 20)
        Me.Txtsectn.TabIndex = 5
        '
        'Txtclassnme
        '
        Me.Txtclassnme.Location = New System.Drawing.Point(108, 55)
        Me.Txtclassnme.Name = "Txtclassnme"
        Me.Txtclassnme.Size = New System.Drawing.Size(135, 20)
        Me.Txtclassnme.TabIndex = 4
        '
        'Txtclassid
        '
        Me.Txtclassid.Location = New System.Drawing.Point(108, 17)
        Me.Txtclassid.Name = "Txtclassid"
        Me.Txtclassid.Size = New System.Drawing.Size(135, 20)
        Me.Txtclassid.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Section"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Class Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Class Id"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txtsubj7)
        Me.GroupBox2.Controls.Add(Me.Txtsubj6)
        Me.GroupBox2.Controls.Add(Me.Txtsubj5)
        Me.GroupBox2.Controls.Add(Me.Txtsubj4)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Txtsubj3)
        Me.GroupBox2.Controls.Add(Me.Txtsubj2)
        Me.GroupBox2.Controls.Add(Me.Txtsubj1)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(300, 169)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(494, 157)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Txtsubj7
        '
        Me.Txtsubj7.Location = New System.Drawing.Point(337, 89)
        Me.Txtsubj7.Name = "Txtsubj7"
        Me.Txtsubj7.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj7.TabIndex = 13
        '
        'Txtsubj6
        '
        Me.Txtsubj6.Location = New System.Drawing.Point(337, 58)
        Me.Txtsubj6.Name = "Txtsubj6"
        Me.Txtsubj6.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj6.TabIndex = 12
        '
        'Txtsubj5
        '
        Me.Txtsubj5.Location = New System.Drawing.Point(337, 21)
        Me.Txtsubj5.Name = "Txtsubj5"
        Me.Txtsubj5.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj5.TabIndex = 11
        '
        'Txtsubj4
        '
        Me.Txtsubj4.Location = New System.Drawing.Point(93, 124)
        Me.Txtsubj4.Name = "Txtsubj4"
        Me.Txtsubj4.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj4.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(243, 89)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Subject7"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(243, 58)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Subject6"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(243, 24)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(49, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Subject5"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 127)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Subject4"
        '
        'Txtsubj3
        '
        Me.Txtsubj3.Location = New System.Drawing.Point(93, 86)
        Me.Txtsubj3.Name = "Txtsubj3"
        Me.Txtsubj3.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj3.TabIndex = 5
        '
        'Txtsubj2
        '
        Me.Txtsubj2.Location = New System.Drawing.Point(93, 52)
        Me.Txtsubj2.Name = "Txtsubj2"
        Me.Txtsubj2.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj2.TabIndex = 4
        '
        'Txtsubj1
        '
        Me.Txtsubj1.Location = New System.Drawing.Point(93, 17)
        Me.Txtsubj1.Name = "Txtsubj1"
        Me.Txtsubj1.Size = New System.Drawing.Size(127, 20)
        Me.Txtsubj1.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Subject3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Subject2"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Subject1"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btnexit)
        Me.GroupBox4.Controls.Add(Me.Btnclear)
        Me.GroupBox4.Controls.Add(Me.Btnsave)
        Me.GroupBox4.Controls.Add(Me.Btnedt)
        Me.GroupBox4.Controls.Add(Me.Btndel)
        Me.GroupBox4.Controls.Add(Me.Btnadd)
        Me.GroupBox4.Location = New System.Drawing.Point(309, 332)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(485, 83)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        '
        'Btnexit
        '
        Me.Btnexit.Image = Global.school_management_system.My.Resources.Resources.Log_Out
        Me.Btnexit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnexit.Location = New System.Drawing.Point(395, 9)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(72, 70)
        Me.Btnexit.TabIndex = 14
        Me.Btnexit.Text = "Exit"
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnexit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Image = Global.school_management_system.My.Resources.Resources.delete1
        Me.Btnclear.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnclear.Location = New System.Drawing.Point(314, 9)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 70)
        Me.Btnclear.TabIndex = 13
        Me.Btnclear.Text = "Dispose"
        Me.Btnclear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'Btnsave
        '
        Me.Btnsave.Image = Global.school_management_system.My.Resources.Resources.Save
        Me.Btnsave.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsave.Location = New System.Drawing.Point(240, 9)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(68, 70)
        Me.Btnsave.TabIndex = 3
        Me.Btnsave.Text = "Save"
        Me.Btnsave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnedt
        '
        Me.Btnedt.Image = Global.school_management_system.My.Resources.Resources.download__4_
        Me.Btnedt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnedt.Location = New System.Drawing.Point(161, 9)
        Me.Btnedt.Name = "Btnedt"
        Me.Btnedt.Size = New System.Drawing.Size(73, 70)
        Me.Btnedt.TabIndex = 2
        Me.Btnedt.Text = "Edit"
        Me.Btnedt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnedt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnedt.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Image = Global.school_management_system.My.Resources.Resources.Remove
        Me.Btndel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btndel.Location = New System.Drawing.Point(81, 9)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(68, 70)
        Me.Btndel.TabIndex = 1
        Me.Btndel.Text = "Delete"
        Me.Btndel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btndel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Image = Global.school_management_system.My.Resources.Resources.download__3_
        Me.Btnadd.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnadd.Location = New System.Drawing.Point(0, 9)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(75, 70)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "New"
        Me.Btnadd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'Btnsearch
        '
        Me.Btnsearch.Image = Global.school_management_system.My.Resources.Resources.images__1_
        Me.Btnsearch.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsearch.Location = New System.Drawing.Point(208, 370)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 41)
        Me.Btnsearch.TabIndex = 12
        Me.Btnsearch.Text = "Search"
        Me.Btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btnsearch.UseVisualStyleBackColor = True
        '
        'Txtsearch
        '
        Me.Txtsearch.Location = New System.Drawing.Point(3, 370)
        Me.Txtsearch.Multiline = True
        Me.Txtsearch.Name = "Txtsearch"
        Me.Txtsearch.Size = New System.Drawing.Size(209, 41)
        Me.Txtsearch.TabIndex = 11
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(3, 419)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(791, 150)
        Me.DataGridView1.TabIndex = 13
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.Location = New System.Drawing.Point(8, 127)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(189, 24)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Subject Information"
        '
        'Frmsubj
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(806, 581)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.Txtsearch)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Frmsubj"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Frmsubj"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtsectn As System.Windows.Forms.TextBox
    Friend WithEvents Txtclassnme As System.Windows.Forms.TextBox
    Friend WithEvents Txtclassid As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtsubj7 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj6 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj5 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj4 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txtsubj3 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj2 As System.Windows.Forms.TextBox
    Friend WithEvents Txtsubj1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnedt As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btnclear As System.Windows.Forms.Button
    Friend WithEvents Btnsearch As System.Windows.Forms.Button
    Friend WithEvents Txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
