﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Public Class Frmgrand
    Dim con As New SqlClient.SqlConnection
    Dim cmd As New SqlClient.SqlCommand


    Dim dt2 As New DataTable
    Dim dt As New DataTable
    Dim ds As New DataSet
    Dim dsView As New DataView
    Dim bs As New BindingSource
    Dim ad As Boolean
    Dim delt As Boolean
    Dim edt As Boolean
    Dim fillinfo As Boolean
    Dim ob As String
    Dim ful As String
    Dim per As String
    Private Sub dbaccessconnection()
        'Acces DataBase Connectivity and for MS Access 2003 PROVIDER=Microsoft.Jet.OLEDB.4.0
        Try
            con.ConnectionString = "Data Source=RANAALI\SQLEXPRESS;Initial Catalog=school;Integrated Security=True"
            cmd.Connection = con

        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try
    End Sub
    Private Sub fillgrid()

        Try
            con.Open()
            dt.Clear()
            Dim dasql As New SqlDataAdapter("select * from grand order by cnic  ", con)
            dasql.Fill(dt)
            Me.DataGridView1.DataSource = dt
            Me.DataGridView1.Refresh()
            con.Close()
        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try

    End Sub
    Public Sub addrecord()
        con.Open()
        cmd.CommandText = "insert into grand(cnic,term1rslt,term2rslt,term3rslt,total,grandtotal,percentage,grad,photo)values('" & Txtcnic.Text & "','" & Val(Txtterm1.Text) & "','" & Val(Txtterm2.Text) & "','" & Val(Txtterm3.Text) & "','" & Val(Txtreslt.Text) & "','" & Val(Txtgrand.Text) & "','" & Txtper.Text & "','" & Txtgrade.Text & "',@d1)"
        Dim ms As New MemoryStream()
        Dim bmpImage As New Bitmap(PictureBox2.Image)
        bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
        Dim data As Byte() = ms.GetBuffer()
        Dim p As New SqlParameter("@d1", SqlDbType.Image)
        p.Value = data
        cmd.Parameters.Add(p)

        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Private Sub clear()
        Txtcnic.Clear()
        Txtterm1.Clear()
        Txtterm2.Clear()
        Txtterm3.Text = ""
        Txtreslt.Text = ""

        Txtgrand.Text = ""
        Txtper.Clear()
        Txtgrade.Clear()
        
        PictureBox2.Image = school_management_system.My.Resources.Resources.person
    End Sub
    Private Sub remove()
        Try
            'Dim str1 As String = "Delete * from reges where [reges.cnic]= '" & DataGridView1.SelectedCells(0).Value.ToString & "'"
            'Dim cmd1 As New SqlCommand(str1, con)

            con.Open()
            cmd.CommandText = "delete from grand where cnic ='" & Txtcnic.Text & "'"
            cmd.ExecuteNonQuery()

            con.Close()
            fillgrid()
        Catch ex As Exception
            ex.ToString()
        End Try

    End Sub
    Private Sub Frmgrand_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbaccessconnection()
        fillgrid()
        Txtcnic.Enabled = False
        Txtterm1.Enabled = False
        Txtterm2.Enabled = False
        Txtterm3.Enabled = False
        Txtreslt.Enabled = False

        Txtgrand.Enabled = False
        Txtper.Enabled = False
        Txtgrade.Enabled = False
       
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub DataGridView1_Click(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Txtcnic.Text = DataGridView1.SelectedCells(0).Value.ToString()
        Txtterm1.Text = DataGridView1.SelectedCells(1).Value.ToString()
        Txtterm2.Text = DataGridView1.SelectedCells(2).Value.ToString()
        Txtterm3.Text = DataGridView1.SelectedCells(3).Value.ToString()
        Txtreslt.Text = DataGridView1.SelectedCells(4).Value.ToString()

        Txtgrand.Text = DataGridView1.SelectedCells(5).Value.ToString()
        Txtper.Text = DataGridView1.SelectedCells(6).Value.ToString()
        Txtgrade.Text = DataGridView1.SelectedCells(7).Value.ToString()
        
        con.Open()
        cmd = New SqlCommand("SELECT photo FROM grand WHERE cnic=" & DataGridView1.SelectedCells(0).Value, con)
        Dim ms As New MemoryStream(CType(cmd.ExecuteScalar, Byte()))
        PictureBox2.Image = Image.FromStream(ms)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        cmd.Dispose()
        con.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Me.Txtsearch.Text = DataGridView1.CurrentRow.Cells(1).Value.ToString
    End Sub

   
    Private Sub Btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnadd.Click
        ad = True
        edt = False
        delt = False
        dt.Clear()
        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        
        Txtcnic.Enabled = True
        Txtterm1.Enabled = True
        Txtterm2.Enabled = True
        Txtterm3.Enabled = True
        Txtreslt.Enabled = True

        Txtgrand.Enabled = True
        Txtper.Enabled = True
        Txtgrade.Enabled = True
        
        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub Btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btndel.Click
        edt = False
        delt = True
        ad = False
        'fillinfo = False
        Btnadd.Enabled = True
        Btndel.Enabled = False
        Btnedt.Enabled = False
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()

        Txtcnic.Enabled = True
        Txtterm1.Enabled = True
        Txtterm2.Enabled = True
        Txtterm3.Enabled = True
        Txtreslt.Enabled = True

        Txtgrand.Enabled = True
        Txtper.Enabled = True
        Txtgrade.Enabled = True

        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

    Private Sub Btnedt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnedt.Click
        edt = True
        delt = False
        ad = False
        'fillinfo = False
        Btnadd.Enabled = False
        Btndel.Enabled = False
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        Txtterm1.Enabled = True
        Txtterm2.Enabled = True
        Txtterm3.Enabled = True
        Txtreslt.Enabled = True

        Txtgrand.Enabled = True
        Txtper.Enabled = True
        Txtgrade.Enabled = True

        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        clear()
    End Sub

    Private Sub Btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnsave.Click
        If (ad = "True") Then
            addrecord()
            fillgrid()
            MessageBox.Show("record is add")
        End If
        If (delt = "true") Then
            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to permanently delete " & DataGridView1.SelectedCells(0).Value & "?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
            If dr = Windows.Forms.DialogResult.Cancel Then
                MessageBox.Show("Action aborted!", "Abort", MessageBoxButtons.OK, MessageBoxIcon.Information)
                DataGridView1.ClearSelection()
                Exit Sub
            Else
                remove()
                'fillgrid()
            End If
        End If

        If (edt = "true") Then

            Dim dr As New DialogResult
            dr = MessageBox.Show("Are you sure you want to Update?", "Change Details", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
            If dr = Windows.Forms.DialogResult.OK Then
                If con.State = ConnectionState.Closed Then con.Open()
                Dim st As String = "UPDATE [grand] SET term1rslt  = '" & Val(Txtterm1.Text) & "', term2rslt = '" & Val(Txtterm2.Text) & _
                                    "', term3rslt = '" & Val(Txtterm3.Text) & "',total = '" & Val(Txtreslt.Text) & "',grandtotal = '" & Val(Txtgrand.Text) & "', percentage = '" & Txtper.Text & _
                                    "',grade = '" & Txtgrade.Text & "' WHERE cnic = '" & DataGridView1.SelectedCells(0).Value & "'"
                MessageBox.Show("Process Successful!", "Edit", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Dim cmd As New SqlCommand(st, con)
                cmd.ExecuteNonQuery()
                con.Close()
                fillgrid()

            End If



        End If
        'fillgrid()
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = False
        Txtcnic.Enabled = False
        Txtterm1.Enabled = False
        Txtterm2.Enabled = False
        Txtterm3.Enabled = False
        Txtreslt.Enabled = False

        Txtgrand.Enabled = False
        Txtper.Enabled = False
        Txtgrade.Enabled = False

        PictureBox2.Image = school_management_system.My.Resources.Resources.person

        'for clear boxes
        clear()
    End Sub

    Private Sub Btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnclear.Click
        Btnadd.Enabled = True
        Btndel.Enabled = True
        Btnedt.Enabled = True
        Btnsave.Enabled = True
        Btnclear.Enabled = True
        Btnexit.Enabled = True
        Txtcnic.Enabled = True
        fillgrid()
        Txtcnic.Enabled = False
        Txtterm1.Enabled = False
        Txtterm2.Enabled = False
        Txtterm3.Enabled = False
        Txtreslt.Enabled = False

        Txtgrand.Enabled = False
        Txtper.Enabled = False
        Txtgrade.Enabled = False

        PictureBox2.Image = school_management_system.My.Resources.Resources.person

    End Sub

    Private Sub Btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexit.Click
        Me.Close()
    End Sub

    Private Sub Btnbrows_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnbrows.Click
        Try
            With OpenFileDialog1
                .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
                .FilterIndex = 4
            End With
            'Clear the file name
            OpenFileDialog1.FileName = ""
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                PictureBox2.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub
    Private Sub reslt()
        ob = Val(Txtreslt.Text)
        ful = Val(Txtgrand.Text)
        Txtper.Text = ob / ful * 100
    End Sub
    Private Sub grad()
        If (Txtper.Text >= 90 & Txtper.Text <= 100) Then
            Txtgrade.Text = "Your grade is A"
        ElseIf (Txtper.Text >= 79.5 & Txtper.Text < 90) Then
            Txtgrade.Text = "Your grade is B+"
        ElseIf (Txtper.Text >= 75.5 & Txtper.Text < 79.5) Then
            Txtgrade.Text = "Your grade is B"
        ElseIf (Txtper.Text >= 70.5 & Txtper.Text < 75.5) Then
            Txtgrade.Text = "Your grade is B-"
        ElseIf (Txtper.Text >= 65.5 & Txtper.Text < 70.5) Then
            Txtper.Text = "Your grade is C+"
        ElseIf (Txtper.Text >= 60.5 & Txtper.Text < 65.5) Then
            Txtgrade.Text = "Your grade is C"
        ElseIf (Txtper.Text >= 50.5 & Txtper.Text < 60.5) Then
            Txtgrade.Text = "Your grade is C- "
        ElseIf (Txtper.Text >= 33.0 & Txtper.Text < 50.5) Then

            Txtgrade.Text = "Your grade is D"
        Else
            Txtgrade.Text = "you are failed"
        End If
    End Sub
    Private Sub reslt1()
        Txtreslt.Text = Val(Txtterm1.Text) + Val(Txtterm2.Text) + Val(Txtterm3.Text)
    End Sub

    Private Sub Txtreslt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtreslt.Click
        reslt1()
    End Sub

    

   

    Private Sub Txtgrand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txtgrand.TextChanged

    End Sub

    Private Sub Txtper_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtper.Click
        reslt()
    End Sub

    Private Sub Txtgrade_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txtgrade.Click
        grad()
    End Sub

   

   
    'Private Sub fill()

    'Try
    ' Dim fill As String
    'MessageBox.Show("Fill")
    'con.Open()
    'cmd.CommandText = "select obmarks from rslt where cnic=" & Txtcnic.Text & " "
    'fill = cmd.ExecuteScalar()
    'Txtterm1.Text = fill
    'cmd.CommandText = "select obmarks from term2 where cnic=" & Txtcnic.Text & ""
    'fill = cmd.ExecuteScalar()
    'Txtterm2.Text = fill
    'cmd.CommandText = "select obmarks from term3 where cnic=" & Txtcnic.Text & ""
    'fill = cmd.ExecuteScalar()
    'Txtterm3.Text = fill

    ' con.Close()
    ' MessageBox.Show("done")
    'Catch ex As Exception
    'End Try


    ' End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'fill()
    End Sub
End Class