﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConstants
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnFaradays = New System.Windows.Forms.Button()
        Me.btnAvo = New System.Windows.Forms.Button()
        Me.btnMolar = New System.Windows.Forms.Button()
        Me.btnBohrs = New System.Windows.Forms.Button()
        Me.btnImpedence = New System.Windows.Forms.Button()
        Me.btnPermeability = New System.Windows.Forms.Button()
        Me.btnPermitivity = New System.Windows.Forms.Button()
        Me.btnCharge = New System.Windows.Forms.Button()
        Me.btnBoltzmans = New System.Windows.Forms.Button()
        Me.btnPlanks = New System.Windows.Forms.Button()
        Me.btnGravitational = New System.Windows.Forms.Button()
        Me.btnCoulombs = New System.Windows.Forms.Button()
        Me.btnSpeed = New System.Windows.Forms.Button()
        Me.textbox = New System.Windows.Forms.MaskedTextBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnFaradays)
        Me.Panel1.Controls.Add(Me.btnAvo)
        Me.Panel1.Controls.Add(Me.btnMolar)
        Me.Panel1.Controls.Add(Me.btnBohrs)
        Me.Panel1.Controls.Add(Me.btnImpedence)
        Me.Panel1.Controls.Add(Me.btnPermeability)
        Me.Panel1.Controls.Add(Me.btnPermitivity)
        Me.Panel1.Controls.Add(Me.btnCharge)
        Me.Panel1.Controls.Add(Me.btnBoltzmans)
        Me.Panel1.Controls.Add(Me.btnPlanks)
        Me.Panel1.Controls.Add(Me.btnGravitational)
        Me.Panel1.Controls.Add(Me.btnCoulombs)
        Me.Panel1.Controls.Add(Me.btnSpeed)
        Me.Panel1.Controls.Add(Me.textbox)
        Me.Panel1.Location = New System.Drawing.Point(2, 106)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(257, 477)
        Me.Panel1.TabIndex = 0
        '
        'btnFaradays
        '
        Me.btnFaradays.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnFaradays.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFaradays.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnFaradays.Location = New System.Drawing.Point(-5, 446)
        Me.btnFaradays.Name = "btnFaradays"
        Me.btnFaradays.Size = New System.Drawing.Size(256, 27)
        Me.btnFaradays.TabIndex = 34
        Me.btnFaradays.Text = "F     -    Faradays Constant"
        Me.btnFaradays.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFaradays.UseVisualStyleBackColor = True
        '
        'btnAvo
        '
        Me.btnAvo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAvo.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAvo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAvo.Location = New System.Drawing.Point(-5, 409)
        Me.btnAvo.Name = "btnAvo"
        Me.btnAvo.Size = New System.Drawing.Size(256, 31)
        Me.btnAvo.TabIndex = 33
        Me.btnAvo.Text = "Na  -    Avogadros Number"
        Me.btnAvo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAvo.UseVisualStyleBackColor = True
        '
        'btnMolar
        '
        Me.btnMolar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMolar.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMolar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnMolar.Location = New System.Drawing.Point(-5, 376)
        Me.btnMolar.Name = "btnMolar"
        Me.btnMolar.Size = New System.Drawing.Size(256, 27)
        Me.btnMolar.TabIndex = 32
        Me.btnMolar.Text = "Rc  -    Molar gas constant"
        Me.btnMolar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnMolar.UseVisualStyleBackColor = True
        '
        'btnBohrs
        '
        Me.btnBohrs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBohrs.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBohrs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBohrs.Location = New System.Drawing.Point(-5, 343)
        Me.btnBohrs.Name = "btnBohrs"
        Me.btnBohrs.Size = New System.Drawing.Size(256, 27)
        Me.btnBohrs.TabIndex = 31
        Me.btnBohrs.Text = "Rb  -    Bohrs radius"
        Me.btnBohrs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBohrs.UseVisualStyleBackColor = True
        '
        'btnImpedence
        '
        Me.btnImpedence.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnImpedence.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImpedence.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnImpedence.Location = New System.Drawing.Point(-5, 310)
        Me.btnImpedence.Name = "btnImpedence"
        Me.btnImpedence.Size = New System.Drawing.Size(256, 27)
        Me.btnImpedence.TabIndex = 30
        Me.btnImpedence.Text = "z     -    Impedence of vacuum"
        Me.btnImpedence.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnImpedence.UseVisualStyleBackColor = True
        '
        'btnPermeability
        '
        Me.btnPermeability.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPermeability.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPermeability.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPermeability.Location = New System.Drawing.Point(-5, 277)
        Me.btnPermeability.Name = "btnPermeability"
        Me.btnPermeability.Size = New System.Drawing.Size(256, 27)
        Me.btnPermeability.TabIndex = 29
        Me.btnPermeability.Text = "u     -    Permeability of vacuum"
        Me.btnPermeability.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPermeability.UseVisualStyleBackColor = True
        '
        'btnPermitivity
        '
        Me.btnPermitivity.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPermitivity.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPermitivity.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPermitivity.Location = New System.Drawing.Point(-5, 244)
        Me.btnPermitivity.Name = "btnPermitivity"
        Me.btnPermitivity.Size = New System.Drawing.Size(256, 27)
        Me.btnPermitivity.TabIndex = 28
        Me.btnPermitivity.Text = "E     -    Permitivity of vacuum"
        Me.btnPermitivity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPermitivity.UseVisualStyleBackColor = True
        '
        'btnCharge
        '
        Me.btnCharge.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCharge.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCharge.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnCharge.Location = New System.Drawing.Point(-5, 211)
        Me.btnCharge.Name = "btnCharge"
        Me.btnCharge.Size = New System.Drawing.Size(256, 27)
        Me.btnCharge.TabIndex = 27
        Me.btnCharge.Text = "e     -    Charge on electron"
        Me.btnCharge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCharge.UseVisualStyleBackColor = True
        '
        'btnBoltzmans
        '
        Me.btnBoltzmans.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBoltzmans.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBoltzmans.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBoltzmans.Location = New System.Drawing.Point(-5, 178)
        Me.btnBoltzmans.Name = "btnBoltzmans"
        Me.btnBoltzmans.Size = New System.Drawing.Size(256, 27)
        Me.btnBoltzmans.TabIndex = 26
        Me.btnBoltzmans.Text = "k     -    Boltzmans Constant     "
        Me.btnBoltzmans.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBoltzmans.UseVisualStyleBackColor = True
        '
        'btnPlanks
        '
        Me.btnPlanks.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPlanks.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPlanks.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPlanks.Location = New System.Drawing.Point(-5, 145)
        Me.btnPlanks.Name = "btnPlanks"
        Me.btnPlanks.Size = New System.Drawing.Size(256, 27)
        Me.btnPlanks.TabIndex = 25
        Me.btnPlanks.Text = "h     -    Planks Constant"
        Me.btnPlanks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPlanks.UseVisualStyleBackColor = True
        '
        'btnGravitational
        '
        Me.btnGravitational.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGravitational.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGravitational.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnGravitational.Location = New System.Drawing.Point(-5, 112)
        Me.btnGravitational.Name = "btnGravitational"
        Me.btnGravitational.Size = New System.Drawing.Size(256, 27)
        Me.btnGravitational.TabIndex = 24
        Me.btnGravitational.Text = "g     -    Gravitational Acceleration"
        Me.btnGravitational.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGravitational.UseVisualStyleBackColor = True
        '
        'btnCoulombs
        '
        Me.btnCoulombs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCoulombs.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCoulombs.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnCoulombs.Location = New System.Drawing.Point(-5, 79)
        Me.btnCoulombs.Name = "btnCoulombs"
        Me.btnCoulombs.Size = New System.Drawing.Size(256, 27)
        Me.btnCoulombs.TabIndex = 23
        Me.btnCoulombs.Text = "Cc   -    Coulombs Constant     "
        Me.btnCoulombs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCoulombs.UseVisualStyleBackColor = True
        '
        'btnSpeed
        '
        Me.btnSpeed.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSpeed.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSpeed.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSpeed.Location = New System.Drawing.Point(-5, 46)
        Me.btnSpeed.Name = "btnSpeed"
        Me.btnSpeed.Size = New System.Drawing.Size(256, 27)
        Me.btnSpeed.TabIndex = 22
        Me.btnSpeed.Text = "c     -     SPEED OF LIGHT"
        Me.btnSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSpeed.UseVisualStyleBackColor = True
        '
        'textbox
        '
        Me.textbox.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.textbox.Font = New System.Drawing.Font("Calibri", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textbox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.textbox.Location = New System.Drawing.Point(-5, 12)
        Me.textbox.Name = "textbox"
        Me.textbox.Size = New System.Drawing.Size(256, 28)
        Me.textbox.TabIndex = 21
        Me.textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmConstants
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = Global.school_management_system.My.Resources.Resources.special_form2
        Me.ClientSize = New System.Drawing.Size(254, 581)
        Me.Controls.Add(Me.Panel1)
        Me.Location = New System.Drawing.Point(753, 0)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(270, 670)
        Me.MinimumSize = New System.Drawing.Size(270, 598)
        Me.Name = "frmConstants"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "CONSTANTS"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnFaradays As System.Windows.Forms.Button
    Friend WithEvents btnAvo As System.Windows.Forms.Button
    Friend WithEvents btnMolar As System.Windows.Forms.Button
    Friend WithEvents btnBohrs As System.Windows.Forms.Button
    Friend WithEvents btnImpedence As System.Windows.Forms.Button
    Friend WithEvents btnPermeability As System.Windows.Forms.Button
    Friend WithEvents btnPermitivity As System.Windows.Forms.Button
    Friend WithEvents btnCharge As System.Windows.Forms.Button
    Friend WithEvents btnBoltzmans As System.Windows.Forms.Button
    Friend WithEvents btnPlanks As System.Windows.Forms.Button
    Friend WithEvents btnGravitational As System.Windows.Forms.Button
    Friend WithEvents btnCoulombs As System.Windows.Forms.Button
    Friend WithEvents btnSpeed As System.Windows.Forms.Button
    Friend WithEvents textbox As System.Windows.Forms.MaskedTextBox
End Class
