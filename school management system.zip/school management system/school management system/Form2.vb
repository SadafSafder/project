﻿Public Class frmConstants

    Private Sub btnSpeed_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "3.0 x 10^8 m/s"
    End Sub

    Private Sub btnSpeed_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnCoulombs_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "8.987 x 10^9 Nm^2/Coulombs^2"
    End Sub

    Private Sub btnCoulombs_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnGravitational_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "9.806 m/s^2"
    End Sub

    Private Sub btnGravitational_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnPlanks_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "6.67 x 10^-11 m^3/kg/s^2"
    End Sub

    Private Sub btnPlanks_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnBoltzmans_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "1.3807 x 10^-23 J/K"
    End Sub

    Private Sub btnBoltzmans_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnCharge_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "1.6022 x 10^-22 coulombs"
    End Sub

    Private Sub btnCharge_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnPermitivity_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "8.85 x 10^-12 F/m"
    End Sub

    Private Sub btnPermitivity_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnPermeability_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "1.2566 x 10 ^ -6 N/A^2"
    End Sub

    Private Sub btnPermeability_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnImpedence_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "3.767 x 10^2 ohms"
    End Sub

    Private Sub btnImpedence_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnBohrs_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "5.2918 x 10^-11 m"
    End Sub

    Private Sub btnBohrs_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnMolar_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "8.3145 J/mol/K"
    End Sub

    Private Sub btnMolar_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnAvo_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "6.022 x 10^23 mol^-1"
    End Sub

    Private Sub btnAvo_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

    Private Sub btnFaradays_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Text = "9.6485 x 10^4 C/mol"
    End Sub

    Private Sub btnFaradays_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textbox.Clear()
    End Sub

End Class