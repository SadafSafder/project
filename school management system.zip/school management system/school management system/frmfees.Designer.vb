﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmfees
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Txtfnme = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txtnme = New System.Windows.Forms.TextBox()
        Me.Txtcnic = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Txtlibraryfee = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Txtexamfee = New System.Windows.Forms.TextBox()
        Me.Txtmonthfee = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txtpaid = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txtdue = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Txttransportfee = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txtblnce = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Btnbrows = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnedt = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.Txtsearch = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txtfnme)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Txtnme)
        Me.GroupBox1.Controls.Add(Me.Txtcnic)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 155)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(274, 117)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Txtfnme
        '
        Me.Txtfnme.Location = New System.Drawing.Point(83, 81)
        Me.Txtfnme.Name = "Txtfnme"
        Me.Txtfnme.Size = New System.Drawing.Size(170, 20)
        Me.Txtfnme.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Father Name"
        '
        'Txtnme
        '
        Me.Txtnme.Location = New System.Drawing.Point(83, 53)
        Me.Txtnme.Name = "Txtnme"
        Me.Txtnme.Size = New System.Drawing.Size(170, 20)
        Me.Txtnme.TabIndex = 3
        '
        'Txtcnic
        '
        Me.Txtcnic.Location = New System.Drawing.Point(83, 20)
        Me.Txtcnic.Name = "Txtcnic"
        Me.Txtcnic.Size = New System.Drawing.Size(170, 20)
        Me.Txtcnic.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cnic"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txtlibraryfee)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Txtexamfee)
        Me.GroupBox2.Controls.Add(Me.Txtmonthfee)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(292, 155)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(267, 117)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Txtlibraryfee
        '
        Me.Txtlibraryfee.Location = New System.Drawing.Point(83, 88)
        Me.Txtlibraryfee.Name = "Txtlibraryfee"
        Me.Txtlibraryfee.Size = New System.Drawing.Size(170, 20)
        Me.Txtlibraryfee.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 88)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Library Fee"
        '
        'Txtexamfee
        '
        Me.Txtexamfee.Location = New System.Drawing.Point(83, 53)
        Me.Txtexamfee.Name = "Txtexamfee"
        Me.Txtexamfee.Size = New System.Drawing.Size(170, 20)
        Me.Txtexamfee.TabIndex = 3
        '
        'Txtmonthfee
        '
        Me.Txtmonthfee.Location = New System.Drawing.Point(83, 20)
        Me.Txtmonthfee.Name = "Txtmonthfee"
        Me.Txtmonthfee.Size = New System.Drawing.Size(170, 20)
        Me.Txtmonthfee.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Exam fee"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(7, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "month Fee"
        '
        'Txtpaid
        '
        Me.Txtpaid.Location = New System.Drawing.Point(98, 45)
        Me.Txtpaid.Name = "Txtpaid"
        Me.Txtpaid.Size = New System.Drawing.Size(170, 20)
        Me.Txtpaid.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = " transport fees"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(7, 78)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Due fees"
        '
        'Txtdue
        '
        Me.Txtdue.Location = New System.Drawing.Point(98, 70)
        Me.Txtdue.Name = "Txtdue"
        Me.Txtdue.Size = New System.Drawing.Size(170, 20)
        Me.Txtdue.TabIndex = 7
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Txttransportfee)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Txtblnce)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Txtdue)
        Me.GroupBox3.Controls.Add(Me.Txtpaid)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 278)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(274, 122)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        '
        'Txttransportfee
        '
        Me.Txttransportfee.Location = New System.Drawing.Point(98, 18)
        Me.Txttransportfee.Name = "Txttransportfee"
        Me.Txttransportfee.Size = New System.Drawing.Size(170, 20)
        Me.Txttransportfee.TabIndex = 11
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Paid "
        '
        'Txtblnce
        '
        Me.Txtblnce.Location = New System.Drawing.Point(98, 96)
        Me.Txtblnce.Name = "Txtblnce"
        Me.Txtblnce.Size = New System.Drawing.Size(170, 20)
        Me.Txtblnce.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(3, 103)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "total Balance "
        '
        'Btnbrows
        '
        Me.Btnbrows.Location = New System.Drawing.Point(643, 328)
        Me.Btnbrows.Name = "Btnbrows"
        Me.Btnbrows.Size = New System.Drawing.Size(75, 23)
        Me.Btnbrows.TabIndex = 10
        Me.Btnbrows.Text = "Add Photo"
        Me.Btnbrows.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btnsave)
        Me.GroupBox4.Controls.Add(Me.Btnedt)
        Me.GroupBox4.Controls.Add(Me.Btndel)
        Me.GroupBox4.Controls.Add(Me.Btnadd)
        Me.GroupBox4.Location = New System.Drawing.Point(292, 322)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(327, 86)
        Me.GroupBox4.TabIndex = 11
        Me.GroupBox4.TabStop = False
        '
        'Btnsave
        '
        Me.Btnsave.Image = Global.school_management_system.My.Resources.Resources.Save
        Me.Btnsave.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsave.Location = New System.Drawing.Point(244, 9)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(75, 70)
        Me.Btnsave.TabIndex = 3
        Me.Btnsave.Text = "Save"
        Me.Btnsave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnedt
        '
        Me.Btnedt.Image = Global.school_management_system.My.Resources.Resources.download__4_
        Me.Btnedt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnedt.Location = New System.Drawing.Point(168, 7)
        Me.Btnedt.Name = "Btnedt"
        Me.Btnedt.Size = New System.Drawing.Size(75, 70)
        Me.Btnedt.TabIndex = 2
        Me.Btnedt.Text = "Edit"
        Me.Btnedt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnedt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnedt.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Image = Global.school_management_system.My.Resources.Resources.Remove
        Me.Btndel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btndel.Location = New System.Drawing.Point(87, 7)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(75, 70)
        Me.Btndel.TabIndex = 1
        Me.Btndel.Text = "Delete"
        Me.Btndel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btndel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Image = Global.school_management_system.My.Resources.Resources.download__3_
        Me.Btnadd.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnadd.Location = New System.Drawing.Point(6, 9)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(75, 70)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "New"
        Me.Btnadd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'Txtsearch
        '
        Me.Txtsearch.Location = New System.Drawing.Point(210, 414)
        Me.Txtsearch.Multiline = True
        Me.Txtsearch.Name = "Txtsearch"
        Me.Txtsearch.Size = New System.Drawing.Size(409, 41)
        Me.Txtsearch.TabIndex = 14
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(11, 461)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(741, 119)
        Me.DataGridView1.TabIndex = 18
        '
        'Btnexit
        '
        Me.Btnexit.Image = Global.school_management_system.My.Resources.Resources.Log_Out
        Me.Btnexit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnexit.Location = New System.Drawing.Point(110, 406)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(75, 49)
        Me.Btnexit.TabIndex = 17
        Me.Btnexit.Text = "Exit"
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnexit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Image = Global.school_management_system.My.Resources.Resources.delete1
        Me.Btnclear.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnclear.Location = New System.Drawing.Point(12, 406)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 49)
        Me.Btnclear.TabIndex = 16
        Me.Btnclear.Text = "Dispose"
        Me.Btnclear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'Btnsearch
        '
        Me.Btnsearch.Image = Global.school_management_system.My.Resources.Resources.images__1_
        Me.Btnsearch.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsearch.Location = New System.Drawing.Point(623, 414)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 41)
        Me.Btnsearch.TabIndex = 15
        Me.Btnsearch.Text = "Search"
        Me.Btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btnsearch.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Image = Global.school_management_system.My.Resources.Resources.person
        Me.PictureBox2.Location = New System.Drawing.Point(576, 155)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(167, 161)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.school_management_system.My.Resources.Resources.schoolmanagement3
        Me.PictureBox1.Location = New System.Drawing.Point(2, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(750, 148)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Location = New System.Drawing.Point(298, 278)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(261, 45)
        Me.GroupBox5.TabIndex = 19
        Me.GroupBox5.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(81, 16)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(166, 20)
        Me.DateTimePicker1.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Date"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label12.Location = New System.Drawing.Point(7, 125)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(166, 24)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Fees information"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'frmfees
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(755, 581)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Btnexit)
        Me.Controls.Add(Me.Btnclear)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.Txtsearch)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Btnbrows)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmfees"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frmfees"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtfnme As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txtnme As System.Windows.Forms.TextBox
    Friend WithEvents Txtcnic As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtdue As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txtpaid As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txtexamfee As System.Windows.Forms.TextBox
    Friend WithEvents Txtmonthfee As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txtlibraryfee As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtblnce As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txttransportfee As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Btnbrows As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnedt As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btnclear As System.Windows.Forms.Button
    Friend WithEvents Btnsearch As System.Windows.Forms.Button
    Friend WithEvents Txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
