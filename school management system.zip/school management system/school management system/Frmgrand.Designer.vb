﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmgrand
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Txtcnic = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txtterm3 = New System.Windows.Forms.TextBox()
        Me.Txtterm2 = New System.Windows.Forms.TextBox()
        Me.Txtterm1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Txtgrand = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Txtgrade = New System.Windows.Forms.TextBox()
        Me.Txtper = New System.Windows.Forms.TextBox()
        Me.Txtreslt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Btnbrows = New System.Windows.Forms.Button()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Txtsearch = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnedt = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.school_management_system.My.Resources.Resources.schoolmanagement3
        Me.PictureBox1.Location = New System.Drawing.Point(1, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(775, 150)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txtcnic)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Txtterm3)
        Me.GroupBox1.Controls.Add(Me.Txtterm2)
        Me.GroupBox1.Controls.Add(Me.Txtterm1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(1, 156)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(290, 148)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'Txtcnic
        '
        Me.Txtcnic.Location = New System.Drawing.Point(125, 19)
        Me.Txtcnic.Name = "Txtcnic"
        Me.Txtcnic.Size = New System.Drawing.Size(129, 20)
        Me.Txtcnic.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(27, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "cnic"
        '
        'Txtterm3
        '
        Me.Txtterm3.Location = New System.Drawing.Point(125, 119)
        Me.Txtterm3.Name = "Txtterm3"
        Me.Txtterm3.Size = New System.Drawing.Size(129, 20)
        Me.Txtterm3.TabIndex = 5
        '
        'Txtterm2
        '
        Me.Txtterm2.Location = New System.Drawing.Point(125, 87)
        Me.Txtterm2.Name = "Txtterm2"
        Me.Txtterm2.Size = New System.Drawing.Size(129, 20)
        Me.Txtterm2.TabIndex = 4
        '
        'Txtterm1
        '
        Me.Txtterm1.Location = New System.Drawing.Point(125, 51)
        Me.Txtterm1.Name = "Txtterm1"
        Me.Txtterm1.Size = New System.Drawing.Size(129, 20)
        Me.Txtterm1.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Final Term result"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Term2 result"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Term1 result"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txtgrand)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Txtgrade)
        Me.GroupBox2.Controls.Add(Me.Txtper)
        Me.GroupBox2.Controls.Add(Me.Txtreslt)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(316, 156)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(265, 148)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        '
        'Txtgrand
        '
        Me.Txtgrand.Location = New System.Drawing.Point(118, 51)
        Me.Txtgrand.Name = "Txtgrand"
        Me.Txtgrand.Size = New System.Drawing.Size(118, 20)
        Me.Txtgrand.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(23, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "total marks"
        '
        'Txtgrade
        '
        Me.Txtgrade.Location = New System.Drawing.Point(118, 115)
        Me.Txtgrade.Name = "Txtgrade"
        Me.Txtgrade.ReadOnly = True
        Me.Txtgrade.Size = New System.Drawing.Size(118, 20)
        Me.Txtgrade.TabIndex = 6
        '
        'Txtper
        '
        Me.Txtper.Location = New System.Drawing.Point(118, 80)
        Me.Txtper.Name = "Txtper"
        Me.Txtper.ReadOnly = True
        Me.Txtper.Size = New System.Drawing.Size(118, 20)
        Me.Txtper.TabIndex = 5
        '
        'Txtreslt
        '
        Me.Txtreslt.Location = New System.Drawing.Point(118, 16)
        Me.Txtreslt.Name = "Txtreslt"
        Me.Txtreslt.ReadOnly = True
        Me.Txtreslt.Size = New System.Drawing.Size(118, 20)
        Me.Txtreslt.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 122)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Grade"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 90)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Percentage"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Total result"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(1, 417)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(762, 152)
        Me.DataGridView1.TabIndex = 4
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Image = Global.school_management_system.My.Resources.Resources.person
        Me.PictureBox2.Location = New System.Drawing.Point(617, 157)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(126, 138)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 22
        Me.PictureBox2.TabStop = False
        '
        'Btnbrows
        '
        Me.Btnbrows.Location = New System.Drawing.Point(649, 301)
        Me.Btnbrows.Name = "Btnbrows"
        Me.Btnbrows.Size = New System.Drawing.Size(94, 28)
        Me.Btnbrows.TabIndex = 23
        Me.Btnbrows.Text = "Add Photo"
        Me.Btnbrows.UseVisualStyleBackColor = True
        '
        'Btnsearch
        '
        Me.Btnsearch.Image = Global.school_management_system.My.Resources.Resources.images__1_
        Me.Btnsearch.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsearch.Location = New System.Drawing.Point(171, 357)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 41)
        Me.Btnsearch.TabIndex = 27
        Me.Btnsearch.Text = "Search"
        Me.Btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btnsearch.UseVisualStyleBackColor = True
        '
        'Txtsearch
        '
        Me.Txtsearch.Location = New System.Drawing.Point(1, 357)
        Me.Txtsearch.Multiline = True
        Me.Txtsearch.Name = "Txtsearch"
        Me.Txtsearch.Size = New System.Drawing.Size(171, 41)
        Me.Txtsearch.TabIndex = 26
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Btnexit)
        Me.GroupBox5.Controls.Add(Me.Btnclear)
        Me.GroupBox5.Controls.Add(Me.Btnsave)
        Me.GroupBox5.Controls.Add(Me.Btnedt)
        Me.GroupBox5.Controls.Add(Me.Btndel)
        Me.GroupBox5.Controls.Add(Me.Btnadd)
        Me.GroupBox5.Location = New System.Drawing.Point(273, 332)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(490, 79)
        Me.GroupBox5.TabIndex = 28
        Me.GroupBox5.TabStop = False
        '
        'Btnexit
        '
        Me.Btnexit.Image = Global.school_management_system.My.Resources.Resources.Log_Out
        Me.Btnexit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnexit.Location = New System.Drawing.Point(409, 9)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(75, 70)
        Me.Btnexit.TabIndex = 14
        Me.Btnexit.Text = "Exit"
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnexit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Image = Global.school_management_system.My.Resources.Resources.delete1
        Me.Btnclear.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnclear.Location = New System.Drawing.Point(328, 9)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 70)
        Me.Btnclear.TabIndex = 13
        Me.Btnclear.Text = "Dispose"
        Me.Btnclear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'Btnsave
        '
        Me.Btnsave.Image = Global.school_management_system.My.Resources.Resources.Save
        Me.Btnsave.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsave.Location = New System.Drawing.Point(244, 9)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(75, 70)
        Me.Btnsave.TabIndex = 3
        Me.Btnsave.Text = "Save"
        Me.Btnsave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnedt
        '
        Me.Btnedt.Image = Global.school_management_system.My.Resources.Resources.download__4_
        Me.Btnedt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnedt.Location = New System.Drawing.Point(168, 7)
        Me.Btnedt.Name = "Btnedt"
        Me.Btnedt.Size = New System.Drawing.Size(75, 70)
        Me.Btnedt.TabIndex = 2
        Me.Btnedt.Text = "Edit"
        Me.Btnedt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnedt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnedt.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Image = Global.school_management_system.My.Resources.Resources.Remove
        Me.Btndel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btndel.Location = New System.Drawing.Point(87, 7)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(75, 70)
        Me.Btndel.TabIndex = 1
        Me.Btndel.Text = "Delete"
        Me.Btndel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btndel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Image = Global.school_management_system.My.Resources.Resources.download__3_
        Me.Btnadd.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnadd.Location = New System.Drawing.Point(6, 9)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(75, 70)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "New"
        Me.Btnadd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(52, 310)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 30)
        Me.Button1.TabIndex = 29
        Me.Button1.Text = "fill"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Frmgrand
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(775, 581)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.Txtsearch)
        Me.Controls.Add(Me.Btnbrows)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Frmgrand"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Frmgrand"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtterm2 As System.Windows.Forms.TextBox
    Friend WithEvents Txtterm1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtgrade As System.Windows.Forms.TextBox
    Friend WithEvents Txtper As System.Windows.Forms.TextBox
    Friend WithEvents Txtreslt As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txtcnic As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Txtgrand As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Btnbrows As System.Windows.Forms.Button
    Friend WithEvents Btnsearch As System.Windows.Forms.Button
    Friend WithEvents Txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btnclear As System.Windows.Forms.Button
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnedt As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Txtterm3 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
