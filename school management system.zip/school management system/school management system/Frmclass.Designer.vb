﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmclass
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txtclassid = New System.Windows.Forms.TextBox()
        Me.Txtclasnme = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Txtroom = New System.Windows.Forms.TextBox()
        Me.Txtsession = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Txtstd = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Txtsearch = New System.Windows.Forms.TextBox()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnedt = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Txtclasnme)
        Me.GroupBox1.Controls.Add(Me.Txtclassid)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 174)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(309, 108)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Class Id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Class Name"
        '
        'Txtclassid
        '
        Me.Txtclassid.Location = New System.Drawing.Point(117, 26)
        Me.Txtclassid.Name = "Txtclassid"
        Me.Txtclassid.Size = New System.Drawing.Size(165, 20)
        Me.Txtclassid.TabIndex = 2
        '
        'Txtclasnme
        '
        Me.Txtclasnme.Location = New System.Drawing.Point(117, 63)
        Me.Txtclasnme.Name = "Txtclasnme"
        Me.Txtclasnme.Size = New System.Drawing.Size(165, 20)
        Me.Txtclasnme.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Txtroom)
        Me.GroupBox2.Controls.Add(Me.Txtsession)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(363, 174)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(329, 115)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'Txtroom
        '
        Me.Txtroom.Location = New System.Drawing.Point(117, 63)
        Me.Txtroom.Name = "Txtroom"
        Me.Txtroom.Size = New System.Drawing.Size(165, 20)
        Me.Txtroom.TabIndex = 3
        '
        'Txtsession
        '
        Me.Txtsession.Location = New System.Drawing.Point(117, 26)
        Me.Txtsession.Name = "Txtsession"
        Me.Txtsession.Size = New System.Drawing.Size(165, 20)
        Me.Txtsession.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Room#"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Session"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Txtstd)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 288)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(309, 70)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'Txtstd
        '
        Me.Txtstd.Location = New System.Drawing.Point(117, 26)
        Me.Txtstd.Name = "Txtstd"
        Me.Txtstd.Size = New System.Drawing.Size(165, 20)
        Me.Txtstd.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(31, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "NO.of Students"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btnsave)
        Me.GroupBox4.Controls.Add(Me.Btnedt)
        Me.GroupBox4.Controls.Add(Me.Btndel)
        Me.GroupBox4.Controls.Add(Me.Btnadd)
        Me.GroupBox4.Location = New System.Drawing.Point(363, 288)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(329, 85)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(2, 439)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(748, 130)
        Me.DataGridView1.TabIndex = 17
        '
        'Txtsearch
        '
        Me.Txtsearch.Location = New System.Drawing.Point(213, 385)
        Me.Txtsearch.Multiline = True
        Me.Txtsearch.Name = "Txtsearch"
        Me.Txtsearch.Size = New System.Drawing.Size(393, 41)
        Me.Txtsearch.TabIndex = 14
        '
        'Btnsearch
        '
        Me.Btnsearch.Image = Global.school_management_system.My.Resources.Resources.images__1_
        Me.Btnsearch.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsearch.Location = New System.Drawing.Point(597, 385)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 41)
        Me.Btnsearch.TabIndex = 18
        Me.Btnsearch.Text = "Search"
        Me.Btnsearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btnsearch.UseVisualStyleBackColor = True
        '
        'Btnexit
        '
        Me.Btnexit.Image = Global.school_management_system.My.Resources.Resources.Log_Out
        Me.Btnexit.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnexit.Location = New System.Drawing.Point(111, 371)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(75, 62)
        Me.Btnexit.TabIndex = 16
        Me.Btnexit.Text = "Exit"
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnexit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Image = Global.school_management_system.My.Resources.Resources.delete1
        Me.Btnclear.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnclear.Location = New System.Drawing.Point(12, 371)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 62)
        Me.Btnclear.TabIndex = 15
        Me.Btnclear.Text = "Dispose"
        Me.Btnclear.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'Btnsave
        '
        Me.Btnsave.Image = Global.school_management_system.My.Resources.Resources.Save
        Me.Btnsave.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnsave.Location = New System.Drawing.Point(244, 9)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(75, 70)
        Me.Btnsave.TabIndex = 3
        Me.Btnsave.Text = "Save"
        Me.Btnsave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnsave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnedt
        '
        Me.Btnedt.Image = Global.school_management_system.My.Resources.Resources.download__4_
        Me.Btnedt.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnedt.Location = New System.Drawing.Point(168, 7)
        Me.Btnedt.Name = "Btnedt"
        Me.Btnedt.Size = New System.Drawing.Size(75, 70)
        Me.Btnedt.TabIndex = 2
        Me.Btnedt.Text = "Edit"
        Me.Btnedt.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnedt.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnedt.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Image = Global.school_management_system.My.Resources.Resources.Remove
        Me.Btndel.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btndel.Location = New System.Drawing.Point(87, 7)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(75, 70)
        Me.Btndel.TabIndex = 1
        Me.Btndel.Text = "Delete"
        Me.Btndel.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btndel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Image = Global.school_management_system.My.Resources.Resources.download__3_
        Me.Btnadd.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btnadd.Location = New System.Drawing.Point(6, 9)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(75, 70)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "New"
        Me.Btnadd.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btnadd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.school_management_system.My.Resources.Resources.schoolmanagement1
        Me.PictureBox1.Location = New System.Drawing.Point(2, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(759, 137)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.Location = New System.Drawing.Point(8, 114)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(169, 24)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Class information"
        '
        'Frmclass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(762, 581)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Btnexit)
        Me.Controls.Add(Me.Btnclear)
        Me.Controls.Add(Me.Txtsearch)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Frmclass"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Frmclass"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtclasnme As System.Windows.Forms.TextBox
    Friend WithEvents Txtclassid As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtroom As System.Windows.Forms.TextBox
    Friend WithEvents Txtsession As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Txtstd As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnedt As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btnclear As System.Windows.Forms.Button
    Friend WithEvents Txtsearch As System.Windows.Forms.TextBox
    Friend WithEvents Btnsearch As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
