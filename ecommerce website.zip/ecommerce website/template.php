<?php
   
		  function head()
		  {
			?>
			
			 
					  <div id="header">
						<div id="top">
							   <div id="top_main">
									<div id="top_left">
									Welcome visitor you can <a href="index.php?page=login">Login</a> or <a href="index.php?page=signup">create an account</a>
									</div>
									<div id="top_menu">
										<ul class="menu_contact">
										<li><a href=""><img src="img/Untitled.jpg" id="pic">Wish List(0)</li>
										<li><a href=""><img src="img/1.jpg" id="pic">My Account</li>
										<li><a href=""><img src="img/2.jpg" id="pic">Your Shopping</li>
										<li><a href=""><img src="img/3.jpg" id="pic">Finish Shopping</li>
										<li><a href=""><img src="img/4.jpg" id="pic">Call Us 0342-3483483</li>
										</ul>
									</div>
							   </div>
						  </div>
						  <div id="mid">
							<div id="mid_main">
							  <div id="mid_left"><a href=""><img src="img/logo.jpg"></a></div>
							  <div id="mid_center">
								<select style="width:40%;height:100%" id="opt">
								<option>All category</option>
								</select>
								<input type="text" placeholder="search..." style="width:59%;height:100%" id="text">
							  
							  </div>
							  <div id="mid_right"><img src="img/7.jpg" style="width:23%;height:82%">
							  <div id="a2"><b>SHOPPING CART</b></div>
							  <div id="a3">0 items(s) - PKR 0</div>
							  </div>
							</div>
						  </div>
						  
						  <div id="bottom">
						
							 <div id="bottom_main">
								<ul class="first_menu">
								   <li><a href="index.php">Home</a></li>
								   <li><a href="index.php?page=orderway">HOW TO ORDER</a></li>
								   <li><a href="index.php?page=quickorder">QUICK ORDER</a></li>
								   <li><a href="index.php?page=contactus">CONTACT US</a></li>
								   <li><a href="index.php?page=aboutus">ABOUT US</a></li>
								   
								   
								</ul>
							 </div>
						 </div> 
					</div>	 
		
			<?php
		  }
		 function cat()
		  {
		    ?>
				  <div id="center">
			  <div id="center_main">
				 
				 
				 <div id="left_menu">
					 <table cellpadding="0" cellspacing="0" width="99%" height="98%" id="tbl2">
					 <tr>
					 <td  id="a"><b>Categories</b></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">Brands</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">CLEARANCE SALE</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">Kitchen Appliances</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">Home Appliances</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">LIFE STYLE</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">MOBILE PHONES</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">PHOTOGRAPHY</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">TABLETS</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">AUDIO & MP3</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">TV & ENTERTAINMENT</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">TRAVEL BAGS</a></td>
					 </tr>
					  <tr>
					 <td id="b"><a href="">COMPUTING</a></td>
					 </tr>
					 </table>
				  </div>
				<?php
			 }
		function slider()
		{
			?>
			  
				  <div id="pic1"><img src="img/pic.jpg" style="width:100%;height:100%"></div>
			  </div>   
			</div>
			<?php
		}
		function products()
		{
		  ?>
		         
				 <div id="pro">
				   <div id="pro_main">
					 <div id="pro_menu">
					 <table  cellpadding="0" cellspacing="0" width="100%" height="100%" id="tbl3">
					 <tr>
					 <td id="menu1"><a href="">LATEST</a></td>
					 <td id="menu2"><a href="">BEST SELLER</a></td>
					 <td id="menu3"><a href="">MOST VIEWED</a></td>
					 </tr>
					 </table>
					 </div>
				  </div>
			  </div>
				 
			  <div id="pro_start">
				<div id="pro_start_main"> 
				 <div id="products">
					<div id="pro1">
					  <div id="img"><img src="img/pro.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>	
					
					<div id="pro1">
					  <div id="img"><img src="img/pro1.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>	
					
					<div id="pro1">
					  <div id="img"><img src="img/pro2.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>	
					
					<div id="pro1">
					  <div id="img"><img src="img/pro3.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>	
					
					<div id="pro1">
					  <div id="img"><img src="img/pro4.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>	
					
					<div id="pro1">
					  <div id="img"><img src="img/pro5.jpg" style="width:100%;height:100%"></div>
						<div id="txt">Oriflame ?Baby Kit 2
							 <div id="line"></div> 
						</div>
					  <div id="txt_bottom">
						<div id="txt1">PKR 1,350</div>
						<div id="txt2">ORDER NOW</div>
					  </div>
					  <div id="eye"><a href=""><img src="img/eye.jpg" style="width:60%;height:45%" id="eye_img" title="View"></a></div>
					  <div id="search1"><img src="img/search.png" style="width:110%;height:100%" id="search_img" title="Oriflame ?Baby Kit 2"></a></div>
					  <div id="heart"><a href=""><img src="img/heart.png" style="width:40%;height:40%" id="heart_img" title="Add to Wish List"></a></div>
					  <div id="search"><a href=""><img src="img/arrow.jpg" style="width:80%;height:70%" id="arrow_img" title="Add to Compare"></a></div>
					</div>
				  </div>
				</div>
			</div>	
		  <?php
		}
		function homecategory()
		{
		?>
		  <div id="pro_end">
			   <div id="pro2_end_main">  
					<div id="pro2">
						<a href=""><div id="shade"></div></a>
						<a href=""><img src="img/banner1212.png" style="width:100%;height:100%"></a>  
					</div>	
					<div id="pro2">
						 <a href=""><div id="shade"></div></a>
						 <a href=""><img src="img/banner1111.png" style="width:100%;height:100%"></a>
					</div>	
					<div id="pro2">
						   <a href=""><div id="shade"></div></a>
						  <a href=""><img src="img/banner2222.png" style="width:100%;height:100%"></a>
					</div>	
					<div id="pro2">
						  <a href=""><div id="shade"></div></a>
						 <a href=""><img src="img/banner3333.png" style="width:100%;height:100%"></a>
					</div>	
					<div id="pro2">
						  <a href=""><div id="shade"></div></a>
						  <a href=""><img src="img/banner4444.png" style="width:100%;height:100%"></a>
					</div>	
				</div>
			 </div>
		<?php
		}
		function newsletter()
		{
		 ?>
		    <div id="footer">
		       <div id="footer_main">
					  <div id="footer_left">
						 <div id="msg"><img src="img/msg.jpg" style="width:100%;height:100%"></div>
						 <div id="msg_txt">NEWSLETTER</div>
					  </div>
					   <div id="inbox">
						  <input type="text" name="input" id="input" style="width:70%;height:100%" placeholder="your email adress">
						  <input type="submit" name="submit" value="SUBSCRIBE" id="button" style="width:29%;height:100%">
					   </div>
					   <div id="link">
						<div id="link_txt">FOLLOW US ON</div>
						<a href=""><div id="link_fb">f</div> </a>
					   </div>
		        </div>
		     </div>
		 <?php
		}
			  
?>


	<?php
  
  
   function howorder()
   {
      ?>
       <div  style="width:80%;float:left;background:white">
<div id="order_detail">
  <strong>Placing Your First Order
Placing an order with saqiscity.com is easy. There's no need to create an account first. You automatically create an account when you place your first order online. (We accept orders by phone or e-mail.)<br />
Here are the steps you need to follow to place an order. If you have any problems when following these steps, please Contact  us +92 324 8442744 <br /><br />
 
1. Find the Items you want<br />
2. Add The Items to your Shopping cart by pressing the “Add To Cart” button on the right of the product page.<br />
3. Proceed to Checkout by pressing a button yet again on the right hand side of the page.<br />
4. Sign In / Create a New Account<br />
5. Enter Shipping Address<br />
6. Choose  Mode of Payment.
7. Review and Submit Your Order<br />
8. Check Your Order Status<br /><br />
9. Get a confirmation call by the saqiscity.com Sales team over the phone.<br /><br />
 
Note: Some items offered on our website are fulfilled by saqiscity.com Merchants or through saqiscity Partner Marketplace. Payment, shipping, and return policies may vary by type of order and by seller. Please call our support team for more help.<br />
1. Find the Items You Want<br />
First you will need to browse or search for the items you would like to order. Keyword search boxes are located on nearly every page of our store. You will also find links to browse lists and more detailed product-specific searches in the top navigation bar of each store. When you find an item that interests you, click the title or name of the item to see its product detail page. Here you will find more information about the item,<br />
If you don't find what you're looking for in one of our Saqiscity Stores, then get in touch with us as we can find what ever you need from all over the world at better then market price.<br /><br />
 
2. Add the Items to Your Shopping Cart<br />
If you want to order an item from saqiscity.com, click the "Add to Shopping Cart" button on the item's product detail page. Once you've added an item to your Shopping Cart, keep searching or browsing until your cart contains all of the items you want to order. You can access the contents of your Shopping Cart at any time by clicking at the top of every page of our website.<br />
3. Proceed to Checkout<br />
Take a moment to review all of the items you've placed in your Shopping Cart. When you're ready to place an order for everything in the "Shopping Cart Items--To Buy Now" section of your cart, click the "Proceed to checkout" button. You will be taken to the first page of the order form.<br />
The instructions below outline each step of our online order form. If at any point you encounter difficulty or receive an error message, please Contact Us +92 324 8442744<br /><br />
 
4. Sign In<br />
Enter your e-mail address. (Keep in mind that the e-mail address you provide here will be the only e-mail address to which we can send information about subsequent orders.) Indicate that you are a new customer.<br /><br />
 
5. Enter a Shipping Address<br />
Tell us where you would like to ship your order. We currently have TCS  as our partner courier company doing deliveries for us in over 1500 destinations in Pakistan.
If any remote area TCS Service not available then we will use another courier or cargo services.<br /><br />
  </strong> </div>
 
	 <?php
   }
  
   function quickorder()
   {
    ?>
	  we are working hard on quick order way it will complete soon 
	 <?php
   
   }
    function contactus()
   {
     ?>
	<strong>contact us using the email or mobile number, available top of the website.</strong>
<?php
   }
   function aboutus()
   {
     ?>
	  Its SHOPING Mall
	 <?php
   }
   function login()
   {
     ?>
	
	<form action="index.php"  method="post">
        <table border="0" cellpadding="5" cellspacing="5" align="center">
         <tr>
	  <td><b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">User Name:</b></td>
	   <td> <input type="text" name="user_name" style="width:180px;height:30px;background:#FFEFE8;font-size:16px;font-style:italic" /></td>
		</tr>
	   <tr>
	   <td><b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">Password:</b></td>
		<td> <input type="password" name="user_password" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
	  </tr>
	  <tr>
	  <td></td>
	    <td><input type="submit" value="Submit" style="width:80px;height:40px;border-radius:5px;background:#6F0037;color:#FFFFFF;font-size:18px"/></td>
	  </tr>
	  </table>
	</form>
	
	 <?php
   }
   function signup()
   {
     ?>
	 <div id="signup_div">
<form action="index.php" enctype="multipart/form-data" method="post" name="signup" onsubmit="return validateform()">

	 <table border="0" cellpadding="5" cellspacing="5" align="center">
	   <tr>
	       <td><b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">First Name:</b></td>
		   <td> <input type="text" name="first_name" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
		   <td><span id="optional_firstname"></span></td>
	   </tr>
	   <tr>
	       <td>  <b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">Last Name:</b></td>
		   <td> <input type="text" name="last_name" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
		   <td><span id="optional_lastname"></span></td>
	   </tr>
	   <tr>
	       <td> <b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">User Name:</b></td>
		   <td> <input type="text" name="user_name" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
		   <td><span id="optional_username"></span></td>
	   </tr>
	   <tr>
	       <td> <b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">Password:</b></td>
		   <td> <input type="password" name="user_password" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
		   <td><span id="optional_userpass"></span></td>
	   </tr>
	   <tr>
	       <td> <b style="font-family:sans-serif;font-size:22px;color:#97004B;text-decoration:underline">Re-enter Password:</b></td>
		   <td> <input type="password" name="reEnter_password" style="width:180px;height:30px;background:#FFEFE8;font-size:16px" /></td>
		   <td><span id="optional_reenterpass"></span></td>
	   </tr>
	   <tr>
	       <td>Gender</td>
		   <td><input type="radio" name="gen" id="gen" />Male<input type="radio" name="gen" id="gen" />FeMale</td>
	   </tr>
	   <tr>
	       <td>Country</td>
		   <td>
		   <select>
		     <option>Pakistan</option>
			 <option>Turkey</option>
			 <option>America</option>
			 <option>Germany</option>
			 <option>India</option>
			 <option>Australia</option>
			 <option>china</option>
		   </select>
		   </td>
	   </tr>
	    <tr>
	       <td> <input type="submit" value="create an account" style="width:180px;height:40px;border-radius:5px;background:#6F0037;color:#FFFFFF;font-size:18px" /> </td>
		   <td> <input type="reset" style="width:180px;height:40px;border-radius:5px;background:#6F0037;color:#FFFFFF;font-size:18px" /> </td>
	   </tr>
	 </table>


	  
	</form>
	</div>
	 <?php
   }
 
?>