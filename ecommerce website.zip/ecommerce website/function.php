<?php

   function check()
	  {

			if(!isset($_GET["page"]))
				 {
				       slider();
					   products();
				 }
			echo"<div id='check_main'>";
			echo"<div id='check_area'>";
			if($_GET["page"]=="orderway")
			    {


				 howorder();

				}
				else if($_GET["page"]=="quickorder")
			    {

				     quickorder();

				}
				else if($_GET["page"]=="aboutus")
			    {

				    aboutus();

				}
				else if($_GET["page"]=="contactus")
			    {

				     contactus();

				}
				else if($_GET["page"]=="login")
			    {

				     login();

				}
				else if($_GET["page"]=="signup")
			    {

				     signup();

				}
			echo"</div>";
			echo"</div>";
	  }
?>
