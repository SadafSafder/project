function validateform()
{
	if(document.signup.first_name.value=="")
	{
		document.getElementById('optional_firstname').innerHTML="enter first name";
		document.getElementById('optional_firstname').style.color="red";
		document.getElementById('optional_firstname').style.fontFamily="sans-serif";
		window.setTimeout("erase('optional_firstname')",4000);
		return false;
	}
	if(document.signup.last_name.value=="")
	{
		document.getElementById('optional_lastname').innerHTML="enter last name";
		document.getElementById('optional_lastname').style.color="red";
		document.getElementById('optional_lastname').style.fontFamily="sans-serif";
		window.setTimeout("erase('optional_lastname')",4000);
		return false;
	}
	if(document.signup.user_name.value=="")
	{
		document.getElementById('optional_username').innerHTML="enter  username";
		document.getElementById('optional_username').style.color="red";
		document.getElementById('optional_username').style.fontFamily="sans-serif";
		window.setTimeout("erase('optional_username')",4000);
		return false;
	}
	if(document.signup.user_password.value=="")
	{
		document.getElementById('optional_userpass').innerHTML="enter password";
		document.getElementById('optional_userpass').style.color="red";
		document.getElementById('optional_userpass').style.fontFamily="sans-serif";
		window.setTimeout("erase('optional_userpass')",4000);
		return false;
	}
	if(document.signup.reEnter_password.value=="")
	{
		document.getElementById('optional_reenterpass').innerHTML="reEnter password";
		document.getElementById('optional_reenterpass').style.color="red";
		document.getElementById('optional_reenterpass').style.fontFamily="sans-serif";
		window.setTimeout("erase('optional_reenterpass')",4000);
		return false;
	}
}
function erase(idd)
{
	document.getElementById(idd).innerHTML="";
}
