<html>
		  <head>
		<title>online shopping mall in pakistan</title>
		<link rel="stylesheet"  href="code.css">
		<script language="javascript" src="function.js"></script>
		</head>
		 <body >
<?php
   include("template.php");
   include("function.php");
?> 
			<div id="main">
			   <?php
			     head();
				 cat();
				 
				 check();
				
				 homecategory();
				 newsletter();
				 
			
			   ?>
			 
			</div>
		</body>
</html>
  