﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.FrmPurchaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FrmSaleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrmTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrmVouchersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FrmAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrmFlockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrmitemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'FrmPurchaseToolStripMenuItem
        '
        Me.FrmPurchaseToolStripMenuItem.Name = "FrmPurchaseToolStripMenuItem"
        Me.FrmPurchaseToolStripMenuItem.Size = New System.Drawing.Size(171, 134)
        Me.FrmPurchaseToolStripMenuItem.Text = "frmPurchase"
        '
        'FrmSaleToolStripMenuItem
        '
        Me.FrmSaleToolStripMenuItem.Name = "FrmSaleToolStripMenuItem"
        Me.FrmSaleToolStripMenuItem.Size = New System.Drawing.Size(117, 134)
        Me.FrmSaleToolStripMenuItem.Text = "FrmSale"
        '
        'FrmTransactionToolStripMenuItem
        '
        Me.FrmTransactionToolStripMenuItem.Name = "FrmTransactionToolStripMenuItem"
        Me.FrmTransactionToolStripMenuItem.Size = New System.Drawing.Size(204, 134)
        Me.FrmTransactionToolStripMenuItem.Text = "frm transaction"
        '
        'FrmVouchersToolStripMenuItem
        '
        Me.FrmVouchersToolStripMenuItem.Name = "FrmVouchersToolStripMenuItem"
        Me.FrmVouchersToolStripMenuItem.Size = New System.Drawing.Size(175, 134)
        Me.FrmVouchersToolStripMenuItem.Text = "FrmVouchers"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.LightBlue
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FrmAccountToolStripMenuItem, Me.FrmFlockToolStripMenuItem, Me.FrmitemToolStripMenuItem, Me.FrmTransactionToolStripMenuItem, Me.FrmPurchaseToolStripMenuItem, Me.FrmSaleToolStripMenuItem, Me.FrmVouchersToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 138)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FrmAccountToolStripMenuItem
        '
        Me.FrmAccountToolStripMenuItem.Name = "FrmAccountToolStripMenuItem"
        Me.FrmAccountToolStripMenuItem.Size = New System.Drawing.Size(166, 134)
        Me.FrmAccountToolStripMenuItem.Text = "FrmAccount"
        '
        'FrmFlockToolStripMenuItem
        '
        Me.FrmFlockToolStripMenuItem.Name = "FrmFlockToolStripMenuItem"
        Me.FrmFlockToolStripMenuItem.Size = New System.Drawing.Size(127, 134)
        Me.FrmFlockToolStripMenuItem.Text = "frmFlock"
        '
        'FrmitemToolStripMenuItem
        '
        Me.FrmitemToolStripMenuItem.Name = "FrmitemToolStripMenuItem"
        Me.FrmitemToolStripMenuItem.Size = New System.Drawing.Size(119, 134)
        Me.FrmitemToolStripMenuItem.Text = "frmitem"
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(108, 134)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightBlue
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, 141)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 254)
        Me.Panel1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(34, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(116, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Daily Status"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 413)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FrmPurchaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents FrmSaleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FrmTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FrmVouchersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FrmAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FrmFlockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FrmitemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
