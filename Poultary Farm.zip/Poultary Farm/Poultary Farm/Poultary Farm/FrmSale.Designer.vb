﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim SIdLabel As System.Windows.Forms.Label
        Dim RateLabel As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim QuantityLabel As System.Windows.Forms.Label
        Dim ItemLabel As System.Windows.Forms.Label
        Dim DetailLabel As System.Windows.Forms.Label
        Dim AmountLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Me.QuantityTextBox = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.DetailTextBox = New System.Windows.Forms.TextBox()
        Me.ItemTextBox = New System.Windows.Forms.ComboBox()
        Me.SIdTextBox = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.AmountTextBox = New System.Windows.Forms.TextBox()
        Me.RateTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.BtnParty = New System.Windows.Forms.Button()
        Me.datetxt = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        SIdLabel = New System.Windows.Forms.Label()
        RateLabel = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        QuantityLabel = New System.Windows.Forms.Label()
        ItemLabel = New System.Windows.Forms.Label()
        DetailLabel = New System.Windows.Forms.Label()
        AmountLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SIdLabel
        '
        SIdLabel.AutoSize = True
        SIdLabel.Location = New System.Drawing.Point(28, 271)
        SIdLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        SIdLabel.Name = "SIdLabel"
        SIdLabel.Size = New System.Drawing.Size(28, 15)
        SIdLabel.TabIndex = 0
        SIdLabel.Text = "SId"
        '
        'RateLabel
        '
        RateLabel.AutoSize = True
        RateLabel.Location = New System.Drawing.Point(595, 295)
        RateLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        RateLabel.Name = "RateLabel"
        RateLabel.Size = New System.Drawing.Size(37, 15)
        RateLabel.TabIndex = 3
        RateLabel.Text = "Rate"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.ForeColor = System.Drawing.Color.Red
        Label4.Location = New System.Drawing.Point(235, 374)
        Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(213, 15)
        Label4.TabIndex = 169
        Label4.Text = "(Please Enter Amount Without dashes"
        '
        'QuantityLabel
        '
        QuantityLabel.AutoSize = True
        QuantityLabel.Location = New System.Drawing.Point(17, 336)
        QuantityLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        QuantityLabel.Name = "QuantityLabel"
        QuantityLabel.Size = New System.Drawing.Size(59, 15)
        QuantityLabel.TabIndex = 4
        QuantityLabel.Text = "Quantity"
        '
        'ItemLabel
        '
        ItemLabel.AutoSize = True
        ItemLabel.Location = New System.Drawing.Point(23, 301)
        ItemLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        ItemLabel.Name = "ItemLabel"
        ItemLabel.Size = New System.Drawing.Size(35, 15)
        ItemLabel.TabIndex = 2
        ItemLabel.Text = "Item"
        '
        'DetailLabel
        '
        DetailLabel.AutoSize = True
        DetailLabel.Location = New System.Drawing.Point(589, 376)
        DetailLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        DetailLabel.Name = "DetailLabel"
        DetailLabel.Size = New System.Drawing.Size(45, 15)
        DetailLabel.TabIndex = 6
        DetailLabel.Text = "Detail"
        '
        'AmountLabel
        '
        AmountLabel.AutoSize = True
        AmountLabel.Location = New System.Drawing.Point(17, 425)
        AmountLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        AmountLabel.Name = "AmountLabel"
        AmountLabel.Size = New System.Drawing.Size(55, 15)
        AmountLabel.TabIndex = 5
        AmountLabel.Text = "Amount"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(577, 263)
        AccNameLabel.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(103, 15)
        AccNameLabel.TabIndex = 1
        AccNameLabel.Text = "Account Name:"
        '
        'QuantityTextBox
        '
        Me.QuantityTextBox.Location = New System.Drawing.Point(141, 332)
        Me.QuantityTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.QuantityTextBox.Name = "QuantityTextBox"
        Me.QuantityTextBox.Size = New System.Drawing.Size(376, 21)
        Me.QuantityTextBox.TabIndex = 2
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(324, 21)
        Me.Button3.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(145, 45)
        Me.Button3.TabIndex = 2
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'DetailTextBox
        '
        Me.DetailTextBox.Location = New System.Drawing.Point(723, 322)
        Me.DetailTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.DetailTextBox.Multiline = True
        Me.DetailTextBox.Name = "DetailTextBox"
        Me.DetailTextBox.Size = New System.Drawing.Size(385, 132)
        Me.DetailTextBox.TabIndex = 6
        '
        'ItemTextBox
        '
        Me.ItemTextBox.FormattingEnabled = True
        Me.ItemTextBox.Location = New System.Drawing.Point(141, 301)
        Me.ItemTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.ItemTextBox.Name = "ItemTextBox"
        Me.ItemTextBox.Size = New System.Drawing.Size(376, 23)
        Me.ItemTextBox.TabIndex = 3
        '
        'SIdTextBox
        '
        Me.SIdTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.SIdTextBox.Location = New System.Drawing.Point(141, 271)
        Me.SIdTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.SIdTextBox.Name = "SIdTextBox"
        Me.SIdTextBox.Size = New System.Drawing.Size(376, 21)
        Me.SIdTextBox.TabIndex = 0
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(11, 16)
        Me.Button4.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(145, 45)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(300, 462)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(657, 73)
        Me.GroupBox1.TabIndex = 168
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(167, 16)
        Me.Button2.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(145, 45)
        Me.Button2.TabIndex = 1
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(480, 16)
        Me.Button6.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(140, 45)
        Me.Button6.TabIndex = 3
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(4, 541)
        Me.dgv.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(1279, 313)
        Me.dgv.TabIndex = 167
        Me.dgv.TabStop = False
        '
        'AmountTextBox
        '
        Me.AmountTextBox.Location = New System.Drawing.Point(141, 417)
        Me.AmountTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.AmountTextBox.Name = "AmountTextBox"
        Me.AmountTextBox.Size = New System.Drawing.Size(376, 21)
        Me.AmountTextBox.TabIndex = 5
        Me.AmountTextBox.TabStop = False
        '
        'RateTextBox
        '
        Me.RateTextBox.Location = New System.Drawing.Point(724, 292)
        Me.RateTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.RateTextBox.Name = "RateTextBox"
        Me.RateTextBox.Size = New System.Drawing.Size(365, 21)
        Me.RateTextBox.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-425, -240)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 159
        Me.Label1.Text = "Label1"
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.Location = New System.Drawing.Point(723, 263)
        Me.AccNameTextBox.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(367, 21)
        Me.AccNameTextBox.TabIndex = 2
        '
        'BtnParty
        '
        Me.BtnParty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnParty.Location = New System.Drawing.Point(1088, 258)
        Me.BtnParty.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnParty.Name = "BtnParty"
        Me.BtnParty.Size = New System.Drawing.Size(109, 27)
        Me.BtnParty.TabIndex = 1
        Me.BtnParty.Text = "Party"
        Me.BtnParty.UseVisualStyleBackColor = True
        '
        'datetxt
        '
        Me.datetxt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datetxt.Location = New System.Drawing.Point(833, 192)
        Me.datetxt.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.datetxt.Name = "datetxt"
        Me.datetxt.Size = New System.Drawing.Size(169, 21)
        Me.datetxt.TabIndex = 723
        Me.datetxt.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(4, -6)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox5.Size = New System.Drawing.Size(1279, 167)
        Me.GroupBox5.TabIndex = 730
        Me.GroupBox5.TabStop = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label11.Location = New System.Drawing.Point(816, 29)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(304, 113)
        Me.Label11.TabIndex = 721
        Me.Label11.Text = "ITEMS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Poultary_Farm.My.Resources.Resources._0d772a6d2f2a1c20f15a28b78a4b1f56
        Me.PictureBox1.Location = New System.Drawing.Point(8, 10)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(277, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(607, 29)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(224, 113)
        Me.Label3.TabIndex = 720
        Me.Label3.Text = "SALE"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FrmSale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1281, 741)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.datetxt)
        Me.Controls.Add(Me.BtnParty)
        Me.Controls.Add(Me.AccNameTextBox)
        Me.Controls.Add(AccNameLabel)
        Me.Controls.Add(Me.QuantityTextBox)
        Me.Controls.Add(SIdLabel)
        Me.Controls.Add(Me.DetailTextBox)
        Me.Controls.Add(Me.ItemTextBox)
        Me.Controls.Add(Me.SIdTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.AmountTextBox)
        Me.Controls.Add(Me.RateTextBox)
        Me.Controls.Add(RateLabel)
        Me.Controls.Add(Label4)
        Me.Controls.Add(QuantityLabel)
        Me.Controls.Add(ItemLabel)
        Me.Controls.Add(DetailLabel)
        Me.Controls.Add(AmountLabel)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmSale"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmSale"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents QuantityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents DetailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ItemTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents SIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents AmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BtnParty As System.Windows.Forms.Button
    Friend WithEvents datetxt As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
