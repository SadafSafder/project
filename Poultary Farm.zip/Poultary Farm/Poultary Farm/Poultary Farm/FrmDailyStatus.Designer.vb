﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDailyStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim FlockNoLabel As System.Windows.Forms.Label
        Dim ProdNoOfEggsLabel As System.Windows.Forms.Label
        Dim FeedLabel As System.Windows.Forms.Label
        Dim FeedPerBirdLabel As System.Windows.Forms.Label
        Dim MortalityLabel As System.Windows.Forms.Label
        Dim CurrentDateLabel As System.Windows.Forms.Label
        Dim PreQtyLabel As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim EggProductionPercentageLabel As System.Windows.Forms.Label
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ProdOfEggsTextBox = New System.Windows.Forms.TextBox()
        Me.PreQtyTextBox = New System.Windows.Forms.TextBox()
        Me.FeedPerBirdTextBox = New System.Windows.Forms.TextBox()
        Me.FlockNoTextBox = New System.Windows.Forms.ComboBox()
        Me.FeedTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CurrentDate = New System.Windows.Forms.DateTimePicker()
        Me.MortalityTextBox = New System.Windows.Forms.TextBox()
        Me.EggProdcutionPercentageTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        FlockNoLabel = New System.Windows.Forms.Label()
        ProdNoOfEggsLabel = New System.Windows.Forms.Label()
        FeedLabel = New System.Windows.Forms.Label()
        FeedPerBirdLabel = New System.Windows.Forms.Label()
        MortalityLabel = New System.Windows.Forms.Label()
        CurrentDateLabel = New System.Windows.Forms.Label()
        PreQtyLabel = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        EggProductionPercentageLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlockNoLabel
        '
        FlockNoLabel.AutoSize = True
        FlockNoLabel.Location = New System.Drawing.Point(40, 248)
        FlockNoLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FlockNoLabel.Name = "FlockNoLabel"
        FlockNoLabel.Size = New System.Drawing.Size(50, 13)
        FlockNoLabel.TabIndex = 0
        FlockNoLabel.Text = "FlockNo:"
        '
        'ProdNoOfEggsLabel
        '
        ProdNoOfEggsLabel.AutoSize = True
        ProdNoOfEggsLabel.Location = New System.Drawing.Point(536, 299)
        ProdNoOfEggsLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        ProdNoOfEggsLabel.Name = "ProdNoOfEggsLabel"
        ProdNoOfEggsLabel.Size = New System.Drawing.Size(116, 13)
        ProdNoOfEggsLabel.TabIndex = 4
        ProdNoOfEggsLabel.Text = "Production No Of Eggs"
        '
        'FeedLabel
        '
        FeedLabel.AutoSize = True
        FeedLabel.Location = New System.Drawing.Point(34, 280)
        FeedLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FeedLabel.Name = "FeedLabel"
        FeedLabel.Size = New System.Drawing.Size(52, 13)
        FeedLabel.TabIndex = 1
        FeedLabel.Text = "Feed(KG)"
        '
        'FeedPerBirdLabel
        '
        FeedPerBirdLabel.AutoSize = True
        FeedPerBirdLabel.Location = New System.Drawing.Point(11, 306)
        FeedPerBirdLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FeedPerBirdLabel.Name = "FeedPerBirdLabel"
        FeedPerBirdLabel.Size = New System.Drawing.Size(109, 13)
        FeedPerBirdLabel.TabIndex = 3
        FeedPerBirdLabel.Text = "Feed Per Bird(GRAM)"
        '
        'MortalityLabel
        '
        MortalityLabel.AutoSize = True
        MortalityLabel.Location = New System.Drawing.Point(40, 332)
        MortalityLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        MortalityLabel.Name = "MortalityLabel"
        MortalityLabel.Size = New System.Drawing.Size(46, 13)
        MortalityLabel.TabIndex = 5
        MortalityLabel.Text = "Mortality"
        '
        'CurrentDateLabel
        '
        CurrentDateLabel.AutoSize = True
        CurrentDateLabel.Location = New System.Drawing.Point(589, 243)
        CurrentDateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        CurrentDateLabel.Name = "CurrentDateLabel"
        CurrentDateLabel.Size = New System.Drawing.Size(30, 13)
        CurrentDateLabel.TabIndex = 7
        CurrentDateLabel.Text = "Date"
        '
        'PreQtyLabel
        '
        PreQtyLabel.AutoSize = True
        PreQtyLabel.Location = New System.Drawing.Point(562, 273)
        PreQtyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        PreQtyLabel.Name = "PreQtyLabel"
        PreQtyLabel.Size = New System.Drawing.Size(90, 13)
        PreQtyLabel.TabIndex = 2
        PreQtyLabel.Text = "Previous Quantity"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(401, 210)
        Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(0, 13)
        Label4.TabIndex = 157
        '
        'EggProductionPercentageLabel
        '
        EggProductionPercentageLabel.AutoSize = True
        EggProductionPercentageLabel.Location = New System.Drawing.Point(536, 325)
        EggProductionPercentageLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        EggProductionPercentageLabel.Name = "EggProductionPercentageLabel"
        EggProductionPercentageLabel.Size = New System.Drawing.Size(109, 13)
        EggProductionPercentageLabel.TabIndex = 6
        EggProductionPercentageLabel.Text = "Egg Production %age"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(242, 14)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 2
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'ProdOfEggsTextBox
        '
        Me.ProdOfEggsTextBox.Location = New System.Drawing.Point(667, 299)
        Me.ProdOfEggsTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ProdOfEggsTextBox.Name = "ProdOfEggsTextBox"
        Me.ProdOfEggsTextBox.Size = New System.Drawing.Size(211, 20)
        Me.ProdOfEggsTextBox.TabIndex = 4
        '
        'PreQtyTextBox
        '
        Me.PreQtyTextBox.Location = New System.Drawing.Point(667, 273)
        Me.PreQtyTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PreQtyTextBox.Name = "PreQtyTextBox"
        Me.PreQtyTextBox.ReadOnly = True
        Me.PreQtyTextBox.Size = New System.Drawing.Size(211, 20)
        Me.PreQtyTextBox.TabIndex = 2
        '
        'FeedPerBirdTextBox
        '
        Me.FeedPerBirdTextBox.Location = New System.Drawing.Point(143, 306)
        Me.FeedPerBirdTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FeedPerBirdTextBox.Name = "FeedPerBirdTextBox"
        Me.FeedPerBirdTextBox.Size = New System.Drawing.Size(240, 20)
        Me.FeedPerBirdTextBox.TabIndex = 3
        '
        'FlockNoTextBox
        '
        Me.FlockNoTextBox.FormattingEnabled = True
        Me.FlockNoTextBox.Location = New System.Drawing.Point(143, 240)
        Me.FlockNoTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FlockNoTextBox.Name = "FlockNoTextBox"
        Me.FlockNoTextBox.Size = New System.Drawing.Size(240, 21)
        Me.FlockNoTextBox.TabIndex = 0
        '
        'FeedTextBox
        '
        Me.FeedTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.FeedTextBox.Location = New System.Drawing.Point(143, 280)
        Me.FeedTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FeedTextBox.Name = "FeedTextBox"
        Me.FeedTextBox.Size = New System.Drawing.Size(240, 20)
        Me.FeedTextBox.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(241, 393)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 150
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 1
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 3
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(1, 462)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(953, 276)
        Me.dgv.TabIndex = 149
        Me.dgv.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-301, -214)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Label1"
        '
        'CurrentDate
        '
        Me.CurrentDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.CurrentDate.Location = New System.Drawing.Point(667, 247)
        Me.CurrentDate.Name = "CurrentDate"
        Me.CurrentDate.Size = New System.Drawing.Size(211, 20)
        Me.CurrentDate.TabIndex = 7
        '
        'MortalityTextBox
        '
        Me.MortalityTextBox.Location = New System.Drawing.Point(143, 332)
        Me.MortalityTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MortalityTextBox.Name = "MortalityTextBox"
        Me.MortalityTextBox.Size = New System.Drawing.Size(240, 20)
        Me.MortalityTextBox.TabIndex = 6
        '
        'EggProdcutionPercentageTextBox
        '
        Me.EggProdcutionPercentageTextBox.Location = New System.Drawing.Point(667, 325)
        Me.EggProdcutionPercentageTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.EggProdcutionPercentageTextBox.Name = "EggProdcutionPercentageTextBox"
        Me.EggProdcutionPercentageTextBox.ReadOnly = True
        Me.EggProdcutionPercentageTextBox.Size = New System.Drawing.Size(211, 20)
        Me.EggProdcutionPercentageTextBox.TabIndex = 5
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(1, 0)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(959, 145)
        Me.GroupBox5.TabIndex = 730
        Me.GroupBox5.TabStop = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label11.Location = New System.Drawing.Point(556, 26)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(327, 98)
        Me.Label11.TabIndex = 721
        Me.Label11.Text = "VOUCHERS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(272, 26)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(300, 98)
        Me.Label3.TabIndex = 720
        Me.Label3.Text = "PAYMENT"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Poultary_Farm.My.Resources.Resources._0d772a6d2f2a1c20f15a28b78a4b1f56
        Me.PictureBox1.Location = New System.Drawing.Point(6, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(208, 130)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'FrmDailyStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(955, 741)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.EggProdcutionPercentageTextBox)
        Me.Controls.Add(EggProductionPercentageLabel)
        Me.Controls.Add(Label4)
        Me.Controls.Add(PreQtyLabel)
        Me.Controls.Add(Me.MortalityTextBox)
        Me.Controls.Add(Me.CurrentDate)
        Me.Controls.Add(CurrentDateLabel)
        Me.Controls.Add(FlockNoLabel)
        Me.Controls.Add(Me.ProdOfEggsTextBox)
        Me.Controls.Add(Me.PreQtyTextBox)
        Me.Controls.Add(Me.FeedPerBirdTextBox)
        Me.Controls.Add(Me.FlockNoTextBox)
        Me.Controls.Add(Me.FeedTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(ProdNoOfEggsLabel)
        Me.Controls.Add(FeedLabel)
        Me.Controls.Add(FeedPerBirdLabel)
        Me.Controls.Add(MortalityLabel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmDailyStatus"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmDailyStatus"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ProdOfEggsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PreQtyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FeedPerBirdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FlockNoTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents FeedTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CurrentDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents MortalityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EggProdcutionPercentageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
