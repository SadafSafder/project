﻿Imports System.Data.SqlClient

Public Class FrmDailyStatus
    'Public Property val As String
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable




    Private Sub FrmDailyStatus_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
        FillItemCombo()
        ' val = PreQtyTextBox.Text
        'Dim da As New SqlDataAdapter("SELECT * FROM Items", con)
        ' da.Fill(dt)
        'PreQtyTextBox.Text = dt.Rows(0)("Quality").ToString()
    End Sub
    Private Sub selectBirdsQuantity()
        Try
            cmdsql.Connection = con
            cmdsql.CommandText = "select CurrentQty from Flockk where FlockNo='" & FlockNoTextBox.Text & "'"
            PreQtyTextBox.Text = cmdsql.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub insertion()
        Try
            cmdsql.Connection = con

            cmdsql.CommandText = "INSERT INTO  DailyStatus (FlockNo,CurrentDate,PreQty,FeedPerBird,TotalFeed,EggProduction,Mortality) VALUES  ('" & FlockNoTextBox.Text & "','" & CurrentDate.Text & "','" & PreQtyTextBox.Text & "','" & FeedPerBirdTextBox.Text & "','" & FeedTextBox.Text & "','" & ProdOfEggsTextBox.Text & "','" & MortalityTextBox.Text & "'  )"

            cmdsql.ExecuteNonQuery()




        Catch ex As Exception
            MsgBox("Please Enter Data in correct Format" & ex.Message)

        End Try



    End Sub

    Private Sub FillItemCombo()
        Try

            Dim dasql As New SqlClient.SqlDataAdapter("select * from Flockk order by FlockNo", con)
            Dim dt As New DataTable
            dasql.Fill(dt)
            If dt.Rows.Count > 0 Then
                FlockNoTextBox.DataSource = dt
                FlockNoTextBox.DisplayMember = "FlockNo"
            End If
        Catch ex As Exception

        End Try

    End Sub

   
    Private Sub SqlGridView()
        Try
            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM DailyStatus order by FlockNo  ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
    Function CLEAR_CONTROL()
        FlockNoTextBox.DataBindings.Clear()
        CurrentDate.DataBindings.Clear()
        PreQtyTextBox.DataBindings.Clear()
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        FeedPerBirdTextBox.DataBindings.Clear()
        FeedTextBox.DataBindings.Clear()
        ProdOfEggsTextBox.DataBindings.Clear()
        MortalityTextBox.DataBindings.Clear()

        FlockNoTextBox.Text = ""
        CurrentDate.Text = ""
        PreQtyTextBox.Text = ""
        FeedPerBirdTextBox.Text = ""
        FeedTextBox.Text = ""
        ProdOfEggsTextBox.Text = ""
        MortalityTextBox.Text = ""



        Return 0
    End Function
    Private Sub CalculateFeed()
        Try

            Dim fd As Integer
            Dim birdsQty As Integer
            Dim feed As Integer
            fd = FeedTextBox.Text
            birdsQty = PreQtyTextBox.Text
            feed = fd * 1000 / birdsQty
            FeedPerBirdTextBox.Text = feed
        Catch ex As Exception

        End Try

    End Sub
    Private Sub CalculateEggs()
        Try

       
        Dim eggs As Integer
        Dim birdsQty As Integer
        Dim per As Integer
        eggs = ProdOfEggsTextBox.Text
        birdsQty = PreQtyTextBox.Text
        per = eggs / birdsQty * 100
            EggProdcutionPercentageTextBox.Text = per
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If FlockNoTextBox.Text <> "" Then

            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please fill All Information..!!")
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If FlockNoTextBox.Text <> "" Then


            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM DailyStatus WHERE FlockNo= '" & FlockNoTextBox.Text & "' "
                cmdsql.ExecuteNonQuery()
                '        MsgBox("Delete Successfuly")

                CLEAR_CONTROL()
                SqlGridView()



            Else : result = DialogResult.No
                MsgBox("Delete Cancel")
            End If
        Else
            MsgBox("Please Select Any accounts !!!")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
    End Sub
    Private Sub updation()
        Try


            cmdsql.Connection = con
            cmdsql.CommandText = "update DailyStatus set  CurrentDate='" & CurrentDate.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  DailyStatus set  PreQty= '" & PreQtyTextBox.Text & "'  where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  DailyStatus  set   FeedPerBird='" & FeedPerBirdTextBox.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  DailyStatus  set   TotalFeed='" & FeedTextBox.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update DailyStatus set   EggProduction='" & ProdOfEggsTextBox.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()
            cmdsql.Connection = con
            cmdsql.CommandText = "update DailyStatus set   Mortality='" & MortalityTextBox.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(" Please Enter Data in Correct Format" & ex.Message)
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        updation()
        CLEAR_CONTROL()
        SqlGridView()
    End Sub
    Private Sub boxvalue()
        Try



            CLEAR_CONTROL()
            FlockNoTextBox.DataBindings.Add("text", dt, "FlockNo")
            CurrentDate.DataBindings.Add("text", dt, "CurrentDate")
            '  Obalancetxt.DataBindings.Add("text", dt, "balance")
            PreQtyTextBox.DataBindings.Add("text", dt, "PreQty")
            FeedPerBirdTextBox.DataBindings.Add("text", dt, "FeedPerBird")
            FeedTextBox.DataBindings.Add("text", dt, "TotalFeed")
            ProdOfEggsTextBox.DataBindings.Add("text", dt, "EggProduction")
            MortalityTextBox.DataBindings.Add("text", dt, "Mortality")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
    End Sub

    Private Sub PreQtyTextBox_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PreQtyTextBox.MouseClick

    End Sub


    Private Sub FlockNoTextBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlockNoTextBox.SelectedIndexChanged
        selectBirdsQuantity()
    End Sub

    Private Sub FeedPerBirdTextBox_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FeedPerBirdTextBox.Click
        ' CalculateFeed()
    End Sub

    Private Sub FeedPerBirdTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeedPerBirdTextBox.TextChanged

    End Sub

    Private Sub EggProdcutionPercentageTextBox_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EggProdcutionPercentageTextBox.Click
        ' CalculateEggs()
    End Sub

    Private Sub EggProdcutionPercentageTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EggProdcutionPercentageTextBox.TextChanged

    End Sub

    Private Sub FeedTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FeedTextBox.TextChanged
        CalculateFeed()
    End Sub

    Private Sub PreQtyTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PreQtyTextBox.TextChanged
        CalculateEggs()
        CalculateFeed()
    End Sub

    Private Sub ProdOfEggsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProdOfEggsTextBox.TextChanged
        CalculateEggs()
    End Sub
End Class