﻿Public Class AccSearch


    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt5 As New DataTable


    Private Sub SqlGridView()
        Try


            dt5.Clear()

            Dim daSql As New SqlClient.SqlDataAdapter("SELECT AccNO,AccName FROM Accounts  ", con)

            daSql.Fill(dt5)
            Me.dgv.DataSource = dt5
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub AccSearch_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then

            Try
                Dim dr As DataGridViewRow = dgv.SelectedRows(0)
                Me.Hide()



                'FrmContract.AccNoTextBox.Text = dr.Cells(0).Value()
                'FrmContract.AccNameTextBox.Text = dr.Cells(1).Value()





                If FrmVouchers.fr = True Then
                    FrmVouchers.AccNameTextbox.Text = dr.Cells(1).Value()
                    FrmVouchers.fr = False

                    Me.Close()

                End If

                If FrmVouchers.tr = True Then
                    FrmVouchers.AccNameTotxt.Text = dr.Cells(1).Value()
                    FrmVouchers.tr = False

                    Me.Close()
                End If

                'FrmPayVouchers.DataGridView1.Rows.Add(dr.Cells(1).Value())

                Me.Close()

                TextBox1.Text = ""
                dt5.Clear()

                '  consql.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub


    Private Sub AccSearch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SqlGridView()

        Me.KeyPreview = True
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Try


            dt5.Clear()

            Dim daSql As New SqlClient.SqlDataAdapter("SELECT AccNO,AccName FROM Accounts where AccName like '%" & TextBox1.Text & "%'  ", con)

            daSql.Fill(dt5)
            Me.dgv.DataSource = dt5
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class