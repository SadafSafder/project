﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFlocks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim FlockNoLabel As System.Windows.Forms.Label
        Dim FarmNameLabel As System.Windows.Forms.Label
        Dim AccHolderLabel As System.Windows.Forms.Label
        Dim OwnerLabel As System.Windows.Forms.Label
        Dim BirdsQtyLabel As System.Windows.Forms.Label
        Dim CurrentQtyLabel As System.Windows.Forms.Label
        Me.FarmNameTextBox = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.OwnerTextBox = New System.Windows.Forms.TextBox()
        Me.FlockNoTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.BirdsQtyTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StartDate = New System.Windows.Forms.DateTimePicker()
        Me.CurrentQtyTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        FlockNoLabel = New System.Windows.Forms.Label()
        FarmNameLabel = New System.Windows.Forms.Label()
        AccHolderLabel = New System.Windows.Forms.Label()
        OwnerLabel = New System.Windows.Forms.Label()
        BirdsQtyLabel = New System.Windows.Forms.Label()
        CurrentQtyLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FlockNoLabel
        '
        FlockNoLabel.AutoSize = True
        FlockNoLabel.Location = New System.Drawing.Point(40, 184)
        FlockNoLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FlockNoLabel.Name = "FlockNoLabel"
        FlockNoLabel.Size = New System.Drawing.Size(53, 13)
        FlockNoLabel.TabIndex = 0
        FlockNoLabel.Text = "Flock No:"
        '
        'FarmNameLabel
        '
        FarmNameLabel.AutoSize = True
        FarmNameLabel.Location = New System.Drawing.Point(40, 234)
        FarmNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        FarmNameLabel.Name = "FarmNameLabel"
        FarmNameLabel.Size = New System.Drawing.Size(64, 13)
        FarmNameLabel.TabIndex = 2
        FarmNameLabel.Text = "Farm Name:"
        '
        'AccHolderLabel
        '
        AccHolderLabel.AutoSize = True
        AccHolderLabel.Location = New System.Drawing.Point(495, 184)
        AccHolderLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccHolderLabel.Name = "AccHolderLabel"
        AccHolderLabel.Size = New System.Drawing.Size(55, 13)
        AccHolderLabel.TabIndex = 1
        AccHolderLabel.Text = "Start Date"
        '
        'OwnerLabel
        '
        OwnerLabel.AutoSize = True
        OwnerLabel.Location = New System.Drawing.Point(40, 290)
        OwnerLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        OwnerLabel.Name = "OwnerLabel"
        OwnerLabel.Size = New System.Drawing.Size(38, 13)
        OwnerLabel.TabIndex = 5
        OwnerLabel.Text = "Owner"
        '
        'BirdsQtyLabel
        '
        BirdsQtyLabel.AutoSize = True
        BirdsQtyLabel.Location = New System.Drawing.Point(493, 237)
        BirdsQtyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        BirdsQtyLabel.Name = "BirdsQtyLabel"
        BirdsQtyLabel.Size = New System.Drawing.Size(72, 13)
        BirdsQtyLabel.TabIndex = 3
        BirdsQtyLabel.Text = "Birds Quantity"
        '
        'CurrentQtyLabel
        '
        CurrentQtyLabel.AutoSize = True
        CurrentQtyLabel.Location = New System.Drawing.Point(493, 297)
        CurrentQtyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        CurrentQtyLabel.Name = "CurrentQtyLabel"
        CurrentQtyLabel.Size = New System.Drawing.Size(57, 13)
        CurrentQtyLabel.TabIndex = 4
        CurrentQtyLabel.Text = "CurrentQty"
        '
        'FarmNameTextBox
        '
        Me.FarmNameTextBox.Location = New System.Drawing.Point(113, 234)
        Me.FarmNameTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FarmNameTextBox.Name = "FarmNameTextBox"
        Me.FarmNameTextBox.Size = New System.Drawing.Size(302, 20)
        Me.FarmNameTextBox.TabIndex = 1
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(242, 14)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 2
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'OwnerTextBox
        '
        Me.OwnerTextBox.Location = New System.Drawing.Point(113, 290)
        Me.OwnerTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.OwnerTextBox.Name = "OwnerTextBox"
        Me.OwnerTextBox.Size = New System.Drawing.Size(302, 20)
        Me.OwnerTextBox.TabIndex = 3
        '
        'FlockNoTextBox
        '
        Me.FlockNoTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.FlockNoTextBox.Location = New System.Drawing.Point(113, 184)
        Me.FlockNoTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FlockNoTextBox.Name = "FlockNoTextBox"
        Me.FlockNoTextBox.Size = New System.Drawing.Size(302, 20)
        Me.FlockNoTextBox.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(240, 355)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 150
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 1
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 3
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(1, 453)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(959, 292)
        Me.dgv.TabIndex = 149
        Me.dgv.TabStop = False
        '
        'BirdsQtyTextBox
        '
        Me.BirdsQtyTextBox.Location = New System.Drawing.Point(609, 237)
        Me.BirdsQtyTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BirdsQtyTextBox.Name = "BirdsQtyTextBox"
        Me.BirdsQtyTextBox.Size = New System.Drawing.Size(270, 20)
        Me.BirdsQtyTextBox.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-305, -217)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Label1"
        '
        'StartDate
        '
        Me.StartDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.StartDate.Location = New System.Drawing.Point(609, 177)
        Me.StartDate.Name = "StartDate"
        Me.StartDate.Size = New System.Drawing.Size(260, 20)
        Me.StartDate.TabIndex = 5
        '
        'CurrentQtyTextBox
        '
        Me.CurrentQtyTextBox.Location = New System.Drawing.Point(609, 294)
        Me.CurrentQtyTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CurrentQtyTextBox.Name = "CurrentQtyTextBox"
        Me.CurrentQtyTextBox.Size = New System.Drawing.Size(270, 20)
        Me.CurrentQtyTextBox.TabIndex = 4
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(1, 0)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(959, 145)
        Me.GroupBox5.TabIndex = 730
        Me.GroupBox5.TabStop = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label11.Location = New System.Drawing.Point(470, 26)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(408, 98)
        Me.Label11.TabIndex = 721
        Me.Label11.Text = "MANAGEMENT"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Poultary_Farm.My.Resources.Resources._0d772a6d2f2a1c20f15a28b78a4b1f56
        Me.PictureBox1.Location = New System.Drawing.Point(6, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(208, 130)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(274, 26)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(199, 98)
        Me.Label3.TabIndex = 720
        Me.Label3.Text = "FLOCK"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FrmFlocks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(959, 741)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.CurrentQtyTextBox)
        Me.Controls.Add(CurrentQtyLabel)
        Me.Controls.Add(Me.StartDate)
        Me.Controls.Add(Me.FarmNameTextBox)
        Me.Controls.Add(FlockNoLabel)
        Me.Controls.Add(Me.OwnerTextBox)
        Me.Controls.Add(Me.FlockNoTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.BirdsQtyTextBox)
        Me.Controls.Add(FarmNameLabel)
        Me.Controls.Add(AccHolderLabel)
        Me.Controls.Add(OwnerLabel)
        Me.Controls.Add(BirdsQtyLabel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmFlocks"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmFlocks"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents FarmNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents OwnerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FlockNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents BirdsQtyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents StartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents CurrentQtyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
