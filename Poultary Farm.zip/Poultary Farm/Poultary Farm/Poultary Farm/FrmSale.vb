﻿Public Class FrmSale


    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Public SaleParty As Boolean
    
    Private Sub insertion()
        Try
            cmdsql.Connection = con

            cmdsql.CommandText = "INSERT INTO  Sales (SId,SDate,AccName,Item,Rate,Quantity,Amount,Details) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & ItemTextBox.Text & "','" & RateTextBox.Text & "','" & QuantityTextBox.Text & "','" & AmountTextBox.Text & "','" & DetailTextBox.Text & "'  )"

            cmdsql.ExecuteNonQuery()




        Catch ex As Exception
            MsgBox("Please Enter Data in correct Format" & ex.Message)

        End Try



    End Sub
    Private Sub id()
        Try

      
        SIdTextBox.Text = ""
        Dim ed As Double
        cmdsql = New SqlClient.SqlCommand("select isnull(Count(Item),0) from Sales", con)


        ed = cmdsql.ExecuteScalar()


        ed = ed + 1

        SIdTextBox.Text = ed
        Catch ex As Exception

        End Try

    End Sub
    Private Sub FillItemCombo()
        Try

            Dim dasql As New SqlClient.SqlDataAdapter("select * from Items order by ItemName", con)
            Dim dt As New DataTable
            dasql.Fill(dt)
            If dt.Rows.Count > 0 Then
                ItemTextBox.DataSource = dt
                ItemTextBox.DisplayMember = "ItemName"
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SqlGridView()
        Try
            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM Sales order by SId  ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
    Function CLEAR_CONTROL()
        SIdTextBox.DataBindings.Clear()
        ItemTextBox.DataBindings.Clear()
        datetxt.DataBindings.Clear()
        RateTextBox.DataBindings.Clear()
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        QuantityTextBox.DataBindings.Clear()
        AmountTextBox.DataBindings.Clear()
        DetailTextBox.DataBindings.Clear()

        SIdTextBox.Text = ""
        ItemTextBox.Text = ""
        RateTextBox.Text = ""
        QuantityTextBox.Text = ""
        AmountTextBox.Text = ""
        DetailTextBox.Text = ""

        datetxt.Text = ""

        Return 0
    End Function

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If ItemTextBox.Text <> "" Then

            id()
            UpdateTransaction()
            UpdateStock()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please fill All Information..!!")
        End If
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If SIdTextBox.Text <> "" Then


            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM Sales  WHERE SId= '" & SIdTextBox.Text & "' "
                cmdsql.ExecuteNonQuery()
                '        MsgBox("Delete Successfuly")

                CLEAR_CONTROL()
                SqlGridView()



            Else : result = DialogResult.No
                MsgBox("Delete Cancel")
            End If
        Else
            MsgBox("Please Select Any accounts !!!")
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
    End Sub
    Private Sub updation()
        Try

            cmdsql.Connection = con
            cmdsql.CommandText = "update  Sales  set   SDate='" & datetxt.Text & "'   where SId='" & SIdTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()
            cmdsql.Connection = con
            cmdsql.CommandText = "update  Sales  set   AccName='" & AccNameTextBox.Text & "'   where SId='" & SIdTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update Sales set  Item='" & ItemTextBox.Text & "'   where SId='" & SIdTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()
            cmdsql.Connection = con
           
        
            cmdsql.CommandText = "update  Sales  set  Rate= '" & RateTextBox.Text & "'  where SId='" & SIdTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  Sales  set   Quantity='" & QuantityTextBox.Text & "'   where SId='" & SIdTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  Sales  set   Amount='" & AmountTextBox.Text & "'   where SId='" & SIdTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update  Sales  set   Details='" & DetailTextBox.Text & "'   where SId='" & SIdTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()



        Catch ex As Exception
            MsgBox(" Please Enter Data in Correct Format")
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        updation()
        UpdateSale()
        CLEAR_CONTROL()
        SqlGridView()
    End Sub
    Private Sub boxvalue()
        Try



            CLEAR_CONTROL()
            SIdTextBox.DataBindings.Add("text", dt, "SId")
            datetxt.DataBindings.Add("text", dt, "SDate")
            AccNameTextBox.DataBindings.Add("text", dt, "AccName")
            ItemTextBox.DataBindings.Add("text", dt, "Item")
            '  Obalancetxt.DataBindings.Add("text", dt, "balance")
            RateTextBox.DataBindings.Add("text", dt, "Rate")
            QuantityTextBox.DataBindings.Add("text", dt, "Quantity")
            AmountTextBox.DataBindings.Add("text", dt, "Amount")
            DetailTextBox.DataBindings.Add("text", dt, "Details")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
    End Sub
    Private Sub AccountsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub
    Private Sub Amount()
        Try
            Dim qty As Decimal
            Dim rate As Decimal
            Dim amnt As Decimal
            qty = QuantityTextBox.Text
            rate = RateTextBox.Text
            amnt = qty * rate
            AmountTextBox.Text = amnt
        Catch ex As Exception

        End Try
    End Sub
    Private Sub FrmSale_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
        FillItemCombo()

    End Sub
    Private Sub UpdateStock()
        Try

            cmdsql.Connection = con
            Dim Qty As Integer
            cmdsql.CommandText = "select Quantity from Items where ItemName='" & ItemTextBox.Text & "' "
            Qty = cmdsql.ExecuteScalar
            Qty = Qty + QuantityTextBox.Text()
            cmdsql.CommandText = "update Items set Quantity ='" & Qty & "' from Items where ItemName='" & ItemTextBox.Text & "'"
            cmdsql.ExecuteScalar()
        Catch ex As Exception

        End Try

    End Sub
    ' Private Sub UpdateTransactionDebit()
    'cmdsql.Connection = con
    'Dim TID As String
    'Dim Transport As String
    ' TID = "Sale" & ComboItem.Text
    'Transport = "Sale From Godwon To " & AccNameTextBox.Text
    '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
    ' cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Debit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "'  )"

    'cmdsql.ExecuteNonQuery()
    '///////////////////////////// Updation of Transport Record in Transaction ////////////////////
    'cmdsql.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & SIdTextBox.Text & "','" & SaledateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & Transport & "','" & FrAmountTextbox.Text & "')"
    'cmdsql.ExecuteNonQuery()
    ' cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "'  )"

    'cmdsql.ExecuteNonQuery()
    ' cmdsql.Connection = con
    'cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Debit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "')"
    'cmdsql.ExecuteNonQuery()



    'End Sub
    Private Sub UpdateTransaction()
        'cmdsql.Connection = con
        'Dim TID As String
        'Dim Transport As String
        ' TID = "Sale" & ComboItem.Text
        'Transport = "Sale From Godwon To " & AccNameTextBox.Text
        '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
        ' cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "'  )"

        'cmdsql.ExecuteNonQuery()
        '///////////////////////////// Updation of Transport Record in Transaction ////////////////////
        'cmdsql.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & SIdTextBox.Text & "','" & SaledateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & Transport & "','" & FrAmountTextbox.Text & "')"
        'cmdsql.ExecuteNonQuery()
        ' cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "'  )"

        'cmdsql.ExecuteNonQuery()
        Try
            cmdsql.Connection = con
            cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & SIdTextBox.Text & "','" & datetxt.Text & "','" & AccNameTextBox.Text & "','" & DetailTextBox.Text & "','" & AmountTextBox.Text & "')"
            cmdsql.ExecuteNonQuery()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub BtnParty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnParty.Click
        SaleParty = True
        FrmParty.ShowDialog()
    End Sub
    Private Sub UpdateSale()
        Try
            cmdsql.Connection = con
            Dim ItemQty As Decimal
            cmdsql.CommandText = "select Quantity from Sales where Sid='" & SIdTextBox.Text & "'"
            ItemQty = cmdsql.ExecuteScalar
            '///////////////////// Delete From Purchase ///////////
            cmdsql.CommandText = "delete from Sales where Sid='" & SIdTextBox.Text & "'"
            cmdsql.ExecuteNonQuery()
            '//////////////////////////////////////////////////////
            '/////////////////////// Update Transaction ////////////
            cmdsql.CommandText = "delete from Transactions where TransId='" & SIdTextBox.Text & "'"
            cmdsql.ExecuteNonQuery()
            '////////////////////////////////////////////////////////
            '///////////// Update Stock //////////////////////////
            'cmdsql.Connection = con
            'Dim Qty As Integer
            'cmdsql.CommandText = "select Quantity from Items where ItemName='" & ItemTextBox.Text & "' "
            ' Qty = cmdsql.ExecuteScalar
            ' Qty = Qty - QuantityTextBox.Text()
            'cmdsql.CommandText = "update Items set Quantity ='" & Qty & "'from Items where ItemName='" & ItemTextBox.Text & "'"
            'cmdsql.ExecuteScalar()
            '////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            '//////////////////////// Saving Again /////////////////////////////////////////////////////////////////////////

            'UpdateStock()
            UpdateTransaction()
            'updation()
            'UpdateTransactionDebit()
            ' dt.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub QuantityTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuantityTextBox.TextChanged
        Amount()
    End Sub

    Private Sub RateTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RateTextBox.TextChanged
        Amount()
    End Sub
End Class