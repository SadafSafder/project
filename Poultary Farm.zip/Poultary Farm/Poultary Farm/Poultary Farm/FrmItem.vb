﻿Public Class FrmItem
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Public Property val As String
    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(QuantityTextbox.Text) And IsNumeric(AvgRateTextbox.Text)) Then

                cmdsql.CommandText = "INSERT INTO  Items (ItemCode,ItemName,Avgrate,Quantity) VALUES  ('" & ItemCodeTextBox.Text & "','" & itemNameTextBox.Text & "','" & AvgRateTextbox.Text & "','" & QuantityTextbox.Text & "' )"

                cmdsql.ExecuteNonQuery()
            Else
                MessageBox.Show("Please Enter Data in Correct Format")
            End If


        Catch ex As Exception
            MsgBox("Please Enter Data in Proper Format")

        End Try



    End Sub

    Private Sub FrmItem_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
        QuantityTextbox.Text = val
    End Sub
    Private Sub id()
        Try
            ItemIdTextBox.Text = ""
            Dim ed As Double
            cmdsql = New SqlClient.SqlCommand("select isnull(max(ItemCode),0) from Items", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed + 1

            ItemIdTextBox.Text = ed
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SqlGridView()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * from Items ", con)

            daSql.Fill(dt)
            Me.Dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Function CLEAR_CONTROL()
        ItemIdTextBox.DataBindings.Clear()
        itemNameTextBox.DataBindings.Clear()
        QuantityTextbox.DataBindings.Clear()

        ItemIdTextBox.Text = ""
        itemNameTextBox.Text = ""
        QuantityTextbox.Text = ""
        Return 0
    End Function

    Private Sub updation()
        Try


            cmdsql.Connection = con
            If (IsNumeric(QuantityTextbox.Text)) Then

                cmdsql.CommandText = "update Items set  ItemName='" & itemNameTextBox.Text & "' ,Quantity='" & QuantityTextbox.Text & "' where ItemCode='" & ItemIdTextBox.Text & "'  "
                cmdsql.ExecuteNonQuery()
            Else
                MsgBox("Please Enter Data in Proper Format")
            End If

        Catch ex As Exception

        End Try
    End Sub
    Private Sub boxvalue()
        Try
            AvgRateTextbox.ReadOnly = True
            CLEAR_CONTROL()
            ItemIdTextBox.DataBindings.Add("text", dt, "ItemCode")
            itemNameTextBox.DataBindings.Add("text", dt, "ItemName")
            QuantityTextbox.DataBindings.Add("text", dt, "Quantity")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If itemNameTextBox.Text <> "" And AvgRateTextbox.Text <> "" Then
            id()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please Fill All Info!!")
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        CLEAR_CONTROL()
        AvgRateTextbox.ReadOnly = False
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If ItemIdTextBox.Text <> "" Then

            updation()
            CLEAR_CONTROL()
            SqlGridView()

        Else
            MsgBox("Please Select any Item !!")

        End If
        AvgRateTextbox.ReadOnly = False
    End Sub
    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()

    End Sub

    Private Sub QuantityTextbox_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles QuantityTextbox.Click
        'Dim obb As New FrmDailyStatus
        'obb.val = Me.QuantityTextbox.Text()
        'obb.Show()
        ' Me.Hide()
    End Sub

    Private Sub QuantityTextbox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuantityTextbox.TextChanged

    End Sub
End Class