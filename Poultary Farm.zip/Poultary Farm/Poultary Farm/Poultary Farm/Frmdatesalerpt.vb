﻿Public Class Frmdatesalerpt
    'Dim cmd As New SqlClient.SqlCommand
    Dim con As New SqlClient.SqlConnection
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim da As New SqlClient.SqlDataAdapter
    Dim ds As New PoltaryFarmDBDataSet
    Dim rpt As New SaleDatereport
    Private Sub dbaccessconnection()
        'Acces DataBase Connectivity and for MS Access 2003 PROVIDER=Microsoft.Jet.OLEDB.4.0
        Try
            con.ConnectionString = "Data Source=SADAFBHATTI;Initial Catalog=PoltaryFarmDB;Integrated Security=True"
            cmdsql.Connection = con
            'MessageBox.Show(con.State.ToString())
        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try
    End Sub
    Private Sub Frmdatesalerpt_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbaccessconnection()
    End Sub
    Private Sub search()
        Try

            ds.Clear()

            cmdsql.Connection = con

            '        cmdsql.CommandText = "Select PId,PDate,AccName,Item,Rate,Quantity,Amount,Details from Purchases where PDate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "'   "
            'cmdsql.CommandText = "Select PDate from Purchases where PDate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "'   "
            cmdsql.CommandText = "select * from Sales"
            cmdsql.CommandType = CommandType.Text
            da.SelectCommand = cmdsql




            da.Fill(ds, "Sales")
            rpt.SetDataSource(ds)
            CrystalReportViewer1.ReportSource = rpt
            CrystalReportViewer1.Refresh()
            ' consql.Close()
            ds.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub







    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        search()
    End Sub
End Class



