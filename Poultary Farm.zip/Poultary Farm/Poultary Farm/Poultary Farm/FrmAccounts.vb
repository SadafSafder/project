﻿Public Class FrmAccounts
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Private Sub AccountsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub


    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(PhoneTextBox.Text)) Then
                cmdsql.CommandText = "INSERT INTO  accounts (AccNo,AccName,AccHolder,Type,Address,Phone) VALUES  ('" & AccNoTextBox.Text & "','" & AccNameTextBox.Text & "','" & AccHolderTextBox.Text & "','" & TypeTextBox.Text & "','" & AddressTextBox.Text & "','" & PhoneTextBox.Text & "'  )"

                cmdsql.ExecuteNonQuery()
            End If



        Catch ex As Exception
            MsgBox("Please Enter Data in correct Format")

        End Try



    End Sub

    Private Sub updation()
        Try


            cmdsql.Connection = con
            cmdsql.CommandText = "update accounts set  AccName='" & AccNameTextBox.Text & "'   where AccNo='" & AccNoTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update accounts set  AccHolder= '" & AccHolderTextBox.Text & "'  where AccNo='" & AccNoTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update accounts set   Type='" & TypeTextBox.Text & "'   where AccNo='" & AccNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            If (IsNumeric(PhoneTextBox.Text)) Then

                cmdsql.CommandText = "update accounts set   Phone='" & PhoneTextBox.Text & "'   where AccNo='" & AccNoTextBox.Text & "' "
                cmdsql.ExecuteNonQuery()
            End If

            cmdsql.Connection = con
            cmdsql.CommandText = "update accounts set   Address='" & AddressTextBox.Text & "'  where AccNo='" & AccNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(" Please Enter Data in Correct Format")
        End Try
    End Sub

    Private Sub ccode()
        Try
            ' AccNoTextBox.Text = ""
            Dim ed As String
            cmdsql = New SqlClient.SqlCommand("select isnull(Count(AccNo),0) from accounts", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed + 1

            AccNoTextBox.Text = AccNoTextBox.Text + "-" + ed
        Catch ex As Exception

        End Try
    End Sub


    Private Sub SqlGridView()
        Try
            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM accounts order by AccNo  ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub




    Private Sub boxvalue()
        Try



            CLEAR_CONTROL()
            AccNoTextBox.DataBindings.Add("text", dt, "AccNo")
            AccNameTextBox.DataBindings.Add("text", dt, "AccName")
            '  Obalancetxt.DataBindings.Add("text", dt, "balance")
            TypeTextBox.DataBindings.Add("text", dt, "type")
            AccHolderTextBox.DataBindings.Add("text", dt, "AccHolder")
            PhoneTextBox.DataBindings.Add("text", dt, "Phone")

            AddressTextBox.DataBindings.Add("text", dt, "Address")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Function CLEAR_CONTROL()
        AccNoTextBox.DataBindings.Clear()
        AccNameTextBox.DataBindings.Clear()
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        TypeTextBox.DataBindings.Clear()
        AccHolderTextBox.DataBindings.Clear()
        PhoneTextBox.DataBindings.Clear()
        AccNoTextBox.DataBindings.Clear()
        AddressTextBox.DataBindings.Clear()
        AccNoTextBox.Text = ""
        AccNameTextBox.Text = ""
        AddressTextBox.Text = ""
        AccNoTextBox.Text = ""
        AccHolderTextBox.Text = ""
        PhoneTextBox.Text = ""
        TypeTextBox.Text = ""



        Return 0
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If AccNoTextBox.Text <> "" Then


            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM accounts WHERE AccNo= '" & AccNoTextBox.Text & "' "
                cmdsql.ExecuteNonQuery()
                '        MsgBox("Delete Successfuly")

                CLEAR_CONTROL()
                SqlGridView()



            Else : result = DialogResult.No
                MsgBox("Delete Cancel")
            End If
        Else
            MsgBox("Please Select Any accounts !!!")
        End If

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If AccNameTextBox.Text <> "" Then

            ccode()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please fill All Information..!!")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        updation()
        CLEAR_CONTROL()
        SqlGridView()
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
    End Sub

    Private Sub AccNoTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNoTextBox.TextChanged

    End Sub

    Private Sub AccHolderLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AccountsBindingSource_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AccNameTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNameTextBox.TextChanged

    End Sub
End Class
