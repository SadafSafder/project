﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTransaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TransIdLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim TranseDateLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Dim DescriptionLabel As System.Windows.Forms.Label
        Dim CreditLabel As System.Windows.Forms.Label
        Dim BalanceLabel As System.Windows.Forms.Label
        Dim DebitLabel As System.Windows.Forms.Label
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.CreditTextBox = New System.Windows.Forms.TextBox()
        Me.TransIdTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.BalanceTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DebitTextBox = New System.Windows.Forms.TextBox()
        Me.TransDate = New System.Windows.Forms.DateTimePicker()
        Me.DescriptionTextBox = New System.Windows.Forms.TextBox()
        TransIdLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        TranseDateLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        DescriptionLabel = New System.Windows.Forms.Label()
        CreditLabel = New System.Windows.Forms.Label()
        BalanceLabel = New System.Windows.Forms.Label()
        DebitLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TransIdLabel
        '
        TransIdLabel.AutoSize = True
        TransIdLabel.Location = New System.Drawing.Point(14, 58)
        TransIdLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TransIdLabel.Name = "TransIdLabel"
        TransIdLabel.Size = New System.Drawing.Size(42, 13)
        TransIdLabel.TabIndex = 143
        TransIdLabel.Text = "Transid"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(320, 9)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 24)
        Me.Label2.TabIndex = 142
        Me.Label2.Text = "Transactions"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(242, 14)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 30
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.Location = New System.Drawing.Point(593, 85)
        Me.AccNameTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(227, 20)
        Me.AccNameTextBox.TabIndex = 137
        '
        'CreditTextBox
        '
        Me.CreditTextBox.Location = New System.Drawing.Point(121, 145)
        Me.CreditTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CreditTextBox.Name = "CreditTextBox"
        Me.CreditTextBox.Size = New System.Drawing.Size(341, 20)
        Me.CreditTextBox.TabIndex = 139
        '
        'TransIdTextBox
        '
        Me.TransIdTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TransIdTextBox.Location = New System.Drawing.Point(121, 55)
        Me.TransIdTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TransIdTextBox.Name = "TransIdTextBox"
        Me.TransIdTextBox.Size = New System.Drawing.Size(64, 20)
        Me.TransIdTextBox.TabIndex = 135
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightBlue
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(157, 198)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 150
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(136, 267)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(642, 336)
        Me.dgv.TabIndex = 149
        Me.dgv.TabStop = False
        '
        'BalanceTextBox
        '
        Me.BalanceTextBox.Location = New System.Drawing.Point(593, 145)
        Me.BalanceTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BalanceTextBox.Name = "BalanceTextBox"
        Me.BalanceTextBox.Size = New System.Drawing.Size(227, 20)
        Me.BalanceTextBox.TabIndex = 140
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.ForeColor = System.Drawing.Color.Red
        Label3.Location = New System.Drawing.Point(193, 61)
        Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(154, 15)
        Label3.TabIndex = 151
        Label3.Text = "(Please Enter 3-Characters"
        '
        'TranseDateLabel
        '
        TranseDateLabel.AutoSize = True
        TranseDateLabel.Location = New System.Drawing.Point(14, 88)
        TranseDateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TranseDateLabel.Name = "TranseDateLabel"
        TranseDateLabel.Size = New System.Drawing.Size(63, 13)
        TranseDateLabel.TabIndex = 144
        TranseDateLabel.Text = "TranseDate"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(478, 88)
        AccNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(54, 13)
        AccNameLabel.TabIndex = 145
        AccNameLabel.Text = "AccName"
        '
        'DescriptionLabel
        '
        DescriptionLabel.AutoSize = True
        DescriptionLabel.Location = New System.Drawing.Point(14, 118)
        DescriptionLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DescriptionLabel.Name = "DescriptionLabel"
        DescriptionLabel.Size = New System.Drawing.Size(60, 13)
        DescriptionLabel.TabIndex = 146
        DescriptionLabel.Text = "Description"
        '
        'CreditLabel
        '
        CreditLabel.AutoSize = True
        CreditLabel.Location = New System.Drawing.Point(14, 148)
        CreditLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        CreditLabel.Name = "CreditLabel"
        CreditLabel.Size = New System.Drawing.Size(34, 13)
        CreditLabel.TabIndex = 147
        CreditLabel.Text = "Credit"
        '
        'BalanceLabel
        '
        BalanceLabel.AutoSize = True
        BalanceLabel.Location = New System.Drawing.Point(481, 148)
        BalanceLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        BalanceLabel.Name = "BalanceLabel"
        BalanceLabel.Size = New System.Drawing.Size(46, 13)
        BalanceLabel.TabIndex = 148
        BalanceLabel.Text = "Balance"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-372, -227)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Label1"
        '
        'DebitTextBox
        '
        Me.DebitTextBox.Location = New System.Drawing.Point(593, 114)
        Me.DebitTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DebitTextBox.Name = "DebitTextBox"
        Me.DebitTextBox.Size = New System.Drawing.Size(227, 20)
        Me.DebitTextBox.TabIndex = 152
        '
        'DebitLabel
        '
        DebitLabel.AutoSize = True
        DebitLabel.Location = New System.Drawing.Point(481, 117)
        DebitLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DebitLabel.Name = "DebitLabel"
        DebitLabel.Size = New System.Drawing.Size(32, 13)
        DebitLabel.TabIndex = 153
        DebitLabel.Text = "Debit"
        '
        'TransDate
        '
        Me.TransDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.TransDate.Location = New System.Drawing.Point(121, 88)
        Me.TransDate.Name = "TransDate"
        Me.TransDate.Size = New System.Drawing.Size(200, 20)
        Me.TransDate.TabIndex = 154
        '
        'DescriptionTextBox
        '
        Me.DescriptionTextBox.Location = New System.Drawing.Point(121, 119)
        Me.DescriptionTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DescriptionTextBox.Name = "DescriptionTextBox"
        Me.DescriptionTextBox.Size = New System.Drawing.Size(341, 20)
        Me.DescriptionTextBox.TabIndex = 155
        '
        'FrmTransaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1045, 515)
        Me.Controls.Add(Me.DescriptionTextBox)
        Me.Controls.Add(Me.TransDate)
        Me.Controls.Add(DebitLabel)
        Me.Controls.Add(Me.DebitTextBox)
        Me.Controls.Add(TransIdLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.AccNameTextBox)
        Me.Controls.Add(Me.CreditTextBox)
        Me.Controls.Add(Me.TransIdTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.BalanceTextBox)
        Me.Controls.Add(Label3)
        Me.Controls.Add(TranseDateLabel)
        Me.Controls.Add(AccNameLabel)
        Me.Controls.Add(DescriptionLabel)
        Me.Controls.Add(CreditLabel)
        Me.Controls.Add(BalanceLabel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmTransaction"
        Me.Text = "FrmTransaction"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CreditTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TransIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents BalanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DebitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TransDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents DescriptionTextBox As System.Windows.Forms.TextBox
End Class
