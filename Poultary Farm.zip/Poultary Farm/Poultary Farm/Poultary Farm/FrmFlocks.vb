﻿Public Class FrmFlocks
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Private Sub FrmFlocks_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
    End Sub
    Private Sub insertion()
        Try
            cmdsql.Connection = con

            cmdsql.CommandText = "INSERT INTO  Flockk (FlockNo,StartDate,FarmName,Owner,BirdsQty,CurrentQty) VALUES  ('" & FlockNoTextBox.Text & "','" & StartDate.Text & "','" & FarmNameTextBox.Text & "','" & OwnerTextBox.Text & "','" & BirdsQtyTextBox.Text & "' ,'" & CurrentQtyTextBox.Text & "' )"

            cmdsql.ExecuteNonQuery()
          

        Catch ex As Exception
            MsgBox("Please Enter Data in correct Format" & ex.Message)

        End Try



    End Sub
    Private Sub ccode()
        Try
            ' AccNoTextBox.Text = ""
            Dim ed As String
            cmdsql = New SqlClient.SqlCommand("select isnull(Count(FlockNo),0) from Flockk", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed + 1

            FlockNoTextBox.Text = FlockNoTextBox.Text + "-" + ed
        Catch ex As Exception

        End Try
    End Sub


    Private Sub SqlGridView()
        Try
            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM Flockk order by FlockNo  ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
    Function CLEAR_CONTROL()
        FlockNoTextBox.DataBindings.Clear()
        StartDate.DataBindings.Clear()
        FarmNameTextBox.DataBindings.Clear()
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")

        OwnerTextBox.DataBindings.Clear()
        BirdsQtyTextBox.DataBindings.Clear()
        CurrentQtyTextBox.DataBindings.Clear()

        FlockNoTextBox.Text = ""
        FarmNameTextBox.Text = ""
        OwnerTextBox.Text = ""


        BirdsQtyTextBox.Text = ""
        StartDate.Text = ""
        CurrentQtyTextBox.Text = ""


        Return 0
    End Function

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If FarmNameTextBox.Text <> "" Then

            ccode()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please fill All Information..!!")
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If FlockNoTextBox.Text <> "" Then


            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM Flockk  WHERE FlockNo= '" & FlockNoTextBox.Text & "' "
                cmdsql.ExecuteNonQuery()
                '        MsgBox("Delete Successfuly")

                CLEAR_CONTROL()
                SqlGridView()



            Else : result = DialogResult.No
                MsgBox("Delete Cancel")
            End If
        Else
            MsgBox("Please Select Any accounts !!!")
        End If

    End Sub

   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
    End Sub
    Private Sub updation()
        Try


            cmdsql.Connection = con
            cmdsql.CommandText = "update Flockk set  StartDate='" & StartDate.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update Flockk set  FarmName= '" & FarmNameTextBox.Text & "'  where FlockNo='" & FlockNoTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update Flockk set   Owner='" & OwnerTextBox.Text & "'   where FlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update Flockk set   BirdsQty='" & BirdsQtyTextBox.Text & "'   whereFlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()
        

            cmdsql.Connection = con
            cmdsql.CommandText = "update Flockk set   CurrentQty='" & CurrentQtyTextBox.Text & "'   whereFlockNo='" & FlockNoTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(" Please Enter Data in Correct Format")
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        updation()
        CLEAR_CONTROL()
        SqlGridView()
    End Sub
    Private Sub boxvalue()
        Try



            CLEAR_CONTROL()
            FlockNoTextBox.DataBindings.Add("text", dt, "FlockNo")
            StartDate.DataBindings.Add("text", dt, "StartDate")
            '  Obalancetxt.DataBindings.Add("text", dt, "balance")
            FarmNameTextBox.DataBindings.Add("text", dt, "FarmName")
            OwnerTextBox.DataBindings.Add("text", dt, "Owner")
            BirdsQtyTextBox.DataBindings.Add("text", dt, "BirdsQty")
            CurrentQtyTextBox.DataBindings.Add("text", dt, "CurrentQty")


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
    End Sub
    Private Sub AccountsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub FlockNoTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlockNoTextBox.TextChanged

    End Sub
End Class