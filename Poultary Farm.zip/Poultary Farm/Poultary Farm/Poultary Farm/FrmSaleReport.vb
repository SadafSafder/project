﻿Public Class FrmSaleReport

    Private Sub SaleReport1_InitReport(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaleReport1.InitReport

    End Sub
End Class