﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPurchase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim PIdLabel As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim RateLabel As System.Windows.Forms.Label
        Dim QuantityLabel As System.Windows.Forms.Label
        Dim ItemLabel As System.Windows.Forms.Label
        Dim DetailLabel As System.Windows.Forms.Label
        Dim AmountLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Me.RateTextBox = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.QuantityTextBox = New System.Windows.Forms.TextBox()
        Me.DetailTextBox = New System.Windows.Forms.TextBox()
        Me.ItemTextBox = New System.Windows.Forms.ComboBox()
        Me.PIdTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.AmountTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnParty = New System.Windows.Forms.Button()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.datetxt = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        PIdLabel = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        RateLabel = New System.Windows.Forms.Label()
        QuantityLabel = New System.Windows.Forms.Label()
        ItemLabel = New System.Windows.Forms.Label()
        DetailLabel = New System.Windows.Forms.Label()
        AmountLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PIdLabel
        '
        PIdLabel.AutoSize = True
        PIdLabel.Location = New System.Drawing.Point(27, 210)
        PIdLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        PIdLabel.Name = "PIdLabel"
        PIdLabel.Size = New System.Drawing.Size(23, 13)
        PIdLabel.TabIndex = 0
        PIdLabel.Text = "PId"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.ForeColor = System.Drawing.Color.Red
        Label4.Location = New System.Drawing.Point(157, 324)
        Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(213, 15)
        Label4.TabIndex = 152
        Label4.Text = "(Please Enter Amount Without dashes"
        '
        'RateLabel
        '
        RateLabel.AutoSize = True
        RateLabel.Location = New System.Drawing.Point(435, 248)
        RateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        RateLabel.Name = "RateLabel"
        RateLabel.Size = New System.Drawing.Size(30, 13)
        RateLabel.TabIndex = 4
        RateLabel.Text = "Rate"
        '
        'QuantityLabel
        '
        QuantityLabel.AutoSize = True
        QuantityLabel.Location = New System.Drawing.Point(27, 283)
        QuantityLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        QuantityLabel.Name = "QuantityLabel"
        QuantityLabel.Size = New System.Drawing.Size(46, 13)
        QuantityLabel.TabIndex = 3
        QuantityLabel.Text = "Quantity"
        '
        'ItemLabel
        '
        ItemLabel.AutoSize = True
        ItemLabel.Location = New System.Drawing.Point(27, 248)
        ItemLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        ItemLabel.Name = "ItemLabel"
        ItemLabel.Size = New System.Drawing.Size(27, 13)
        ItemLabel.TabIndex = 1
        ItemLabel.Text = "Item"
        '
        'DetailLabel
        '
        DetailLabel.AutoSize = True
        DetailLabel.Location = New System.Drawing.Point(444, 326)
        DetailLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DetailLabel.Name = "DetailLabel"
        DetailLabel.Size = New System.Drawing.Size(34, 13)
        DetailLabel.TabIndex = 6
        DetailLabel.Text = "Detail"
        '
        'AmountLabel
        '
        AmountLabel.AutoSize = True
        AmountLabel.Location = New System.Drawing.Point(27, 360)
        AmountLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AmountLabel.Name = "AmountLabel"
        AmountLabel.Size = New System.Drawing.Size(43, 13)
        AmountLabel.TabIndex = 5
        AmountLabel.Text = "Amount"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(435, 210)
        AccNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(81, 13)
        AccNameLabel.TabIndex = 2
        AccNameLabel.Text = "Account Name:"
        '
        'RateTextBox
        '
        Me.RateTextBox.Location = New System.Drawing.Point(515, 243)
        Me.RateTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.RateTextBox.Name = "RateTextBox"
        Me.RateTextBox.Size = New System.Drawing.Size(341, 20)
        Me.RateTextBox.TabIndex = 5
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(243, 18)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 2
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'QuantityTextBox
        '
        Me.QuantityTextBox.Location = New System.Drawing.Point(84, 276)
        Me.QuantityTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.QuantityTextBox.Name = "QuantityTextBox"
        Me.QuantityTextBox.Size = New System.Drawing.Size(299, 20)
        Me.QuantityTextBox.TabIndex = 4
        '
        'DetailTextBox
        '
        Me.DetailTextBox.Location = New System.Drawing.Point(515, 276)
        Me.DetailTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DetailTextBox.Multiline = True
        Me.DetailTextBox.Name = "DetailTextBox"
        Me.DetailTextBox.Size = New System.Drawing.Size(349, 108)
        Me.DetailTextBox.TabIndex = 7
        '
        'ItemTextBox
        '
        Me.ItemTextBox.FormattingEnabled = True
        Me.ItemTextBox.Location = New System.Drawing.Point(84, 237)
        Me.ItemTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ItemTextBox.Name = "ItemTextBox"
        Me.ItemTextBox.Size = New System.Drawing.Size(299, 21)
        Me.ItemTextBox.TabIndex = 3
        '
        'PIdTextBox
        '
        Me.PIdTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.PIdTextBox.Location = New System.Drawing.Point(84, 208)
        Me.PIdTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PIdTextBox.Name = "PIdTextBox"
        Me.PIdTextBox.Size = New System.Drawing.Size(299, 20)
        Me.PIdTextBox.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(193, 400)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 150
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 1
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 3
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(0, 469)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(959, 273)
        Me.dgv.TabIndex = 149
        Me.dgv.TabStop = False
        '
        'AmountTextBox
        '
        Me.AmountTextBox.Location = New System.Drawing.Point(84, 353)
        Me.AmountTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AmountTextBox.Name = "AmountTextBox"
        Me.AmountTextBox.Size = New System.Drawing.Size(299, 20)
        Me.AmountTextBox.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-355, -212)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 141
        Me.Label1.Text = "Label1"
        '
        'BtnParty
        '
        Me.BtnParty.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnParty.Location = New System.Drawing.Point(853, 205)
        Me.BtnParty.Name = "BtnParty"
        Me.BtnParty.Size = New System.Drawing.Size(83, 23)
        Me.BtnParty.TabIndex = 1
        Me.BtnParty.Text = "Party"
        Me.BtnParty.UseVisualStyleBackColor = True
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.Location = New System.Drawing.Point(515, 207)
        Me.AccNameTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(341, 20)
        Me.AccNameTextBox.TabIndex = 2
        '
        'datetxt
        '
        Me.datetxt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datetxt.Location = New System.Drawing.Point(713, 157)
        Me.datetxt.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.datetxt.Name = "datetxt"
        Me.datetxt.Size = New System.Drawing.Size(128, 20)
        Me.datetxt.TabIndex = 723
        Me.datetxt.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Location = New System.Drawing.Point(0, 6)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(959, 145)
        Me.GroupBox5.TabIndex = 730
        Me.GroupBox5.TabStop = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label11.Location = New System.Drawing.Point(652, 26)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(189, 98)
        Me.Label11.TabIndex = 721
        Me.Label11.Text = "ITEMS"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Poultary_Farm.My.Resources.Resources._0d772a6d2f2a1c20f15a28b78a4b1f56
        Me.PictureBox1.Location = New System.Drawing.Point(6, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(208, 130)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(343, 26)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(315, 98)
        Me.Label3.TabIndex = 720
        Me.Label3.Text = "PURCHASE "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'FrmPurchase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(961, 741)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.datetxt)
        Me.Controls.Add(Me.AccNameTextBox)
        Me.Controls.Add(AccNameLabel)
        Me.Controls.Add(Me.BtnParty)
        Me.Controls.Add(Me.RateTextBox)
        Me.Controls.Add(PIdLabel)
        Me.Controls.Add(Me.QuantityTextBox)
        Me.Controls.Add(Me.DetailTextBox)
        Me.Controls.Add(Me.ItemTextBox)
        Me.Controls.Add(Me.PIdTextBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.AmountTextBox)
        Me.Controls.Add(Label4)
        Me.Controls.Add(RateLabel)
        Me.Controls.Add(QuantityLabel)
        Me.Controls.Add(ItemLabel)
        Me.Controls.Add(DetailLabel)
        Me.Controls.Add(AmountLabel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FrmPurchase"
        Me.Text = "FrmPurchase"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents QuantityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DetailTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ItemTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents PIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents AmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnParty As System.Windows.Forms.Button
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents datetxt As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
