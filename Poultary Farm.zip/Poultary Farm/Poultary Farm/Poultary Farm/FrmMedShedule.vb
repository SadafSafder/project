﻿Public Class FrmMedShedule
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Private Sub FrmMedShedule_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
        FillItemCombo()
    End Sub
    Private Sub FillItemCombo()
        Try

            Dim dasql As New SqlClient.SqlDataAdapter("select * from Flockk order by FlockNo", con)
            Dim dt As New DataTable
            dasql.Fill(dt)
            If dt.Rows.Count > 0 Then
                FlockNoComboBox.DataSource = dt
                FlockNoComboBox.DisplayMember = "FlockNo"
            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub insertion()
        Try
            cmdsql.Connection = con

            cmdsql.CommandText = "INSERT INTO  MedSchedule (Mid,FlockNo,Medication,DueDate,AlerDate) VALUES  ('" & MidTextBox.Text & "','" & FlockNoComboBox.Text & "','" & MedicationTextBox.Text & "','" & DueDate.Text & "','" & AlertDate.Text & "')"

            cmdsql.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox("Please Enter Data in correct Format" & ex.Message)

        End Try



    End Sub
    Private Sub ccode()
        Try
            MidTextBox.Text = ""
            Dim ed As Double
            cmdsql = New SqlClient.SqlCommand("select isnull(max(Mid),0) from MedSchedule", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed + 1

            MIdTextBox.Text = ed
        Catch ex As Exception

        End Try
    End Sub


    Private Sub SqlGridView()
        Try
            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM MedSchedule order by Mid  ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
    Function CLEAR_CONTROL()
        MidTextBox.DataBindings.Clear()
        FlockNoComboBox.DataBindings.Clear()
        MedicationTextBox.DataBindings.Clear()
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")

        DueDate.DataBindings.Clear()
        AlertDate.DataBindings.Clear()
       
        MidTextBox.Text = ""
        FlockNoComboBox.Text = ""
        MedicationTextBox.Text = ""


        DueDate.Text = ""
        AlertDate.Text = ""



        Return 0
    End Function

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If MidTextBox.Text <> "" Then

            ccode()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please fill All Information..!!")
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
    End Sub
    Private Sub updation()
        Try


            cmdsql.Connection = con
            cmdsql.CommandText = "update MedSchedule set  FlockNo='" & FlockNoComboBox.Text & "'   where Mid='" & MidTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update MedSchedule set  Medication= '" & MedicationTextBox.Text & "'  where Mid='" & MidTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update MedSchedule set   DueDate='" & DueDate.Text & "'   where Mid='" & MidTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()

            cmdsql.Connection = con
            cmdsql.CommandText = "update MedSchedule set   AlerDate='" & AlertDate.Text & "'   where Mid='" & MidTextBox.Text & "' "
            cmdsql.ExecuteNonQuery()


           


        Catch ex As Exception
            MsgBox(" Please Enter Data in Correct Format")
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        updation()
        CLEAR_CONTROL()
        SqlGridView()
    End Sub
    Private Sub boxvalue()
        Try



            CLEAR_CONTROL()
            MidTextBox.DataBindings.Add("text", dt, "Mid")
            FlockNoComboBox.DataBindings.Add("text", dt, "FlockNo")
            '  Obalancetxt.DataBindings.Add("text", dt, "balance")
            MedicationTextBox.DataBindings.Add("text", dt, "Medication")
            DueDate.DataBindings.Add("text", dt, "DueDate")
            AlertDate.DataBindings.Add("text", dt, "AlerDate")
          

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
    End Sub
    
End Class