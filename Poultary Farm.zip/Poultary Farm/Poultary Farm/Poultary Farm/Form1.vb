﻿Public Class Form1

    
    Private Sub FrmAccountToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmAccountToolStripMenuItem.Click
        FrmAccounts.ShowDialog()
    End Sub

    Private Sub FrmFlockToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmFlockToolStripMenuItem.Click
        FrmFlocks.ShowDialog()
    End Sub

    Private Sub FrmitemToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmitemToolStripMenuItem.Click
        FrmItem.Show()
    End Sub

    Private Sub FrmTransactionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmTransactionToolStripMenuItem.Click
        FrmTransaction.ShowDialog()
    End Sub

    Private Sub FrmPurchaseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmPurchaseToolStripMenuItem.Click
        FrmPurchase.ShowDialog()
    End Sub

    Private Sub FrmSaleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmSaleToolStripMenuItem.Click
        FrmSale.ShowDialog()
    End Sub

    Private Sub FrmVouchersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrmVouchersToolStripMenuItem.Click
        FrmVouchers.ShowDialog()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoutToolStripMenuItem.Click

        Try

      
        If MsgBox("Are you sure you want to Quit?", vbYesNo) = vbYes Then
            Me.Close()

        Else
            Exit Sub
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        FrmDailyStatus.ShowDialog()
    End Sub
End Class
