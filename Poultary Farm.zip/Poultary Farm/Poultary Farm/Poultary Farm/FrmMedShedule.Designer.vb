﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMedShedule
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MidLabel = New System.Windows.Forms.Label()
        Me.FlockNoLabel = New System.Windows.Forms.Label()
        Me.MedicationLabel = New System.Windows.Forms.Label()
        Me.DueDateLabel = New System.Windows.Forms.Label()
        Me.AlertDateLabel = New System.Windows.Forms.Label()
        Me.MidTextBox = New System.Windows.Forms.TextBox()
        Me.MedicationTextBox = New System.Windows.Forms.TextBox()
        Me.FlockNoComboBox = New System.Windows.Forms.ComboBox()
        Me.DueDate = New System.Windows.Forms.DateTimePicker()
        Me.AlertDate = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.PictureBox1)
        Me.GroupBox5.Controls.Add(Me.Label1)
        Me.GroupBox5.Location = New System.Drawing.Point(1, 0)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(959, 145)
        Me.GroupBox5.TabIndex = 731
        Me.GroupBox5.TabStop = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label11.Location = New System.Drawing.Point(608, 19)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(264, 98)
        Me.Label11.TabIndex = 721
        Me.Label11.Text = "Shedule"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Poultary_Farm.My.Resources.Resources._0d772a6d2f2a1c20f15a28b78a4b1f56
        Me.PictureBox1.Location = New System.Drawing.Point(6, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(208, 130)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Cooper Black", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(381, 19)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(239, 98)
        Me.Label1.TabIndex = 720
        Me.Label1.Text = "Medicine"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MidLabel
        '
        Me.MidLabel.AutoSize = True
        Me.MidLabel.Location = New System.Drawing.Point(291, 179)
        Me.MidLabel.Name = "MidLabel"
        Me.MidLabel.Size = New System.Drawing.Size(24, 13)
        Me.MidLabel.TabIndex = 732
        Me.MidLabel.Text = "Mid"
        '
        'FlockNoLabel
        '
        Me.FlockNoLabel.AutoSize = True
        Me.FlockNoLabel.Location = New System.Drawing.Point(291, 208)
        Me.FlockNoLabel.Name = "FlockNoLabel"
        Me.FlockNoLabel.Size = New System.Drawing.Size(50, 13)
        Me.FlockNoLabel.TabIndex = 733
        Me.FlockNoLabel.Text = "Flock No"
        '
        'MedicationLabel
        '
        Me.MedicationLabel.AutoSize = True
        Me.MedicationLabel.Location = New System.Drawing.Point(291, 243)
        Me.MedicationLabel.Name = "MedicationLabel"
        Me.MedicationLabel.Size = New System.Drawing.Size(59, 13)
        Me.MedicationLabel.TabIndex = 734
        Me.MedicationLabel.Text = "Medication"
        '
        'DueDateLabel
        '
        Me.DueDateLabel.AutoSize = True
        Me.DueDateLabel.Location = New System.Drawing.Point(292, 280)
        Me.DueDateLabel.Name = "DueDateLabel"
        Me.DueDateLabel.Size = New System.Drawing.Size(50, 13)
        Me.DueDateLabel.TabIndex = 735
        Me.DueDateLabel.Text = "DueDate"
        '
        'AlertDateLabel
        '
        Me.AlertDateLabel.AutoSize = True
        Me.AlertDateLabel.Location = New System.Drawing.Point(291, 311)
        Me.AlertDateLabel.Name = "AlertDateLabel"
        Me.AlertDateLabel.Size = New System.Drawing.Size(51, 13)
        Me.AlertDateLabel.TabIndex = 736
        Me.AlertDateLabel.Text = "AlertDate"
        '
        'MidTextBox
        '
        Me.MidTextBox.Location = New System.Drawing.Point(392, 176)
        Me.MidTextBox.Name = "MidTextBox"
        Me.MidTextBox.Size = New System.Drawing.Size(186, 20)
        Me.MidTextBox.TabIndex = 737
        '
        'MedicationTextBox
        '
        Me.MedicationTextBox.Location = New System.Drawing.Point(392, 243)
        Me.MedicationTextBox.Name = "MedicationTextBox"
        Me.MedicationTextBox.Size = New System.Drawing.Size(186, 20)
        Me.MedicationTextBox.TabIndex = 738
        '
        'FlockNoComboBox
        '
        Me.FlockNoComboBox.FormattingEnabled = True
        Me.FlockNoComboBox.Location = New System.Drawing.Point(392, 208)
        Me.FlockNoComboBox.Name = "FlockNoComboBox"
        Me.FlockNoComboBox.Size = New System.Drawing.Size(186, 21)
        Me.FlockNoComboBox.TabIndex = 739
        '
        'DueDate
        '
        Me.DueDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DueDate.Location = New System.Drawing.Point(392, 274)
        Me.DueDate.Name = "DueDate"
        Me.DueDate.Size = New System.Drawing.Size(186, 20)
        Me.DueDate.TabIndex = 740
        '
        'AlertDate
        '
        Me.AlertDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.AlertDate.Location = New System.Drawing.Point(392, 304)
        Me.AlertDate.Name = "AlertDate"
        Me.AlertDate.Size = New System.Drawing.Size(186, 20)
        Me.AlertDate.TabIndex = 741
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(235, 357)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 742
        Me.GroupBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(242, 14)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 2
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 1
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 3
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(1, 447)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(959, 292)
        Me.dgv.TabIndex = 743
        Me.dgv.TabStop = False
        '
        'FrmMedShedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(961, 741)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.AlertDate)
        Me.Controls.Add(Me.DueDate)
        Me.Controls.Add(Me.FlockNoComboBox)
        Me.Controls.Add(Me.MedicationTextBox)
        Me.Controls.Add(Me.MidTextBox)
        Me.Controls.Add(Me.AlertDateLabel)
        Me.Controls.Add(Me.DueDateLabel)
        Me.Controls.Add(Me.MedicationLabel)
        Me.Controls.Add(Me.FlockNoLabel)
        Me.Controls.Add(Me.MidLabel)
        Me.Controls.Add(Me.GroupBox5)
        Me.Name = "FrmMedShedule"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmMedShedule"
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MidLabel As System.Windows.Forms.Label
    Friend WithEvents FlockNoLabel As System.Windows.Forms.Label
    Friend WithEvents MedicationLabel As System.Windows.Forms.Label
    Friend WithEvents DueDateLabel As System.Windows.Forms.Label
    Friend WithEvents AlertDateLabel As System.Windows.Forms.Label
    Friend WithEvents MidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MedicationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FlockNoComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DueDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents AlertDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
End Class
