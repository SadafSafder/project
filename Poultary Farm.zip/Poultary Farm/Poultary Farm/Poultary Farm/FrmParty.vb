﻿Public Class FrmParty
    Dim cmd As New SqlClient.SqlCommand

    Dim dt As New DataTable
    Dim ds As New DataSet
    Private Sub GridView()
        Try

            ' Dim Customer As String

            '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' order by OfficeName", con)
            Dim dasql As New SqlClient.SqlDataAdapter("SELECT AccName FROM Accounts  ", con)
            dasql.Fill(dt)
            Me.dgv.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
    Private Sub GridView1()
        Try
            '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' and OfficeName like '%" & TextBox1.Text & "%' order by OfficeName", con)
            Dim dasql As New SqlClient.SqlDataAdapter("SELECT AccName FROM Accounts where AccName like '%" & TextBox1.Text & "%'  ", con)

            dasql.Fill(dt)
            Me.dgv.DataSource = dt
            'con.Close()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub FrmParty_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        dt.Clear()
    End Sub
    Private Sub FrmParty_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            If FrmPurchase.PurchaseParty = True Then
                FrmPurchase.AccNameTextBox.Text = dgv.CurrentRow.Cells(0).Value
            End If
            'If FrmPurchase.DirectSaleParty = True Then
            'FrmPurchase.CustAccNameTextbox.Text = Me.dgv.CurrentRow.Cells(1).Value
            'End If
            If FrmSale.SaleParty = True Then
                FrmSale.AccNameTextBox.Text = dgv.CurrentRow.Cells(0).Value
            End If

            'FrmLedgerReport.AccaNametxt.Text = Me.dgv.CurrentRow.Cells(1).Value


            Me.Close()
        End If
    End Sub
  
    Private Sub FrmParty_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        GridView()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.TextLength > 1 Then
            dt.Clear()
            GridView1()
            'dt.Select("OfficeName='" & TextBox1.Text & "'")
        Else
            dt.Clear()
            GridView()
        End If
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles dgv.DoubleClick
        If FrmPurchase.PurchaseParty = True Then
            FrmPurchase.AccNameTextBox.Text = dgv.CurrentRow.Cells(1).Value
        End If
        'If FrmPurchase.DirectSaleParty = True Then
        'FrmPurchase.CustAccNameTextbox.Text = Customers_dgv.CurrentRow.Cells(1).Value
        'End If
        If FrmSale.SaleParty = True Then
            FrmSale.AccNameTextBox.Text = dgv.CurrentRow.Cells(1).Value
        End If

        'FrmLedgerReport.AccaNametxt.Text = Customers_dgv.CurrentRow.Cells(1).Value


        Me.Close()
    End Sub
End Class