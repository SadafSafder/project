﻿'Public Class FrmTransaction
'Dim cmdsql As New SqlClient.SqlCommand
'Dim dt As New DataTable
'Dim dt2 As New DataTable
'Private Sub insertion()
' Try
'cmdsql.Connection = con


'cmdsql.CommandText = "INSERT INTO  Transactions (Transid,TransDate,AccName,Description,Debit,Credit,Balance) VALUES  ('" & TransIdTextBox.Text & "','" & TransDate.Text & "','" & AccNameTextBox.Text & "','" & DescriptionTextBox.Text & "' ,'" & DebitTextBox.Text & "','" & CreditTextBox.Text & "','" & BalanceTextBox.Text & "' )"

'cmdsql.ExecuteNonQuery()



'Catch ex As Exception
'MsgBox(" Please Enter Data in Proper Format")

'End Try



'End Sub
'Private Sub id()
'TransIdTextBox.Text = ""
'Dim ed As Double
'cmdsql = New SqlClient.SqlCommand("select isnull(Count(TransId),0) from Transactions where AccName = '" & AccNameTextBox.Text & "' ", con)



'cmdsql = New SqlClient.SqlCommand("select isnull(Count(TransId),0) from Transaction", con)

' ed = cmdsql.ExecuteScalar()


'  ed = ed + 1

'TransIdTextBox.Text = AccNameTextBox.Text
'TransIdTextBox.Text = ed

'End Sub
'Private Sub FrmTransaction_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
'DBConnection()
' SqlGridView()
'End Sub
'Private Sub SqlGridView()

' Try

' dt.Clear()


'Dim daSql As New SqlClient.SqlDataAdapter("SELECT * from Transactions order by TransId desc", con)
'
'daSql.Fill(dt)
'Me.dgv.DataSource = dt

' Catch ex As Exception
'MsgBox(ex.Message)
' End Try
'End Sub
'Function CLEAR_CONTROL()
'  TransIdTextBox.DataBindings.Clear()
' TransDate.DataBindings.Clear()
' AccNameTextBox.DataBindings.Clear()
'  Obalancetxt.DataBindings.Add("text", dt, "balance")
' DescriptionTextBox.DataBindings.Clear()
' DebitTextBox.DataBindings.Clear()
' CreditTextBox.DataBindings.Clear()
'BalanceTextBox.DataBindings.Clear()

' TransIdTextBox.Text = ""
'TransDate.Text = ""
'AccNameTextBox.Text = ""
'DescriptionTextBox.Text = ""
''DebitTextBox.Text = ""
'CreditTextBox.Text = ""
'BalanceTextBox.Text = ""


'Return 0
'End Function

''Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
'If TransIdTextBox.Text <> "" Then
' id()

' insertion()
' CLEAR_CONTROL()
'SqlGridView()
''Else
' MsgBox("Plese Fill All Info")
'End If
'End Sub
'Private Sub updation()
' Try


' cmdsql.Connection = con


' cmdsql.CommandText = "update Transactions set  TransDate='" & TransDate.Text & "',AccName='" & AccNameTextBox.Text & "',Description='" & DescriptionTextBox.Text & "', Debit='" & DebitTextBox.Text & "', Credit='" & CreditTextBox.Text & "', Balance='" & BalanceTextBox.Text & "'  where Transid='" & TransIdTextBox.Text & "' "
'cmdsql.ExecuteNonQuery()

'Catch ex As Exception
' MsgBox(ex.Message)
' End Try
'End Sub
'Private Sub boxvalue()

'CLEAR_CONTROL()
'TransIdTextBox.DataBindings.Add("text", dt, "TransId")
'TransDate.DataBindings.Add("text", dt, "TransDate")
'  Obalancetxt.DataBindings.Add("text", dt, "balance")
' AddressTextBox.DataBindings.Add("text", dt, "type")
'AccNameTextBox.DataBindings.Add("text", dt, "AccName")
'DescriptionTextBox.DataBindings.Add("text", dt, "Description")
'DebitTextBox.DataBindings.Add("text", dt, "Debit")
'CreditTextBox.DataBindings.Add("text", dt, "Credit")
'BalanceTextBox.DataBindings.Add("text", dt, "Balance")

'End Sub

'Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
' If TransIdTextBox.Text <> "" Then

' updation()
'CLEAR_CONTROL()
'SqlGridView()
'Else
' MsgBox("Please Fill All Info")
' End If
'End Sub

'Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
'CLEAR_CONTROL()
'End Sub

'Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
' If TransIdTextBox.Text <> "" Then
'Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
'   If result = DialogResult.Yes Then



' cmdsql.Connection = con
' cmdsql.CommandText = "DELETE  FROM Transactions WHERE TransId= '" & TransIdTextBox.Text & "'   "
' cmdsql.ExecuteNonQuery()
'MsgBox("Delete Successfuly")




'CLEAR_CONTROL()
'SqlGridView()

'  boxvalue()

'Else : result = DialogResult.No
' MsgBox("Delete Cancel")


' End If

'Else
' MsgBox("Please Select Any Contract !!")
'End If
'End Sub
'Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
' boxvalue()

'End Sub
'End Class