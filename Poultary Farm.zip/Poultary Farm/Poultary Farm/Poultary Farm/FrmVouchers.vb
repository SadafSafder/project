﻿Public Class FrmVouchers

    Dim cmdsql As New SqlClient.SqlCommand
    Dim row As Integer
    Dim dt As New DataTable
    Dim dt1 As New DataTable
    Dim dt3 As New DataTable
    Public fr As Boolean = False
    Public tr As Boolean = False
    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(amounttxt.Text)) Then
                cmdsql.CommandText = "INSERT INTO  vouchers (Vchid,AccNameFrom,AccNameTo,Vchamount,Vchtype,vchDate,PaySource,details) VALUES  ('" & idtxt.Text & "','" & AccNameTextbox.Text & "','" & AccNameTotxt.Text & "','" & amounttxt.Text & "','" & TypeTextBox.Text & "','" & datetxt.Text & "','" & pstxt.Text & "','" & detailtxt.Text & "')"

                cmdsql.ExecuteNonQuery()
                cmdsql.Dispose()
            Else
                MsgBox("Please Enter Data in Correct Format")
            End If



        Catch ex As Exception


        End Try


    End Sub

    Private Sub inserttionTransCreditFrom()
        cmdsql.Connection = con
        If (IsNumeric(amounttxt.Text)) Then

            cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & idtxt.Text & "','" & datetxt.Text & "','" & AccNameTextbox.Text & "','" & detailtxt.Text & "','" & amounttxt.Text & "')"

            cmdsql.ExecuteNonQuery()
        Else
            MessageBox.Show("Please Enter Data in Correct Format")
        End If

    End Sub

    Private Sub inserttionTransDebitFrom()
        cmdsql.Connection = con
        If (IsNumeric(amounttxt.Text)) Then

            cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Debit) VALUES  ('" & idtxt.Text & "','" & datetxt.Text & "','" & AccNameTextbox.Text & "','" & detailtxt.Text & "','" & amounttxt.Text & "')"

            cmdsql.ExecuteNonQuery()
        Else
            MessageBox.Show("Please Enter Data in Correct Format")
        End If
    End Sub

    Private Sub inserttionTransCreditTo()
        cmdsql.Connection = con
        If (IsNumeric(amounttxt.Text)) Then

            cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Credit) VALUES  ('" & idtxt.Text & "','" & datetxt.Text & "','" & AccNameTotxt.Text & "','" & detailtxt.Text & "','" & amounttxt.Text & "')"

            cmdsql.ExecuteNonQuery()
        Else
            MessageBox.Show("Please Enter Data in Correct Format")
        End If
    End Sub

    Private Sub inserttionTransDebitto()
        cmdsql.Connection = con
        If (IsNumeric(amounttxt.Text)) Then

            cmdsql.CommandText = "INSERT INTO  transactions (Transid,TransDate,Accname,Description,Debit) VALUES  ('" & idtxt.Text & "','" & datetxt.Text & "','" & AccNameTotxt.Text & "','" & detailtxt.Text & "','" & amounttxt.Text & "')"

            cmdsql.ExecuteNonQuery()
        Else
            MessageBox.Show("Please Enter Data in Correct Format")
        End If
    End Sub

    Private Sub ClearControl()
        AccNameTextbox.Text = ""
        AccNameTotxt.Text = ""
        TypeTextBox.Text = ""
        amounttxt.Text = ""
        detailtxt.Text = ""
        idtxt.Text = ""

    End Sub


    Private Sub AccNoTextbox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        AccSearch.ShowDialog()
    End Sub

    Private Sub AccNoTextbox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub SqlGridView()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM Vouchers where vchDate='" & datetxt.Text & "' ", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub FrmVouchers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        SqlGridView()
        cashInhand()
        Me.KeyPreview = True
    End Sub

    Private Sub cashInhand()
        Try


            Dim a As Decimal

            ''''''''for items qty
            cmdsql = New SqlClient.SqlCommand("select  sum(isnull(Debit,0)) - sum(isnull(Credit,0))  from Transactions where AccName='Cash'", con)




            Label10.Text = cmdsql.ExecuteScalar()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub AccNameTotxt_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles AccNameTotxt.KeyDown
        tr = True
        AccSearch.ShowDialog()

    End Sub

    Private Sub AccNameTotxt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNameTotxt.SelectedIndexChanged

    End Sub

    Private Sub AccNameTextbox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles AccNameTextbox.KeyDown
        fr = True
        AccSearch.ShowDialog()
    End Sub
    Public Sub Invoice()
        Try
            Dim Inv As Double
            cmdsql.Connection = con
            cmdsql.CommandText = "select isnull(Invoice,1) from Inv"
            Inv = cmdsql.ExecuteScalar()
            idtxt.Text = Format(Inv, "")
            '   MessageBox.Show(Inv)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub InvoiceGenerator()
        Try
            Dim Inv As Double
            cmdsql.Connection = con
            cmdsql.CommandText = "select isnull(Invoice,1) from Inv"
            Inv = cmdsql.ExecuteScalar()
            Inv = Inv + 1


            cmdsql.Connection = con
            cmdsql.CommandText = "update Inv set Invoice='" & Inv & "'"
            cmdsql.ExecuteNonQuery()


            MsgBox(Inv)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ccode()
        idtxt.Text = ""
        Dim ed As Double
        cmdsql = New SqlClient.SqlCommand("select isnull(Vchid) from INV", con)


        ed = cmdsql.ExecuteScalar()


        ed = ed + 1

        idtxt.Text = ed
    End Sub
    Private Sub AccNameTextbox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNameTextbox.SelectedIndexChanged

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        If AccNameTextbox.Text <> "" And AccNameTotxt.Text <> "" And amounttxt.Text <> "" And TypeTextBox.Text <> "" Then
            '    ccode()
            Invoice()

            insertion()
            InvoiceGenerator()
            If TypeTextBox.Text = "Credit-" Then

                inserttionTransCreditFrom()

                inserttionTransDebitto()

            End If

            If TypeTextBox.Text = "Debit-" Then

                inserttionTransDebitFrom()
                inserttionTransCreditTo()

            End If
            ' InvoiceGenerator()
            ClearControl()
            SqlGridView()
            cashInhand()

        Else
            MsgBox("Please Fill All info")
        End If


    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ClearControl()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox4_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox4.Enter

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label9.Click

    End Sub
End Class