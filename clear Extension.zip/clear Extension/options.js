document.addEventListener('DOMContentLoaded', () => {
$inputs = document.querySelectorAll('#options input');
	document.getElementById("clearcache").onclick = function() {clearcache()};
restore();
const onChangeInputs =
		document.querySelectorAll('#options [type="checkbox"], #options select');
	const onKeyupInputs =
		document.querySelectorAll('#options [type="checkbox"], #options select');

	for (let i = 0; i < onChangeInputs.length; i++) {
		onChangeInputs[i].addEventListener('change', saveOptions);
	}
	for (let i = 0; i < onKeyupInputs.length; i++) {
		onKeyupInputs[i].addEventListener('keyup', saveOptions);
	}

});
  // Saves options to browser.storage
  const saveOptions = () => {

  	const values = {};

  	for (let i = 0; i < $inputs.length; i++) {
  		const input = $inputs[i];

  		const value =
  			input.type === "checkbox" ? input.checked : input.value;

  		values[input.id] = value;
  	}
    var selectbox=document.getElementById('timeperiod');

    var sel=selectbox.value;
    values['timeperiod']=sel;
  	const options = values;
  	console.log(options);
  	chrome.storage.sync.set(options, () => {

  		// Update status to let user know options were saved.
  		const status = document.getElementById('status');
  		status.className = 'notice';
  		status.textContent = 'Options saved.';
  		setTimeout(() => {
  			status.className += ' invisible';
  		}, 100);


  	});
  }

  function restore(){
    chrome.storage.sync.get(['timeperiod','appcache','cache','cacheStorage','cookies','downloads','filesystems','formdata','history','indexedDB','localStorage','passwords','serviceWorkers','webSQL'], (options) => {
    document.getElementById('timeperiod').value= options.timeperiod;
    document.getElementById('appcache').checked= options.appcache;
    document.getElementById('cache').checked= options.cache;
    document.getElementById('cacheStorage').checked= options.cacheStorage;
    document.getElementById('cookies').checked= options.cookies;
    document.getElementById('downloads').checked= options.downloads;
    document.getElementById('filesystems').checked= options.filesystems;
    document.getElementById('formdata').checked= options.formdata;
    document.getElementById('history').checked= options.history;
    document.getElementById('indexedDB').checked= options.indexedDB;
    document.getElementById('localStorage').checked= options.localStorage;
    document.getElementById('passwords').checked= options.passwords;
    document.getElementById('serviceWorkers').checked= options.serviceWorkers;
    document.getElementById('webSQL').checked= options.webSQL;



  	});


  }

function callback(){

  document.getElementById("msg").style.display="block";
  setTimeout(() => {
    document.getElementById("msg").style.display="none";
  }, 1000);
}


  function clearcache(){

chrome.storage.sync.get(['timeperiod','appcache','cache','cacheStorage','cookies','downloads','filesystems','formdata','history','indexedDB','localStorage','passwords','serviceWorkers','webSQL'], (options) => {
if(options.timeperiod!=="All"){
	var milliseconds = 1000 * 60 * 60 * 24 * parseInt(options.timeperiod);
  var time = (new Date()).getTime() - milliseconds;
	chrome.browsingData.remove(
		{
			"since":time
	},
	 {
		"appcache":options.appcache,
		"cache": options.cache,
		"cacheStorage": options.cacheStorage,
		"cookies": options.cookies,
		"downloads": options.downloads,
		"fileSystems":  options.filesystems,
		"formData":options.formdata,
		"history": options.history,
		"indexedDB": options.indexedDB,
		"localStorage": options.localStorage,
		"passwords": options.passwords,
		"serviceWorkers": options.serviceWorkers,
		"webSQL": options.webSQL
	}, callback);
}else{
	chrome.browsingData.remove(
		{
	},
	 {
	  "appcache":options.appcache,
	  "cache": options.cache,
	  "cacheStorage": options.cacheStorage,
	  "cookies": options.cookies,
	  "downloads": options.downloads,
	  "fileSystems":  options.filesystems,
	  "formData":options.formdata,
	  "history": options.history,
	  "indexedDB": options.indexedDB,
	  "localStorage": options.localStorage,
	  "passwords": options.passwords,
	  "serviceWorkers": options.serviceWorkers,
	  "webSQL": options.webSQL
	}, callback);
}


});

}
