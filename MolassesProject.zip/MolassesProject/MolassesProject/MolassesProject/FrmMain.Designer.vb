﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.Ribbon1 = New System.Windows.Forms.Ribbon()
        Me.RibbonTab1 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel1 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton1 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel14 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton2 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel15 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton3 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel2 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton4 = New System.Windows.Forms.RibbonButton()
        Me.RibbonButton18 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel4 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton13 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab5 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel5 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton5 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel3 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton14 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab7 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel7 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton7 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab8 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel8 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton8 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel9 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton10 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel10 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton9 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel11 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton11 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel18 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton19 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab10 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel13 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton12 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel12 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton15 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel16 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton16 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel17 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton17 = New System.Windows.Forms.RibbonButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RibbonPanel6 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonTab6 = New System.Windows.Forms.RibbonTab()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RibbonButton6 = New System.Windows.Forms.RibbonButton()
        Me.Dgv = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RibbonTextBox1 = New System.Windows.Forms.RibbonTextBox()
        Me.RibbonPanel19 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton20 = New System.Windows.Forms.RibbonButton()
        CType(Me.Dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Ribbon1
        '
        Me.Ribbon1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Ribbon1.Location = New System.Drawing.Point(0, 0)
        Me.Ribbon1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Ribbon1.Minimized = False
        Me.Ribbon1.Name = "Ribbon1"
        '
        '
        '
        Me.Ribbon1.OrbDropDown.BorderRoundness = 8
        Me.Ribbon1.OrbDropDown.Location = New System.Drawing.Point(0, 0)
        Me.Ribbon1.OrbDropDown.Name = ""
        Me.Ribbon1.OrbDropDown.Size = New System.Drawing.Size(527, 447)
        Me.Ribbon1.OrbDropDown.TabIndex = 0
        Me.Ribbon1.OrbImage = Nothing
        Me.Ribbon1.Size = New System.Drawing.Size(1362, 133)
        Me.Ribbon1.TabIndex = 96
        Me.Ribbon1.Tabs.Add(Me.RibbonTab1)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab5)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab7)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab8)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab10)
        Me.Ribbon1.TabsMargin = New System.Windows.Forms.Padding(12, 26, 20, 0)
        Me.Ribbon1.Text = "Ribbon1"
        '
        'RibbonTab1
        '
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel1)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel14)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel15)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel2)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel4)
        Me.RibbonTab1.Text = "Home"
        '
        'RibbonPanel1
        '
        Me.RibbonPanel1.Items.Add(Me.RibbonButton1)
        Me.RibbonPanel1.Text = "Accounts Management"
        '
        'RibbonButton1
        '
        Me.RibbonButton1.Image = Global.MolassesProject.My.Resources.Resources.New_User
        Me.RibbonButton1.SmallImage = CType(resources.GetObject("RibbonButton1.SmallImage"), System.Drawing.Image)
        Me.RibbonButton1.Text = ""
        '
        'RibbonPanel14
        '
        Me.RibbonPanel14.Items.Add(Me.RibbonButton2)
        Me.RibbonPanel14.Text = "Items Management"
        '
        'RibbonButton2
        '
        Me.RibbonButton2.Image = Global.MolassesProject.My.Resources.Resources.Add_item_icon
        Me.RibbonButton2.SmallImage = CType(resources.GetObject("RibbonButton2.SmallImage"), System.Drawing.Image)
        Me.RibbonButton2.Text = ""
        '
        'RibbonPanel15
        '
        Me.RibbonPanel15.Items.Add(Me.RibbonButton3)
        Me.RibbonPanel15.Text = "Vehicle Management"
        '
        'RibbonButton3
        '
        Me.RibbonButton3.Image = Global.MolassesProject.My.Resources.Resources.truck_blue
        Me.RibbonButton3.SmallImage = CType(resources.GetObject("RibbonButton3.SmallImage"), System.Drawing.Image)
        Me.RibbonButton3.Text = ""
        '
        'RibbonPanel2
        '
        Me.RibbonPanel2.Items.Add(Me.RibbonButton4)
        Me.RibbonPanel2.Text = "Contract Management"
        '
        'RibbonButton4
        '
        Me.RibbonButton4.DropDownItems.Add(Me.RibbonButton18)
        Me.RibbonButton4.Image = Global.MolassesProject.My.Resources.Resources.Blog_Image_Handshake__1_
        Me.RibbonButton4.SmallImage = CType(resources.GetObject("RibbonButton4.SmallImage"), System.Drawing.Image)
        Me.RibbonButton4.Text = ""
        '
        'RibbonButton18
        '
        Me.RibbonButton18.Image = CType(resources.GetObject("RibbonButton18.Image"), System.Drawing.Image)
        Me.RibbonButton18.SmallImage = CType(resources.GetObject("RibbonButton18.SmallImage"), System.Drawing.Image)
        Me.RibbonButton18.Text = "RibbonButton18"
        '
        'RibbonPanel4
        '
        Me.RibbonPanel4.Items.Add(Me.RibbonButton13)
        Me.RibbonPanel4.Text = "User Management"
        '
        'RibbonButton13
        '
        Me.RibbonButton13.Image = Global.MolassesProject.My.Resources.Resources.User
        Me.RibbonButton13.SmallImage = CType(resources.GetObject("RibbonButton13.SmallImage"), System.Drawing.Image)
        Me.RibbonButton13.Text = ""
        '
        'RibbonTab5
        '
        Me.RibbonTab5.Panels.Add(Me.RibbonPanel5)
        Me.RibbonTab5.Panels.Add(Me.RibbonPanel3)
        Me.RibbonTab5.Text = "Transactions"
        '
        'RibbonPanel5
        '
        Me.RibbonPanel5.Items.Add(Me.RibbonButton5)
        Me.RibbonPanel5.Text = "Sale Item"
        '
        'RibbonButton5
        '
        Me.RibbonButton5.Image = Global.MolassesProject.My.Resources.Resources.cart_icon1
        Me.RibbonButton5.SmallImage = CType(resources.GetObject("RibbonButton5.SmallImage"), System.Drawing.Image)
        Me.RibbonButton5.Text = "RibbonButton5"
        '
        'RibbonPanel3
        '
        Me.RibbonPanel3.Items.Add(Me.RibbonButton14)
        Me.RibbonPanel3.Text = "Purchase Item"
        '
        'RibbonButton14
        '
        Me.RibbonButton14.Image = Global.MolassesProject.My.Resources.Resources.add_to_basket_512
        Me.RibbonButton14.SmallImage = CType(resources.GetObject("RibbonButton14.SmallImage"), System.Drawing.Image)
        Me.RibbonButton14.Text = "RibbonButton14"
        '
        'RibbonTab7
        '
        Me.RibbonTab7.Panels.Add(Me.RibbonPanel7)
        Me.RibbonTab7.Panels.Add(Me.RibbonPanel19)
        Me.RibbonTab7.Text = "Vouchers"
        '
        'RibbonPanel7
        '
        Me.RibbonPanel7.Items.Add(Me.RibbonButton7)
        Me.RibbonPanel7.Text = "Vouchers"
        '
        'RibbonButton7
        '
        Me.RibbonButton7.Image = Global.MolassesProject.My.Resources.Resources.stock_vector_the_voucher_icon_coupon_and_gift_offer_discount_symbol_flat_vector_illustration_button_3147398421
        Me.RibbonButton7.SmallImage = CType(resources.GetObject("RibbonButton7.SmallImage"), System.Drawing.Image)
        Me.RibbonButton7.Text = "RibbonButton7"
        '
        'RibbonTab8
        '
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel8)
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel9)
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel10)
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel11)
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel18)
        Me.RibbonTab8.Text = "Reports"
        '
        'RibbonPanel8
        '
        Me.RibbonPanel8.Items.Add(Me.RibbonButton8)
        Me.RibbonPanel8.Text = "Sale Report"
        '
        'RibbonButton8
        '
        Me.RibbonButton8.Image = Global.MolassesProject.My.Resources.Resources.invoiced_sales_reports_1_11
        Me.RibbonButton8.SmallImage = CType(resources.GetObject("RibbonButton8.SmallImage"), System.Drawing.Image)
        Me.RibbonButton8.Text = "RibbonButton8"
        '
        'RibbonPanel9
        '
        Me.RibbonPanel9.Items.Add(Me.RibbonButton10)
        Me.RibbonPanel9.Text = "Purchase Report"
        '
        'RibbonButton10
        '
        Me.RibbonButton10.Image = Global.MolassesProject.My.Resources.Resources.purchase_report1
        Me.RibbonButton10.SmallImage = CType(resources.GetObject("RibbonButton10.SmallImage"), System.Drawing.Image)
        Me.RibbonButton10.Text = ""
        '
        'RibbonPanel10
        '
        Me.RibbonPanel10.Items.Add(Me.RibbonButton9)
        Me.RibbonPanel10.Text = "Ledger Report"
        '
        'RibbonButton9
        '
        Me.RibbonButton9.Image = Global.MolassesProject.My.Resources.Resources.ledger_prvws_teaser
        Me.RibbonButton9.SmallImage = CType(resources.GetObject("RibbonButton9.SmallImage"), System.Drawing.Image)
        Me.RibbonButton9.Text = ""
        '
        'RibbonPanel11
        '
        Me.RibbonPanel11.Items.Add(Me.RibbonButton11)
        Me.RibbonPanel11.Text = "Balance Sheet"
        '
        'RibbonButton11
        '
        Me.RibbonButton11.Image = Global.MolassesProject.My.Resources.Resources.Balance_Sheett
        Me.RibbonButton11.SmallImage = CType(resources.GetObject("RibbonButton11.SmallImage"), System.Drawing.Image)
        Me.RibbonButton11.Text = "RibbonButton11"
        '
        'RibbonPanel18
        '
        Me.RibbonPanel18.Items.Add(Me.RibbonButton19)
        Me.RibbonPanel18.Text = "Transportation Report"
        '
        'RibbonButton19
        '
        Me.RibbonButton19.Image = Global.MolassesProject.My.Resources.Resources.Transport_Report
        Me.RibbonButton19.SmallImage = CType(resources.GetObject("RibbonButton19.SmallImage"), System.Drawing.Image)
        Me.RibbonButton19.Text = ""
        '
        'RibbonTab10
        '
        Me.RibbonTab10.Panels.Add(Me.RibbonPanel13)
        Me.RibbonTab10.Panels.Add(Me.RibbonPanel12)
        Me.RibbonTab10.Panels.Add(Me.RibbonPanel16)
        Me.RibbonTab10.Panels.Add(Me.RibbonPanel17)
        Me.RibbonTab10.Text = "Tools"
        '
        'RibbonPanel13
        '
        Me.RibbonPanel13.Items.Add(Me.RibbonButton12)
        Me.RibbonPanel13.Text = "Backup"
        '
        'RibbonButton12
        '
        Me.RibbonButton12.Image = Global.MolassesProject.My.Resources.Resources.download__3_
        Me.RibbonButton12.SmallImage = CType(resources.GetObject("RibbonButton12.SmallImage"), System.Drawing.Image)
        Me.RibbonButton12.Text = "RibbonButton12"
        '
        'RibbonPanel12
        '
        Me.RibbonPanel12.Items.Add(Me.RibbonButton15)
        Me.RibbonPanel12.Text = "Restore"
        '
        'RibbonButton15
        '
        Me.RibbonButton15.Image = Global.MolassesProject.My.Resources.Resources.Restore
        Me.RibbonButton15.SmallImage = CType(resources.GetObject("RibbonButton15.SmallImage"), System.Drawing.Image)
        Me.RibbonButton15.Text = ""
        '
        'RibbonPanel16
        '
        Me.RibbonPanel16.Items.Add(Me.RibbonButton16)
        Me.RibbonPanel16.Text = "Calculator"
        '
        'RibbonButton16
        '
        Me.RibbonButton16.Image = Global.MolassesProject.My.Resources.Resources.calc
        Me.RibbonButton16.SmallImage = CType(resources.GetObject("RibbonButton16.SmallImage"), System.Drawing.Image)
        Me.RibbonButton16.Text = ""
        '
        'RibbonPanel17
        '
        Me.RibbonPanel17.Items.Add(Me.RibbonButton17)
        Me.RibbonPanel17.Text = "Word Pad"
        '
        'RibbonButton17
        '
        Me.RibbonButton17.Image = Global.MolassesProject.My.Resources.Resources.wordpd
        Me.RibbonButton17.SmallImage = CType(resources.GetObject("RibbonButton17.SmallImage"), System.Drawing.Image)
        Me.RibbonButton17.Text = ""
        '
        'Timer1
        '
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(69, 157)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(232, 73)
        Me.Label1.TabIndex = 97
        Me.Label1.Text = "Label1"
        '
        'RibbonPanel6
        '
        Me.RibbonPanel6.Text = "Purchase Item"
        '
        'RibbonTab6
        '
        Me.RibbonTab6.Panels.Add(Me.RibbonPanel6)
        Me.RibbonTab6.Text = "Purchase"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label2.Location = New System.Drawing.Point(69, 240)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 55)
        Me.Label2.TabIndex = 98
        Me.Label2.Text = "Label2"
        '
        'RibbonButton6
        '
        Me.RibbonButton6.Image = CType(resources.GetObject("RibbonButton6.Image"), System.Drawing.Image)
        Me.RibbonButton6.SmallImage = CType(resources.GetObject("RibbonButton6.SmallImage"), System.Drawing.Image)
        Me.RibbonButton6.Text = "RibbonButton6"
        '
        'Dgv
        '
        Me.Dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.Dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.Dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv.Location = New System.Drawing.Point(12, 405)
        Me.Dgv.Name = "Dgv"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.LightBlue
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv.Size = New System.Drawing.Size(417, 307)
        Me.Dgv.TabIndex = 99
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(123, 346)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 20)
        Me.Label3.TabIndex = 100
        Me.Label3.Text = "Contract Alert"
        '
        'RibbonTextBox1
        '
        Me.RibbonTextBox1.TextBoxText = ""
        '
        'RibbonPanel19
        '
        Me.RibbonPanel19.Items.Add(Me.RibbonButton20)
        Me.RibbonPanel19.Text = "Vouchers"
        '
        'RibbonButton20
        '
        Me.RibbonButton20.Image = CType(resources.GetObject("RibbonButton20.Image"), System.Drawing.Image)
        Me.RibbonButton20.SmallImage = CType(resources.GetObject("RibbonButton20.SmallImage"), System.Drawing.Image)
        Me.RibbonButton20.Text = "Vouchers"
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Dgv)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Ribbon1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmMain"
        Me.Text = "FrmMain"
        CType(Me.Dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Ribbon1 As System.Windows.Forms.Ribbon
    Friend WithEvents RibbonTab1 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonTab5 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonTab7 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonTab8 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonTab10 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonPanel1 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton1 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel5 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton5 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel7 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton7 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel8 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton8 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel9 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel10 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton9 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton10 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel11 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton11 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel13 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton12 As System.Windows.Forms.RibbonButton
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents RibbonPanel14 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel15 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel2 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel3 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel6 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton6 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonTab6 As System.Windows.Forms.RibbonTab
    Friend WithEvents RibbonPanel4 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel12 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonPanel16 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton2 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton3 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton4 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton13 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton14 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton15 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonButton16 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel17 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton17 As System.Windows.Forms.RibbonButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RibbonButton18 As System.Windows.Forms.RibbonButton
    Friend WithEvents RibbonPanel18 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton19 As System.Windows.Forms.RibbonButton
    Friend WithEvents Dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents RibbonTextBox1 As System.Windows.Forms.RibbonTextBox
    Friend WithEvents RibbonPanel19 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonButton20 As System.Windows.Forms.RibbonButton
End Class
