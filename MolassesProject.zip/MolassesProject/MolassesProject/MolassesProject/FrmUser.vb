﻿Public Class FrmUser

    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable

    Private Sub insertion()
        Try
            cmdsql.Connection = con
            cmdsql.CommandText = "INSERT INTO  login (username,password,type) VALUES  ('" & usertxt.Text & "','" & passtxt.Text & "','" & typetxt.Text & "' )"

            cmdsql.ExecuteNonQuery()





        Catch ex As Exception
            MsgBox(ex.Message)

        End Try



    End Sub
    Private Sub boxvalue()
        clear()
        idtxt.DataBindings.Clear()
        usertxt.DataBindings.Clear()
        passtxt.DataBindings.Clear()
        typetxt.DataBindings.Clear()



        idtxt.DataBindings.Add("text", dt, "Lid")
        usertxt.DataBindings.Add("text", dt, "username")
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        ' typetxt.DataBindings.Add("text", dt, "type")
        passtxt.DataBindings.Add("text", dt, "password")
        typetxt.DataBindings.Add("text", dt, "type")

    End Sub
    Private Sub updation()

        If usertxt.Text <> "admin" And usertxt.Text <> "Admin" And usertxt.Text <> "ADMIN" Then



            cmdsql.Connection = con
            cmdsql.CommandText = "update login set  username='" & usertxt.Text & "'   where lid='" & idtxt.Text & "'  "
            cmdsql.ExecuteNonQuery()
        End If
        cmdsql.Connection = con
        cmdsql.CommandText = "update login set  password= '" & passtxt.Text & "'  where lid='" & idtxt.Text & "'  "
        cmdsql.ExecuteNonQuery()

        cmdsql.Connection = con
        cmdsql.CommandText = "update login set   type='" & typetxt.Text & "'   where lid='" & idtxt.Text & "'  "
        cmdsql.ExecuteNonQuery()

    End Sub

    Private Sub SqlGridView()

        dt.Clear()


        Dim daSql As New SqlClient.SqlDataAdapter("SELECT * FROM login ", con)

        daSql.Fill(dt)
        Me.dgv.DataSource = dt
    End Sub
    Private Sub clear()
        usertxt.Text = ""
        passtxt.Text = ""
        typetxt.Text = ""
        idtxt.Text = ""

    End Sub
    Private Sub FrmUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DBConnection()
        SqlGridView()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim b As String
        cmdsql = New SqlClient.SqlCommand("select username from login where username='" & usertxt.Text & "'", con)
        b = cmdsql.ExecuteScalar()

        If b = "" Then
            If usertxt.Text <> "" And passtxt.Text <> "" And typetxt.Text <> "" Then
                insertion()
                clear()
                SqlGridView()
            Else
                MsgBox("Please Fill All Information")
            End If


        Else
            MsgBox("This User is Already Exists")

        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If idtxt.Text <> "" Then
            updation()
            clear()
            SqlGridView()
        Else
            MsgBox("Please Select Any User ")
        End If
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()
        ' clear()
    End Sub
End Class