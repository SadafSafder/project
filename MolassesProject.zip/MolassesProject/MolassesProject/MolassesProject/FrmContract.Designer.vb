﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmContract
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label6 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim CidLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Dim SDateLabel As System.Windows.Forms.Label
        Dim EDateLabel As System.Windows.Forms.Label
        Dim RateLabel As System.Windows.Forms.Label
        Dim QtyLabel As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Me.AccNoTextBox = New System.Windows.Forms.ComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.itemtextbox = New System.Windows.Forms.ComboBox()
        Me.statusTextbox = New System.Windows.Forms.ComboBox()
        Me.AlertTextBox = New System.Windows.Forms.DateTimePicker()
        Me.ContractBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MolassesDBDataSet = New MolassesProject.molassesDBDataSet()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.SDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.CidTextBox = New System.Windows.Forms.TextBox()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.ContractTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.ContractTableAdapter()
        Me.EDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.RateTextBox = New System.Windows.Forms.TextBox()
        Me.TableAdapterManager = New MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager()
        Me.QtyTextBox = New System.Windows.Forms.TextBox()
        Me.CntypeTextbox = New System.Windows.Forms.ComboBox()
        Label6 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        CidLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        SDateLabel = New System.Windows.Forms.Label()
        EDateLabel = New System.Windows.Forms.Label()
        RateLabel = New System.Windows.Forms.Label()
        QtyLabel = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        CType(Me.ContractBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label6
        '
        Label6.AutoSize = True
        Label6.Location = New System.Drawing.Point(52, 84)
        Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label6.Name = "Label6"
        Label6.Size = New System.Drawing.Size(83, 15)
        Label6.TabIndex = 132
        Label6.Text = "Account No:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(52, 146)
        Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(77, 15)
        Label4.TabIndex = 131
        Label4.Text = "Item Name"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(52, 210)
        Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(70, 15)
        Label3.TabIndex = 130
        Label3.Text = "Alert Date"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(554, 233)
        Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(47, 15)
        Label2.TabIndex = 129
        Label2.Text = "Status"
        '
        'CidLabel
        '
        CidLabel.AutoSize = True
        CidLabel.Location = New System.Drawing.Point(52, 49)
        CidLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        CidLabel.Name = "CidLabel"
        CidLabel.Size = New System.Drawing.Size(82, 15)
        CidLabel.TabIndex = 111
        CidLabel.Text = "Contract ID:"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(52, 115)
        AccNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(103, 15)
        AccNameLabel.TabIndex = 114
        AccNameLabel.Text = "Account Name:"
        '
        'SDateLabel
        '
        SDateLabel.AutoSize = True
        SDateLabel.Location = New System.Drawing.Point(52, 180)
        SDateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        SDateLabel.Name = "SDateLabel"
        SDateLabel.Size = New System.Drawing.Size(75, 15)
        SDateLabel.TabIndex = 117
        SDateLabel.Text = "Start Date:"
        '
        'EDateLabel
        '
        EDateLabel.AutoSize = True
        EDateLabel.Location = New System.Drawing.Point(554, 168)
        EDateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        EDateLabel.Name = "EDateLabel"
        EDateLabel.Size = New System.Drawing.Size(84, 15)
        EDateLabel.TabIndex = 119
        EDateLabel.Text = "Finish Date:"
        '
        'RateLabel
        '
        RateLabel.AutoSize = True
        RateLabel.Location = New System.Drawing.Point(52, 236)
        RateLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        RateLabel.Name = "RateLabel"
        RateLabel.Size = New System.Drawing.Size(81, 15)
        RateLabel.TabIndex = 123
        RateLabel.Text = "Rate / Mon:"
        '
        'QtyLabel
        '
        QtyLabel.AutoSize = True
        QtyLabel.Location = New System.Drawing.Point(554, 198)
        QtyLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        QtyLabel.Name = "QtyLabel"
        QtyLabel.Size = New System.Drawing.Size(63, 15)
        QtyLabel.TabIndex = 125
        QtyLabel.Text = "Quantity:"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Location = New System.Drawing.Point(554, 136)
        Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(94, 15)
        Label5.TabIndex = 134
        Label5.Text = "Contract Type"
        '
        'AccNoTextBox
        '
        Me.AccNoTextBox.FormattingEnabled = True
        Me.AccNoTextBox.Location = New System.Drawing.Point(176, 81)
        Me.AccNoTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNoTextBox.Name = "AccNoTextBox"
        Me.AccNoTextBox.Size = New System.Drawing.Size(265, 23)
        Me.AccNoTextBox.TabIndex = 0
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(15, 17)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'itemtextbox
        '
        Me.itemtextbox.FormattingEnabled = True
        Me.itemtextbox.Location = New System.Drawing.Point(176, 143)
        Me.itemtextbox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.itemtextbox.Name = "itemtextbox"
        Me.itemtextbox.Size = New System.Drawing.Size(265, 23)
        Me.itemtextbox.TabIndex = 1
        '
        'statusTextbox
        '
        Me.statusTextbox.FormattingEnabled = True
        Me.statusTextbox.Items.AddRange(New Object() {"OnGoing", "finish"})
        Me.statusTextbox.Location = New System.Drawing.Point(666, 228)
        Me.statusTextbox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.statusTextbox.Name = "statusTextbox"
        Me.statusTextbox.Size = New System.Drawing.Size(265, 23)
        Me.statusTextbox.TabIndex = 8
        '
        'AlertTextBox
        '
        Me.AlertTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ContractBindingSource, "SDate", True))
        Me.AlertTextBox.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.AlertTextBox.Location = New System.Drawing.Point(176, 205)
        Me.AlertTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AlertTextBox.Name = "AlertTextBox"
        Me.AlertTextBox.Size = New System.Drawing.Size(265, 21)
        Me.AlertTextBox.TabIndex = 5
        '
        'ContractBindingSource
        '
        Me.ContractBindingSource.DataMember = "Contract"
        Me.ContractBindingSource.DataSource = Me.MolassesDBDataSet
        '
        'MolassesDBDataSet
        '
        Me.MolassesDBDataSet.DataSetName = "molassesDBDataSet"
        Me.MolassesDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(247, 17)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightBlue
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(381, 264)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(368, 63)
        Me.GroupBox1.TabIndex = 128
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(132, 17)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(455, 6)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 24)
        Me.Label1.TabIndex = 127
        Me.Label1.Text = "Contract"
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(-1, 333)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(1260, 205)
        Me.dgv.TabIndex = 126
        Me.dgv.TabStop = False
        '
        'SDateDateTimePicker
        '
        Me.SDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ContractBindingSource, "SDate", True))
        Me.SDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.SDateDateTimePicker.Location = New System.Drawing.Point(176, 175)
        Me.SDateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SDateDateTimePicker.Name = "SDateDateTimePicker"
        Me.SDateDateTimePicker.Size = New System.Drawing.Size(265, 21)
        Me.SDateDateTimePicker.TabIndex = 3
        '
        'CidTextBox
        '
        Me.CidTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ContractBindingSource, "Cid", True))
        Me.CidTextBox.Location = New System.Drawing.Point(176, 49)
        Me.CidTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CidTextBox.Name = "CidTextBox"
        Me.CidTextBox.ReadOnly = True
        Me.CidTextBox.Size = New System.Drawing.Size(192, 21)
        Me.CidTextBox.TabIndex = 113
        Me.CidTextBox.TabStop = False
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ContractBindingSource, "AccName", True))
        Me.AccNameTextBox.Location = New System.Drawing.Point(176, 112)
        Me.AccNameTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(265, 21)
        Me.AccNameTextBox.TabIndex = 112
        Me.AccNameTextBox.TabStop = False
        '
        'ContractTableAdapter
        '
        Me.ContractTableAdapter.ClearBeforeFill = True
        '
        'EDateDateTimePicker
        '
        Me.EDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ContractBindingSource, "EDate", True))
        Me.EDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.EDateDateTimePicker.Location = New System.Drawing.Point(666, 163)
        Me.EDateDateTimePicker.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.EDateDateTimePicker.Name = "EDateDateTimePicker"
        Me.EDateDateTimePicker.Size = New System.Drawing.Size(265, 21)
        Me.EDateDateTimePicker.TabIndex = 4
        '
        'RateTextBox
        '
        Me.RateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ContractBindingSource, "Rate", True))
        Me.RateTextBox.Location = New System.Drawing.Point(176, 233)
        Me.RateTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.RateTextBox.Name = "RateTextBox"
        Me.RateTextBox.Size = New System.Drawing.Size(265, 21)
        Me.RateTextBox.TabIndex = 7
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccountsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContractTableAdapter = Me.ContractTableAdapter
        Me.TableAdapterManager.InvTableAdapter = Nothing
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.PurchaseTableAdapter = Nothing
        Me.TableAdapterManager.SaleTableAdapter = Nothing
        Me.TableAdapterManager.StockTableAdapter = Nothing
        Me.TableAdapterManager.TransactionsTableAdapter = Nothing
        Me.TableAdapterManager.TransportationTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VehicleTableAdapter = Nothing
        Me.TableAdapterManager.VouchersTableAdapter = Nothing
        '
        'QtyTextBox
        '
        Me.QtyTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ContractBindingSource, "Qty", True))
        Me.QtyTextBox.Location = New System.Drawing.Point(666, 195)
        Me.QtyTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.QtyTextBox.Name = "QtyTextBox"
        Me.QtyTextBox.Size = New System.Drawing.Size(265, 21)
        Me.QtyTextBox.TabIndex = 6
        '
        'CntypeTextbox
        '
        Me.CntypeTextbox.FormattingEnabled = True
        Me.CntypeTextbox.Items.AddRange(New Object() {"Sale", "Purchase"})
        Me.CntypeTextbox.Location = New System.Drawing.Point(666, 133)
        Me.CntypeTextbox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.CntypeTextbox.Name = "CntypeTextbox"
        Me.CntypeTextbox.Size = New System.Drawing.Size(265, 23)
        Me.CntypeTextbox.TabIndex = 2
        '
        'FrmContract
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(997, 550)
        Me.Controls.Add(Me.CntypeTextbox)
        Me.Controls.Add(Label5)
        Me.Controls.Add(Me.AccNoTextBox)
        Me.Controls.Add(Label6)
        Me.Controls.Add(Me.itemtextbox)
        Me.Controls.Add(Me.statusTextbox)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.AlertTextBox)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(CidLabel)
        Me.Controls.Add(AccNameLabel)
        Me.Controls.Add(SDateLabel)
        Me.Controls.Add(Me.SDateDateTimePicker)
        Me.Controls.Add(EDateLabel)
        Me.Controls.Add(RateLabel)
        Me.Controls.Add(QtyLabel)
        Me.Controls.Add(Me.CidTextBox)
        Me.Controls.Add(Me.AccNameTextBox)
        Me.Controls.Add(Me.EDateDateTimePicker)
        Me.Controls.Add(Me.RateTextBox)
        Me.Controls.Add(Me.QtyTextBox)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmContract"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmContract"
        CType(Me.ContractBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AccNoTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents itemtextbox As System.Windows.Forms.ComboBox
    Friend WithEvents statusTextbox As System.Windows.Forms.ComboBox
    Friend WithEvents AlertTextBox As System.Windows.Forms.DateTimePicker
    Friend WithEvents ContractBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MolassesDBDataSet As MolassesProject.molassesDBDataSet
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents SDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents CidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ContractTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.ContractTableAdapter
    Friend WithEvents EDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents RateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TableAdapterManager As MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents QtyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CntypeTextbox As System.Windows.Forms.ComboBox
End Class
