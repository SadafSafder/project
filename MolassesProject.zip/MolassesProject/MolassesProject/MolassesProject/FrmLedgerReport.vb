﻿Imports CrystalDecisions.CrystalReports.Engine
Public Class FrmLedgerReport


    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim da As New SqlClient.SqlDataAdapter
    Dim ds As New molassesDBDataSet1
    Dim rpt As New LedgrRpt

    Private Sub search()
        '  Try

        ds.Clear()

        cmdsql.Connection = con
      
        cmdsql.CommandText = "select TransDate,Accname,TransId,Description,(isnull(Debit,0)) as Debit ,(isnull(Credit,0)) as Credit ,(Select isnull(Sum(Debit),0)- isnull(Sum(Credit),0) from Transactions where TransDate < '" & sdatetxt.Text & "' and Accname= '" & AccaNametxt.Text & "' ) as Balance  from  Transactions where Accname= '" & AccaNametxt.Text & "' and  TransDate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "'   "


        cmdsql.CommandType = CommandType.Text
        da.SelectCommand = cmdsql


        da.Fill(ds, "Transactions")
        rpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = rpt
        CrystalReportViewer1.Refresh()
        ' consql.Close()
        ds.Clear()
        '   Catch ex As Exception
        '    MsgBox(ex.Message)
        '    End Try
    End Sub


    Private Sub FrmLedgerReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        FrmCustomerList.ShowDialog()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        search()
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try
            Dim ed As Double
            Dim acc As String
            cmdsql = New SqlClient.SqlCommand("select isnull(Sr,0) from Accounts where Accname='" & AccaNametxt.Text & "' ", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed - 1

            cmdsql = New SqlClient.SqlCommand("select Accname from Accounts where sr='" & ed & "' ", con)


            AccaNametxt.Text = cmdsql.ExecuteScalar()

            search()
        Catch ex As Exception

        End Try
    End Sub

   
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            Dim ed As Double
            Dim acc As String
            cmdsql = New SqlClient.SqlCommand("select isnull(Sr,0) from Accounts where Accname='" & AccaNametxt.Text & "' ", con)


            ed = cmdsql.ExecuteScalar()


            ed = ed + 1

            cmdsql = New SqlClient.SqlCommand("select Accname from Accounts where sr='" & ed & "' ", con)


            AccaNametxt.Text = cmdsql.ExecuteScalar()

            search()
        Catch ex As Exception

        End Try
    End Sub
End Class