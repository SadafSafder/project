﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmItem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim VidLabel As System.Windows.Forms.Label
        Dim VehNoLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ItemIdTextBox = New System.Windows.Forms.TextBox()
        Me.itemTextBox = New System.Windows.Forms.TextBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.AvgRateTextbox = New System.Windows.Forms.TextBox()
        Me.QuantityTextbox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        VidLabel = New System.Windows.Forms.Label()
        VehNoLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'VidLabel
        '
        VidLabel.AutoSize = True
        VidLabel.Location = New System.Drawing.Point(111, 57)
        VidLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        VidLabel.Name = "VidLabel"
        VidLabel.Size = New System.Drawing.Size(19, 15)
        VidLabel.TabIndex = 115
        VidLabel.Text = "Id"
        '
        'VehNoLabel
        '
        VehNoLabel.AutoSize = True
        VehNoLabel.Location = New System.Drawing.Point(111, 87)
        VehNoLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        VehNoLabel.Name = "VehNoLabel"
        VehNoLabel.Size = New System.Drawing.Size(35, 15)
        VehNoLabel.TabIndex = 117
        VehNoLabel.Text = "Item"
        AddHandler VehNoLabel.Click, AddressOf Me.VehNoLabel_Click
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(223, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(151, 24)
        Me.Label1.TabIndex = 118
        Me.Label1.Text = "Add New Items"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(15, 17)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'ItemIdTextBox
        '
        Me.ItemIdTextBox.Location = New System.Drawing.Point(249, 54)
        Me.ItemIdTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ItemIdTextBox.Name = "ItemIdTextBox"
        Me.ItemIdTextBox.ReadOnly = True
        Me.ItemIdTextBox.Size = New System.Drawing.Size(115, 21)
        Me.ItemIdTextBox.TabIndex = 116
        Me.ItemIdTextBox.TabStop = False
        '
        'itemTextBox
        '
        Me.itemTextBox.Location = New System.Drawing.Point(249, 84)
        Me.itemTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.itemTextBox.Name = "itemTextBox"
        Me.itemTextBox.Size = New System.Drawing.Size(223, 21)
        Me.itemTextBox.TabIndex = 0
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(51, 255)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(493, 173)
        Me.dgv.TabIndex = 119
        Me.dgv.TabStop = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(250, 18)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightBlue
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox1.Location = New System.Drawing.Point(116, 172)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(364, 63)
        Me.GroupBox1.TabIndex = 114
        Me.GroupBox1.TabStop = False
        '
        'AvgRateTextbox
        '
        Me.AvgRateTextbox.Location = New System.Drawing.Point(249, 115)
        Me.AvgRateTextbox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AvgRateTextbox.Name = "AvgRateTextbox"
        Me.AvgRateTextbox.Size = New System.Drawing.Size(115, 21)
        Me.AvgRateTextbox.TabIndex = 1
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(111, 118)
        Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(123, 15)
        Label2.TabIndex = 121
        Label2.Text = "Average Rate / KG"
        '
        'QuantityTextbox
        '
        Me.QuantityTextbox.Location = New System.Drawing.Point(249, 145)
        Me.QuantityTextbox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.QuantityTextbox.Name = "QuantityTextbox"
        Me.QuantityTextbox.Size = New System.Drawing.Size(115, 21)
        Me.QuantityTextbox.TabIndex = 2
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(113, 149)
        Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(59, 15)
        Label3.TabIndex = 123
        Label3.Text = "Quantity"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Ivory
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.ForeColor = System.Drawing.Color.Navy
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(133, 18)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(109, 39)
        Me.Button1.TabIndex = 86
        Me.Button1.TabStop = False
        Me.Button1.Text = "Clear"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FrmItem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(596, 428)
        Me.Controls.Add(Me.QuantityTextbox)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.AvgRateTextbox)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(VidLabel)
        Me.Controls.Add(Me.ItemIdTextBox)
        Me.Controls.Add(Me.itemTextBox)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(VehNoLabel)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmItem"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmItem"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ItemIdTextBox As System.Windows.Forms.TextBox
    Friend WithEvents itemTextBox As System.Windows.Forms.TextBox
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents AvgRateTextbox As System.Windows.Forms.TextBox
    Friend WithEvents QuantityTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
