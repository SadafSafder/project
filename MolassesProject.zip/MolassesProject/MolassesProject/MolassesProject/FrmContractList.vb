﻿Public Class FrmContractList
    Dim cmd As New SqlClient.SqlCommand

    Dim dt2 As New DataTable
    Dim dt As New DataTable
    Dim ds As New DataSet
    Dim dsView As New DataView
    Dim bs As New BindingSource
    Dim ContractType As String
    Private Sub GridView()


        ' Dim Customer As String
        If FrmSale.SaleContract = True Then
            ContractType = "Sale"
        End If
        If FrmPurchase.PurchaseContract = True And FrmPurchase.PurComboBox.Text = "Purchase Item" Then
            ContractType = "Purchase"
        End If
        If FrmPurchase.PurchaseContract = True And FrmPurchase.PurComboBox.Text = "Sale Item" Then
            ContractType = "Sale"
        End If

        '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' order by OfficeName", con)
        Dim dasql As New SqlClient.SqlDataAdapter("select * from Contract where CnType='" & ContractType & "' and Status='OnGoing' and Stock > 0 order by AccName", con)
        dasql.Fill(dt)
        Me.Customers_dgv.DataSource = dt

    End Sub

    Private Sub GridView1()

        If FrmSale.SaleContract = True Then
            ContractType = "Sale"
        End If
        If FrmPurchase.PurchaseContract = True And FrmPurchase.PurComboBox.Text = "Purchase Item" Then
            ContractType = "Purchase"
        End If
        If FrmPurchase.PurchaseContract = True And FrmPurchase.PurComboBox.Text = "Sale Item" Then
            ContractType = "Sale"
        End If

        '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' and OfficeName like '%" & TextBox1.Text & "%' order by OfficeName", con)
        Dim dasql As New SqlClient.SqlDataAdapter("select * from Contract where AccName like '%" & TextBox1.Text & "%' and CnType='" & ContractType & "' and Status='OnGoing' and Stock>0 order by AccName", con)

        dasql.Fill(dt)
        Me.Customers_dgv.DataSource = dt
        con.Close()

    End Sub

    Private Sub FrmContractList_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        dt.Clear()
    End Sub

    Private Sub FrmContractList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.Enter Then
            If FrmSale.SaleContract = True Then
                FrmSale.CidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value
            End If
            If FrmPurchase.PurchaseContract = True Then
                FrmPurchase.CidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value
            End If
            FrmSale.SaleContract = False
            FrmPurchase.PurchaseContract = False
            Me.Close()
            'Me.Hide()
        End If

    End Sub

    Private Sub FrmContractList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DBConnection()
        Me.KeyPreview = True
        GridView()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.TextLength > 1 Then
            dt.Clear()
            GridView1()
            'dt.Select("OfficeName='" & TextBox1.Text & "'")
        Else
            dt.Clear()
            GridView()
        End If

    End Sub

    Private Sub Customers_dgv_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Customers_dgv.DoubleClick
        If FrmSale.SaleContract = True Then
            FrmSale.CidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value

        End If
        If FrmPurchase.PurchaseContract = True Then
            FrmPurchase.CidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value

        End If
        FrmSale.SaleContract = False
        FrmPurchase.PurchaseContract = False
                Me.Close()
    End Sub
End Class