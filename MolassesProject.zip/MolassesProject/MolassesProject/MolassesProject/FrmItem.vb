﻿Public Class FrmItem

    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable

    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(QuantityTextbox.Text) And IsNumeric(AvgRateTextbox.Text)) Then

                cmdsql.CommandText = "INSERT INTO  Stock (ItemCode,ItemName,Avgrate,quantity) VALUES  ('" & ItemIdTextBox.Text & "','" & itemTextBox.Text & "','" & AvgRateTextbox.Text & "','" & QuantityTextbox.Text & "' )"

                cmdsql.ExecuteNonQuery()
            Else
                MessageBox.Show("Please Enter Data in Correct Format")
            End If


        Catch ex As Exception
            MsgBox("Please Enter Data in Proper Format")

        End Try



    End Sub

    Private Sub updation()
        Try


            cmdsql.Connection = con
            If (IsNumeric(QuantityTextbox.Text)) Then

                cmdsql.CommandText = "update Stock set  ItemName='" & itemTextBox.Text & "' ,quantity='" & QuantityTextbox.Text & "' where ItemCode='" & ItemIdTextBox.Text & "'  "
                cmdsql.ExecuteNonQuery()
            Else
                MsgBox("Please Enter Data in Proper Format")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub id()
        ItemIdTextBox.Text = ""
        Dim ed As Double
        cmdsql = New SqlClient.SqlCommand("select isnull(max(ItemCode),0) from Stock", con)


        ed = cmdsql.ExecuteScalar()


        ed = ed + 1

        ItemIdTextBox.Text = ed
    End Sub



    Private Sub SqlGridView()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * from Stock ", con)

            daSql.Fill(dt)
            Me.Dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub boxvalue()
        AvgRateTextbox.ReadOnly = True
        CLEAR_CONTROL()
        ItemIdTextBox.DataBindings.Add("text", dt, "ItemCode")
        itemTextBox.DataBindings.Add("text", dt, "ItemName")
        QuantityTextbox.DataBindings.Add("text", dt, "Quantity")


    End Sub


    Function CLEAR_CONTROL()
        ItemIdTextBox.DataBindings.Clear()
        itemTextBox.DataBindings.Clear()
        QuantityTextbox.DataBindings.Clear()

        ItemIdTextBox.Text = ""
        itemTextBox.Text = ""
        QuantityTextbox.Text = ""
        Return 0
    End Function
    Private Sub FrmItem_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DBConnection()
        SqlGridView()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If itemTextBox.Text <> "" And AvgRateTextbox.Text <> "" Then
            id()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please Fill All Info!!")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CLEAR_CONTROL()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If ItemIdTextBox.Text <> "" Then

            updation()
            CLEAR_CONTROL()
            SqlGridView()

        Else
            MsgBox("Please Select any Item !!")

        End If
        AvgRateTextbox.ReadOnly = False
    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()

    End Sub

    Private Sub VehNoLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub itemTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itemTextBox.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CLEAR_CONTROL()
        AvgRateTextbox.ReadOnly = False
    End Sub
End Class