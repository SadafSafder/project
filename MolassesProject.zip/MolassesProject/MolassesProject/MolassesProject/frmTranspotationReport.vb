﻿Public Class frmTranspotationReport
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim da As New SqlClient.SqlDataAdapter
    Dim ds As New molassesDBDataSet1
    Dim rpt As New TransportRpt

    Private Sub search()
        '  Try

        ds.Clear()

        cmdsql.Connection = con

        cmdsql.CommandText = "select * from transportation where tdate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "'   "


        cmdsql.CommandType = CommandType.Text
        da.SelectCommand = cmdsql


        da.Fill(ds, "transportation")
        rpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = rpt
        CrystalReportViewer1.Refresh()
        ' consql.Close()
        ds.Clear()
        '   Catch ex As Exception
        '    MsgBox(ex.Message)
        '    End Try
    End Sub

    Private Sub Vehicle()
        '  Try

        ds.Clear()

        cmdsql.Connection = con

        cmdsql.CommandText = "select * from transportation where tdate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "' and VehNo= '" & ComboBox1.Text & "'  "


        cmdsql.CommandType = CommandType.Text
        da.SelectCommand = cmdsql


        da.Fill(ds, "transportation")
        rpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = rpt
        CrystalReportViewer1.Refresh()
        ' consql.Close()
        ds.Clear()
        '   Catch ex As Exception
        '    MsgBox(ex.Message)
        '    End Try
    End Sub




    Private Sub frmTranspotationReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        box()
    End Sub

    Private Sub box()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT vehNo from vehicle ", con)

            daSql.Fill(dt)
            ComboBox1.DataSource = dt
            ComboBox1.DisplayMember = "VehNo"
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            search()
        End If
        If RadioButton2.Checked = True Then
            Vehicle()
        End If
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class