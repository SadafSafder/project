﻿Public Class FrmPurchaseReport

    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim da As New SqlClient.SqlDataAdapter
    Dim ds As New molassesDBDataSet1
    Dim rpt As New purchaseRpt

    Private Sub search()
        '  Try

        ds.Clear()

        cmdsql.Connection = con

        cmdsql.CommandText = "select pid,Accname,Pdate,item,Prate,Pqty,Pamount,Vehicleno from purchase where pdate between '" & sdatetxt.Text & "' and '" & edatetxt.Text & "'   "


        cmdsql.CommandType = CommandType.Text
        da.SelectCommand = cmdsql



        da.Fill(ds, "Purchase")
        rpt.SetDataSource(ds)
        CrystalReportViewer1.ReportSource = rpt
        CrystalReportViewer1.Refresh()
        ' consql.Close()
        ds.Clear()
        ' Catch ex As Exception
        '    MsgBox(ex.Message)
        ' End Try
    End Sub



    Private Sub FrmPurchaseReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        search()
    End Sub
End Class