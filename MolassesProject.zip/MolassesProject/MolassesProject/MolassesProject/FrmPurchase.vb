﻿Public Class FrmPurchase
    Dim cmd As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim dt3 As New DataTable
    Dim ds As New DataSet
    Dim contQty As Integer
    Dim AvgRate As Decimal
    Dim dt2 As New DataTable
    Public PurchaseParty As Boolean
    Public PurchaseContract As Boolean
    Public DirectSaleParty As Boolean
    Dim Chk As Boolean
    Dim ItemStock As Decimal
    Private Sub PurchaseBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TableAdapterManager.UpdateAll(Me.MolassesDBDataSet)

    End Sub

    Private Sub Vehiclelink()
        Try


            dt2.Clear()
            Dim da2 As New SqlClient.SqlDataAdapter("select VehNo from Vehicle ", con)

            da2.Fill(dt2)



            VehicleNoTextBox.DataBindings.Clear()

            '  itemtextbox.Text = ""




            VehicleNoTextBox.DataSource = dt2
            VehicleNoTextBox.DisplayMember = "VehNo"

            VehicleNoTextBox.SelectedIndex = 0

            '   buttunNotxt.DataBindings.Add("Text", dt, "ButtonNo")





        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub FrmPurchase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MolassesDBDataSet1.Stock' table. You can move, or remove it, as needed.

        'TODO: This line of code loads data into the 'MolassesDBDataSet1.Stock' table. You can move, or remove it, as needed.
        'TODO: This line of code loads data into the 'MolassesDBDataSet.Purchase' table. You can move, or remove it, as needed.
        DirectSaleGroupBox.Enabled = False
        'DBConnection()
        Vehiclelink()
        Invoice()
        FillItemCombo()
        If PurComboBox.Text = "Purchase Item" Then
            GridView()
            Customers_dgv.Show()
            Customers_dgv1.Hide()
        End If
        If PurComboBox.Text = "Sale Item" Then
            GridView()
            Customers_dgv.Hide()
            Customers_dgv1.Show()
        End If

        PurComboBox.SelectedIndex = 0
        ComboItem.SelectedIndex = 0
        ' Button4.Enabled = False


    End Sub
    Public Sub Invoice()
        Try
            Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select isnull(Invoice,0) from Inv"
            Inv = cmd.ExecuteScalar()
            PidTextBox.Text = Format(Inv, "")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub InvoiceGenerator()
        Try
            Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select isnull(Invoice,0) from Inv"
            Inv = cmd.ExecuteScalar()
            Inv = Inv + 1
            cmd.CommandText = "update Inv set Invoice='" & Inv & "'"
            cmd.ExecuteScalar()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ContractQtySelect()
        Try

            cmd.Connection = con
            cmd.CommandText = "select Qty from Contract where Cid='" & CidTextBox.Text & "'"
            contQty = cmd.ExecuteScalar
        Catch ex As Exception

        End Try

    End Sub
    Private Sub FillItemCombo()
        Try

            Dim dasql As New SqlClient.SqlDataAdapter("select * from Stock order by ItemName", con)
            Dim dt As New DataTable
            dasql.Fill(dt)
            If dt.Rows.Count > 0 Then
                ComboItem.DataSource = dt
                ComboItem.DisplayMember = "ItemName"
            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub GridView()
        Try

            dt.Clear()

            ' Dim Customer As String


                        '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' order by OfficeName", con)
            Dim dasql As New SqlClient.SqlDataAdapter("select * from Purchase  where PDate ='" & PDateDateTimePicker.Text & "' order by Pid desc", con)
            dasql.Fill(dt)

            Me.Customers_dgv.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub
    Private Sub GridView1()
        Try

            dt3.Clear()

            ' Dim Customer As String
            'Dim d2 As Date = PDateDateTimePicker.Value.ToString("dd-mm-yyyy")

            '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' order by OfficeName", con)
            Dim dasql As New SqlClient.SqlDataAdapter("select Sid,Cid,AccName, SaleDate, Item, AvgRate, SRate, SQty,SAmount,VehicleNo from Sale where SaleDate='" & PDateDateTimePicker.Text & "' order by Sid Desc ", con)
            dasql.Fill(dt3)
            Me.Customers_dgv1.DataSource = dt3

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub UpdateSale()
        cmd.Connection = con
        Dim PreQty As Decimal
        '///////////////////// Selecting Previous Quatity
        cmd.CommandText = "select SQty from Sale where Sid='" & PidTextBox.Text & "'"
        PreQty = cmd.ExecuteScalar()
        '///////////////////// Delete From Purchase ///////////
        cmd.CommandText = "delete from Sale where Sid='" & PidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '//////////////////////////////////////////////////////
        '/////////////////////// Update Transaction ////////////
        cmd.CommandText = "delete from Transactions where TransId='" & PidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '////////////////////////////////////////////////////////
        '/////////////////////// Update Transportation ////////////
        cmd.CommandText = "delete from Transportation where Tid='" & PidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '////////////////////////////////////////////////////////
        '///////////// Update Contract ///////////////////////
        If CidTextBox.Text <> "" Then
            Dim Stock As Integer
            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
            Stock = cmd.ExecuteScalar
            Stock = Stock + PreQty - PQtyUnitText.Text
            cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid='" & CidTextBox.Text & "'"
            cmd.ExecuteScalar()

        End If
        '////////////////////////////////////////////////////////
        '///////////// Update Stock //////////////////////////
        cmd.Connection = con
        Dim Qty As Integer
        cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
        Qty = cmd.ExecuteScalar
        Qty = Qty + PreQty - PQtyUnitText.Text()
        cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
        cmd.ExecuteScalar()

        '////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        '//////////////////////// Saving Again /////////////////////////////////////////////////////////////////////////
        CheckForm()
        If Chk = True Then

            If RdoContract.Checked = True Then
                InsertSaleNew()
                UpdateTransactionNew()
                UpdateTransportation()
                CheckContract()
                'UpdateContractNew()
                'UpdateStockNew()
            Else
                InsertSaleNew()
                UpdateTransactionNew()
                UpdateTransportation()
                'UpdateStockNew()
                dt3.Clear()
                GridView1()
            End If
            Clear()
        End If

    End Sub
    Private Sub UpdateContractNew()
        Dim Status As String
        cmd.Connection = con
        cmd.CommandText = "select Status from Contract where Cid='" & CidTextBox.Text & "'"
        Status = cmd.ExecuteScalar
        If Status = "Finish" Then
            MessageBox.Show("Contract Finished")
        Else
            Dim Stock As Integer
            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
            Stock = cmd.ExecuteScalar
            Stock = Stock - PQtyUnitText.Text
            If Stock < 0 Then
                MessageBox.Show(" Stock limited ")
            Else
                cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid= ' " & CidTextBox.Text & "'"
                cmd.ExecuteScalar()
                If Stock = 0 Then
                    cmd.CommandText = "update Contract set Status='Finish' where Cid=' " & CidTextBox.Text & "'"
                    cmd.ExecuteScalar()
                End If
            End If

            '        MessageBox.Show(Stock)

        End If
    End Sub
    Private Sub UpdateStockNew()
        Try

            cmd.Connection = con
            Dim Qty As Integer
            cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
            Qty = cmd.ExecuteScalar
            Qty = Qty - PQtyUnitText.Text()
            cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
            cmd.ExecuteScalar()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub InsertSaleNew()
        Try
            '     Dim ContractRate As Integer
            Dim Rate As Decimal
            Dim AvgRate As Decimal

            Rate = PRateTextBox.Text
            cmd.CommandText = "select AvgRate from Stock where ItemName='" & ComboItem.Text & "'"
            AvgRate = cmd.ExecuteScalar
            '/////////////////////////////////////////////////////////////////////////
            cmd.CommandText = "INSERT INTO Sale (Sid,Cid,AccName,SaleDate,Item,AvgRate,SRate,SQty,SAmount,VehicleNo) VALUES('" & PidTextBox.Text & "','" & CidTextBox.Text & "','" & AccNameTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & ComboItem.Text & "','" & AvgRate & "','" & Rate & "','" & PQtyUnitText.Text & "','" & PAmountTextBox.Text & "','" & VehicleNoTextBox.Text & "')"
            cmd.ExecuteNonQuery()
            '       MessageBox.Show("Record Inserted in sale")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub CheckForm()

        If PidTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter ID"
            LabelMesage.Visible = True
            Chk = False
            PidTextBox.Focus()
            Exit Sub

        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If AccNameTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Vendor Name"
            LabelMesage.Visible = True
            Chk = False
            AccNameTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If ComboItem.Text = "" Then
            LabelMesage.Text = "Please Enter Item"
            LabelMesage.Visible = True
            Chk = False
            ComboItem.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If PQtyUnitText.Text = "" Then
            LabelMesage.Text = "Please Enter Quantity"
            LabelMesage.Visible = True
            Chk = False
            PQtyUnitText.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If PRateTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Rate"
            LabelMesage.Visible = True
            Chk = False
            PRateTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If VehicleNoTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Vehicle No"
            LabelMesage.Visible = True
            Chk = False
            VehicleNoTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If FromTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Loading From"
            LabelMesage.Visible = True
            Chk = False
            FromTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If

        If ToTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Destination TO:"
            LabelMesage.Visible = True
            Chk = False
            ToTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If FRateTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Freight Rate"
            LabelMesage.Visible = True
            Chk = False
            FRateTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        '//////////////////////////// For Direct sale /////////////////////////
        If DirectSaleCheckBox.Checked = True Then

            If CustAccNameTextbox.Text = "" Then
                LabelMesage.Text = "Please Enter Customer Name"
                LabelMesage.Visible = True
                Chk = False
                CustAccNameTextbox.Focus()
                Exit Sub
            Else
                LabelMesage.Visible = False
                Chk = True
            End If
            If SRateTextBox.Text = "" Then
                LabelMesage.Text = "Please Enter Sale Rate"
                LabelMesage.Visible = True
                Chk = False
                SRateTextBox.Focus()
                Exit Sub
            Else
                LabelMesage.Visible = False
                Chk = True
            End If

        End If

    End Sub
    Private Sub Unitcalculate()
        Try
            PAmountTextBox.Text = PQtyUnitText.Text * PRateTextBox.Text / 40

        Catch ex As Exception

        End Try

    End Sub
    Private Sub FreightCalculate()
        Try
            FrAmountTextbox.Text = (PQtyUnitText.Text / 1000) * FRateTextbox.Text
            'FrAmountTextbox.Text = FRateTextbox.Text * PQtyTextBox.Text
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Enable()
        PidTextBox.Enabled = True
        CidTextBox.Enabled = True
        AccNameTextBox.Enabled = True
        PRateTextBox.Enabled = True
        PQtyUnitText.Enabled = True
        'PQtyTextBox.Enabled = True
        PAmountTextBox.Enabled = True
        VehicleNoTextBox.Enabled = True
        FromTextbox.Enabled = True
        ToTextbox.Enabled = True
        FRateTextbox.Enabled = True
        FrAmountTextbox.Enabled = True
    End Sub
    Private Sub Disable()
        PidTextBox.Enabled = False
        CidTextBox.Enabled = False
        AccNameTextBox.Enabled = False
        PRateTextBox.Enabled = False
        PQtyUnitText.Enabled = False
        'PQtyTextBox.Enabled = False
        PAmountTextBox.Enabled = False
        VehicleNoTextBox.Enabled = False
        FromTextbox.Enabled = False
        ToTextbox.Enabled = False
        FRateTextbox.Enabled = False
        FrAmountTextbox.Enabled = False
    End Sub
    Private Sub Clear()
        '        PidTextBox.Clear()
        CidTextBox.Clear()
        AccNameTextBox.Clear()
        PRateTextBox.Clear()
        PQtyUnitText.Clear()
        'PQtyTextBox.Clear()
        PAmountTextBox.Clear()
        '  VehicleNoTextBox.Clear()
        FromTextbox.Clear()
        ToTextbox.Clear()
        FRateTextbox.Clear()
        FrAmountTextbox.Clear()
        CRatePerKGTextbox.Clear()
        CustAccNameTextbox.Clear()
        SRateTextBox.Clear()
        SAmountTextbox.Clear()
    End Sub
    Private Sub InsertPurchase()
        Try

            Dim Rate As Integer
            cmd.Connection = con
            '/////////////////////////////////////////////////////////////////////////
            Dim Cid As String
            If RdoContract.Checked = True Then
                Cid = CidTextBox.Text
            Else
                Cid = ""
            End If
            Rate = PRateTextBox.Text
            cmd.CommandText = "INSERT INTO Purchase (Pid,Cid,AccName,PDate,Item,PRate,PQty,PAmount,VehicleNo) VALUES('" & PidTextBox.Text & "','" & Cid & "','" & AccNameTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & ComboItem.Text & "','" & Rate & "','" & PQtyUnitText.Text & "','" & PAmountTextBox.Text & "','" & VehicleNoTextBox.Text & "')"
            cmd.ExecuteNonQuery()
            'MessageBox.Show("Record Inserted")

        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub UpdateContract()
        Try

            Dim Status As String
            cmd.Connection = con
            cmd.CommandText = "select Status from Contract where Cid='" & CidTextBox.Text & "'"
            Status = cmd.ExecuteScalar
            If Status = "Finish" Then
                MessageBox.Show("Contract Finished")
            Else
                Dim Stock As Integer
                cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
                Stock = cmd.ExecuteScalar
                Stock = Stock - PQtyUnitText.Text
                cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid='" & CidTextBox.Text & "'"
                cmd.ExecuteScalar()
                If Stock <= 0 Then
                    cmd.CommandText = "update Contract set Status='Finish' where Cid='" & CidTextBox.Text & "'"
                    cmd.ExecuteScalar()
                End If

            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub CheckContract()
        Dim ChkStatus As Integer
        cmd.Connection = con
        cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
        ChkStatus = cmd.ExecuteScalar

        If ChkStatus <= 0 Then
            MessageBox.Show("Contract is Finished")
            cmd.CommandText = "update Contract set Status='Finish' where Cid='" & CidTextBox.Text & "'"
            cmd.ExecuteScalar()
        End If
    End Sub
    Private Sub UpdateTransaction()
        Try

            cmd.Connection = con
            Dim TID As String
            Dim Transport As String

            TID = "Purchase " & ComboItem.Text

            '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////

            cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & PidTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & AccNameTextBox.Text & "','" & TID & "','" & PAmountTextBox.Text & "')"
            cmd.ExecuteNonQuery()
            '///////////////////////////// Updation of Customer Rocord in Transaction///////////////////
            If DirectSaleCheckBox.Checked = True Then
                TID = "Sale " & ComboItem.Text
            End If

            If DirectSaleCheckBox.Checked = True Then
                cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Debit) values ('" & PidTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & CustAccNameTextbox.Text & "','" & TID & "','" & SAmountTextbox.Text & "')"
                cmd.ExecuteNonQuery()
            End If
            '///////////////////////////// Updation of Transport Record in Transaction ////////////////////
            If DirectSaleCheckBox.Checked = True Then
                Transport = "Purchase Transport " & ComboItem.Text & " From " & AccNameTextBox.Text & " To Party " & CustAccNameTextbox.Text
            Else
                Transport = "Purchase Transport " & ComboItem.Text & " From " & AccNameTextBox.Text & " To Godown"

            End If


            cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & PidTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & Transport & "','" & FrAmountTextbox.Text & "')"
            cmd.ExecuteNonQuery()

        Catch ex As Exception

        End Try

    End Sub
    Private Sub UpdateTransactionNew()
        cmd.Connection = con
        Dim TID As String
        Dim Transport As String
        TID = "Sale" & ComboItem.Text
        Transport = "Sale From Godwon To " & AccNameTextBox.Text
        '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Debit) values ('" & PidTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & AccNameTextBox.Text & "','" & TID & "','" & PAmountTextBox.Text & "')"
        cmd.ExecuteNonQuery()
        '///////////////////////////// Updation of Transport Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & PidTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & Transport & "','" & FrAmountTextbox.Text & "')"
        cmd.ExecuteNonQuery()

    End Sub
    Private Sub UpdateTransportation()
        cmd.Connection = con
        Dim Transport As String
        If PurComboBox.Text = "Purchase Item" Then
            Transport = "Purchase Transport" & ComboItem.Text
        End If

        If PurComboBox.Text = "Sale Item" Then
            Transport = "Sale Transport" & ComboItem.Text
        End If
        '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transportation (Tid,TNature,TDate,VehNo,TFrom,TTO,FRate,Qty,FAmount) values ('" & PidTextBox.Text & "','" & Transport & "','" & PDateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & FromTextbox.Text & "','" & ToTextbox.Text & "','" & FRateTextbox.Text & "','" & PQtyUnitText.Text & "','" & FrAmountTextbox.Text & "')"
        cmd.ExecuteNonQuery()

    End Sub
    Private Sub UpdateStock()
        cmd.Connection = con
        'Dim ItemQty As Decimal
        'cmd.CommandText = "select PQty from Purchase where Cid='" & CidTextBox.Text & "'"
        'ItemQty = cmd.ExecuteScalar

        Dim Qty As Integer
        cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
        Qty = cmd.ExecuteScalar
        If PurComboBox.Text = "Purchase Item" Then
            Qty = Qty + PQtyUnitText.Text()
        End If
        If PurComboBox.Text = "Sale Item" Then
            Qty = Qty - PQtyUnitText.Text()
        End If

        cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
        cmd.ExecuteScalar()

    End Sub
    Private Sub ContractSelect()
        '////////////////////////////////////////////
        If CidTextBox.Text = "" Then
        Else
            Dim Rt As Integer
            Dim Cntyp As String
            If PurComboBox.Text = "Purchase Item" Then
                Cntyp = "Purchase"
            End If
            If PurComboBox.Text = "Sale Item" Then
                Cntyp = "Sale"
            End If
            cmd.Connection = con
            cmd.CommandText = "select Rate from Contract where Cid='" & CidTextBox.Text & "' and CnType='" & Cntyp & "'"
            Rt = cmd.ExecuteScalar()
            CRatePerKGTextbox.Text = Rt

            cmd.CommandText = "select AccName from Contract where Cid='" & CidTextBox.Text & "'and CnType='" & Cntyp & "'"
            AccNameTextBox.Text = cmd.ExecuteScalar
            cmd.CommandText = "select Item from Contract where Cid='" & CidTextBox.Text & "' and CnType='" & Cntyp & "'"
            ComboItem.Text = cmd.ExecuteScalar

            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "' and CnType='" & Cntyp & "'"
            LblRemQty.Text = cmd.ExecuteScalar
            ComboItem.Enabled = False

        End If

    End Sub
    Private Sub CheckParty()
        If RdoContract.Checked = False Then
            'CidTextBox.Text = ""
            '            CidTextBox.Enabled = False
            CidTextBox.ReadOnly = True
            AccNameTextBox.Enabled = True
            AccNameTextBox.ReadOnly = False
            ComboItem.Enabled = True
            CRatePerKGTextbox.Enabled = False
            PRateTextBox.Enabled = True
            Clear()
        Else
            'CidTextBox.Enabled = True
            CidTextBox.ReadOnly = False
            AccNameTextBox.Enabled = False
            ComboItem.Enabled = False
            CRatePerKGTextbox.Enabled = False
            PRateTextBox.Enabled = False
            Clear()
        End If
    End Sub
    Private Sub InsertSale()
        Try

            cmd.Connection = con
            '/////////////////////////////////////////////////////////////////////////
            InsertAvgRate()

            cmd.CommandText = "INSERT INTO Sale (Sid,Cid,AccName,SaleDate,Item,AvgRate,SRate,SQty,SAmount,VehicleNo) VALUES('" & PidTextBox.Text & "','" & CidTextBox.Text & "','" & AccNameTextBox.Text & "','" & PDateDateTimePicker.Text & "','" & ComboItem.Text & "','" & AvgRate & "','" & SRateTextBox.Text & "','" & PQtyUnitText.Text & "','" & SAmountTextbox.Text & "','" & VehicleNoTextBox.Text & "')"
            cmd.ExecuteNonQuery()
            '       MessageBox.Show("Record Inserted")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub CalculateAvgRate()
        cmd.Connection = con
        cmd.CommandText = "select AvgRate from Stock where ItemName='" & ComboItem.Text & "'"
        AvgRate = cmd.ExecuteScalar()
        LabelAvgRate.Text = AvgRate
    End Sub
    Private Sub InsertAvgRate()
        Dim TotalAmount As Decimal
        '  Dim CAvgRate As Decimal
        Dim StQty As Decimal
        Dim Avg As Decimal
        Dim Amt As Decimal
        cmd.Connection = con
        cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "'"
        StQty = cmd.ExecuteScalar()

        cmd.CommandText = "select AvgRate from Stock where ItemName='" & ComboItem.Text & "'"
        Avg = cmd.ExecuteScalar()

        Amt = StQty * Avg

        TotalAmount = Int(PAmountTextBox.Text) + Int(FrAmountTextbox.Text)
        '  MessageBox.Show(TotalAmount)
        AvgRate = (Amt + PAmountTextBox.Text) / (StQty + PQtyUnitText.Text)
        'MessageBox.Show(CAvgRate)
        cmd.CommandText = "update Stock set AvgRate='" & AvgRate & "' where ItemName='" & ComboItem.Text & "'"
        cmd.ExecuteNonQuery()
    End Sub
    Private Sub CheckAndCalUnit()
        Try
            PAmountTextBox.Text = PQtyUnitText.Text * PRateTextBox.Text
            
        Catch ex As Exception

        End Try

    End Sub
    Private Sub LoadGridInfo()
        Try

            cmd.Connection = con
            PidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value
            CidTextBox.Text = Customers_dgv.CurrentRow.Cells(1).Value
            AccNameTextBox.Text = Customers_dgv.CurrentRow.Cells(2).Value
            PDateDateTimePicker.Text = Customers_dgv.CurrentRow.Cells(3).Value
            ComboItem.Text = Customers_dgv.CurrentRow.Cells(4).Value
            PRateTextBox.Text = Customers_dgv.CurrentRow.Cells(5).Value
            PQtyUnitText.Text = Customers_dgv.CurrentRow.Cells(6).Value
            PAmountTextBox.Text = Customers_dgv.CurrentRow.Cells(7).Value
            VehicleNoTextBox.Text = Customers_dgv.CurrentRow.Cells(8).Value
            '/////////////////////// Contract / Party Select //////////////////
            If Customers_dgv.CurrentRow.Cells(1).Value = "" Then
                RdoParty.Checked = True
            Else
                RdoContract.Checked = True
            End If
            '////////////////////////////////////////////////////////////////
            '///////////////// Transportation Select ////////////////////////
            cmd.CommandText = "select TFrom from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FromTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select TTO from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            ToTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FRate from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FRateTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FAmount from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FrAmountTextbox.Text = cmd.ExecuteScalar
            '//////////////////////// Direct Sale Select /////////////////////
            Dim ch As String
            cmd.CommandText = "select Sid from Sale where Sid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            ch = cmd.ExecuteScalar()
            '   MessageBox.Show(ch)
            If ch = "" Then
                DirectSaleCheckBox.Checked = False
                DirectSaleGroupBox.Enabled = False
                CustAccNameTextbox.Clear()
                SRateTextBox.Clear()
                SAmountTextbox.Clear()
            Else
                '        MessageBox.Show("Entered")
                DirectSaleGroupBox.Enabled = True
                DirectSaleCheckBox.Checked = True
                cmd.CommandText = "select AccName from Sale where Sid='" & ch & "'"
                CustAccNameTextbox.Text = cmd.ExecuteScalar

                cmd.CommandText = "select SRate from Sale where Sid='" & ch & "'"
                SRateTextBox.Text = cmd.ExecuteScalar

                cmd.CommandText = "select SAmount from Sale where Sid='" & ch & "'"
                SAmountTextbox.Text = cmd.ExecuteScalar
            End If

            Dim CnTp As String
            cmd.CommandText = "select CnType from Contract where Cid='" & CidTextBox.Text & "'"
            CnTp = cmd.ExecuteScalar()
            If CnTp = "Purchase" Then
                PurComboBox.SelectedIndex = 0
            End If
            If CnTp = "Sale" Then
                PurComboBox.SelectedIndex = 1
            End If

        Catch ex As Exception

        End Try

    End Sub
    Private Sub LoadGridInfo1()
        Try

            cmd.Connection = con
            PidTextBox.Text = Customers_dgv1.CurrentRow.Cells(0).Value
            CidTextBox.Text = Customers_dgv1.CurrentRow.Cells(1).Value
            AccNameTextBox.Text = Customers_dgv1.CurrentRow.Cells(2).Value
            PDateDateTimePicker.Text = Customers_dgv1.CurrentRow.Cells(3).Value
            ComboItem.Text = Customers_dgv1.CurrentRow.Cells(4).Value
            PRateTextBox.Text = Customers_dgv1.CurrentRow.Cells(6).Value
            PQtyUnitText.Text = Customers_dgv1.CurrentRow.Cells(7).Value
            PAmountTextBox.Text = Customers_dgv1.CurrentRow.Cells(8).Value
            VehicleNoTextBox.Text = Customers_dgv1.CurrentRow.Cells(9).Value
            
            '/////////////////////// Contract / Party Select //////////////////
            If Customers_dgv1.CurrentRow.Cells(1).Value = "" Then
                RdoParty.Checked = True
            Else
                RdoContract.Checked = True
            End If
            '////////////////////////////////////////////////////////////////
            '///////////////// Transportation Select ////////////////////////
            cmd.CommandText = "select TFrom from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FromTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select TTO from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            ToTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FRate from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FRateTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FAmount from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FrAmountTextbox.Text = cmd.ExecuteScalar


        Catch ex As Exception

        End Try

    End Sub
    Private Sub UpdatePurchase()
        Try

            cmd.Connection = con
            Dim ItemQty As Decimal
            cmd.CommandText = "select PQty from Purchase where Cid='" & CidTextBox.Text & "'"
            ItemQty = cmd.ExecuteScalar
            '///////////////////// Delete From Purchase ///////////
            cmd.CommandText = "delete from Purchase where Pid='" & PidTextBox.Text & "'"
            cmd.ExecuteNonQuery()
            '//////////////////////////////////////////////////////
            '/////////////////////// Update Transaction ////////////
            cmd.CommandText = "delete from Transactions where TransId='" & PidTextBox.Text & "'"
            cmd.ExecuteNonQuery()
            '////////////////////////////////////////////////////////
            '/////////////////////// Update Transportation ////////////
            cmd.CommandText = "delete from Transportation where Tid='" & PidTextBox.Text & "'"
            cmd.ExecuteNonQuery()
            '////////////////////////////////////////////////////////
            '///////////// Update Contract ///////////////////////
            If CidTextBox.Text <> "" Then
                Dim Stock As Integer
                cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
                Stock = cmd.ExecuteScalar
                Stock = Stock - ItemQty + PQtyUnitText.Text
                cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid='" & CidTextBox.Text & "'"
                cmd.ExecuteScalar()

            End If
            '////////////////////////////////////////////////////////
            '///////////// Update Stock //////////////////////////
            cmd.Connection = con
            Dim Qty As Integer
            cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
            Qty = cmd.ExecuteScalar
            Qty = Qty + ItemQty - PQtyUnitText.Text
            cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
            cmd.ExecuteScalar()


            '////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            '//////////////////////// Saving Again /////////////////////////////////////////////////////////////////////////
            CheckForm()
            If Chk = True Then
                InsertPurchase()

                If RdoContract.Checked = True Then
                    CheckContract()
                    'UpdateContract()
                End If
                If DirectSaleCheckBox.Checked = True Then
                    InsertSale()
                Else
                    'UpdateStock()
                    InsertAvgRate()
                End If
                UpdateTransaction()
                UpdateTransportation()


                ComboItem.Enabled = True
                Clear()
                DirectSaleCheckBox.Checked = False
                DirectSaleGroupBox.Enabled = False
                dt.Clear()
                GridView()
            Else
                '   MessageBox.Show("Entry Missing")
            End If
            '    InvoiceGenerator()
            Invoice()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
    Private Sub CheckItemStock()
        Try
            cmd.Connection = con
            cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "'"
            ItemStock = cmd.ExecuteScalar()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

        CheckForm()
        If Chk = True Then
            If PurComboBox.Text = "Purchase Item" Then

                InsertPurchase()

                If RdoContract.Checked = True Then
                    CheckContract()
                    UpdateContract()
                End If
                If DirectSaleCheckBox.Checked = True Then
                    InsertSale()
                Else
                    UpdateStock()
                    InsertAvgRate()
                End If
                UpdateTransaction()
                UpdateTransportation()


                ComboItem.Enabled = True
                Clear()
                DirectSaleCheckBox.Checked = False
                DirectSaleGroupBox.Enabled = False
                dt.Clear()
                GridView()
            Else
                '   MessageBox.Show("Entry Missing")
            End If


            '////////////////////////////////// Sale Item Code ///////////////////
            '/////////////////////////////////////////////////////////////////////
            If PurComboBox.Text = "Sale Item" Then
                Dim qt As Integer
                'Dim CNQTY As Integer
                'CNQTY = 1
                'If RdoContract.Checked = True Then
                'CNQTY = LblRemQty.Text
                'End If

                'qt = LblItemStock.Text
                If Chk = True Then

                    If contQty > 0 And ItemStock > 0 Then

                        If RdoContract.Checked = True Then
                            '                    InsertSale()
                            InsertSaleNew()
                            'UpdateTransaction()
                            UpdateTransactionNew()
                            UpdateTransportation()
                            '  CheckContract()
                            UpdateContract()
                            UpdateStock()
                            dt.Clear()
                            GridView()
                        Else
                            'InsertSale()
                            InsertSaleNew()
                            '                            UpdateTransaction()
                            UpdateTransactionNew()
                            UpdateTransportation()
                            UpdateStock()
                            dt.Clear()
                            GridView()
                        End If

                        '       Clear()
                        '      InvoiceGenerator()
                        '     Invoice()
                    Else
                        MessageBox.Show("Stock is Over")
                    End If


                End If


                RdoParty.Checked = True

            End If
            Clear()
            InvoiceGenerator()
            Invoice()
        End If
    End Sub
    Private Sub CidTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CidTextBox.TextChanged
        ContractSelect()
        CalculateAvgRate()
        ContractQtySelect()
        LblConQty.Text = contQty
    End Sub
    Private Sub FRateTextbox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FRateTextbox.TextChanged

        FreightCalculate()
        '     enableSave()
    End Sub
    Private Sub RdoContract_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdoContract.CheckedChanged
        BtnContract.Enabled = True
        BtnParty.Enabled = False
        CheckParty()
    End Sub
    Private Sub RdoParty_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdoParty.CheckedChanged
        BtnContract.Enabled = False
        BtnParty.Enabled = True
        PRateTextBox.Enabled = True
        CheckParty()
    End Sub
    Private Sub BtnContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnContract.Click
        PurchaseParty = False
        PurchaseContract = True
        FrmContractList.ShowDialog()
    End Sub
    Private Sub BtnParty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnParty.Click
        PurchaseParty = True
        PurchaseContract = False
        FrmCustomerList.ShowDialog()
    End Sub
    Private Sub DirectSaleCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DirectSaleCheckBox.CheckedChanged
        If DirectSaleCheckBox.Checked = True Then
            DirectSaleGroupBox.Enabled = True
        Else
            DirectSaleGroupBox.Enabled = False
        End If
        CheckForm()

    End Sub
    Private Sub BtnDirectSaleParty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDirectSaleParty.Click
        DirectSaleParty = True
        FrmCustomerList.ShowDialog()
    End Sub
    Private Sub ComboItem_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboItem.TextChanged
        Unitcalculate()
        CalculateAvgRate()
        CheckItemStock()
        LblItemStock.Text = ItemStock

    End Sub
    Private Sub SRateTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SRateTextBox.TextChanged
        Try
            ' If SRateTextBox.Text <> "" Then
            SAmountTextbox.Text = (SRateTextBox.Text * PQtyUnitText.Text) / 40
            'End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub CRatePerKGTextbox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CRatePerKGTextbox.TextChanged
        Try

            If RdoContract.Checked = True Then

                PRateTextBox.Text = CRatePerKGTextbox.Text
            End If
        Catch ex As Exception

        End Try


    End Sub
    Private Sub AccNameTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNameTextBox.TextChanged
        ' CalculateAvgRate()
        CheckItemStock()
        LblItemStock.Text = ItemStock
    End Sub
    Private Sub SAmountTextbox_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles SAmountTextbox.LostFocus
        'enableSave()
        Button4.Focus()
    End Sub
    Private Sub PQtyUnitText_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PQtyUnitText.TextChanged
        Unitcalculate()
        FreightCalculate()
    End Sub
    Private Sub PRateTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRateTextBox.TextChanged
        Unitcalculate()
    End Sub
    Private Sub PidTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PidTextBox.TextChanged
        CalculateAvgRate()
    End Sub
    Private Sub Customers_dgv_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Customers_dgv.DoubleClick
        LoadGridInfo()
    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If PurComboBox.Text = "Purchase Item" Then

            UpdatePurchase()


            ComboItem.Enabled = True
            Clear()
            DirectSaleCheckBox.Checked = False
            DirectSaleGroupBox.Enabled = False
            dt.Clear()
            GridView()
        End If
        ' End If
        If PurComboBox.Text = "Sale Item" Then
            UpdateSale()
            Clear()
            dt3.Clear()
            GridView1()
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Clear()
        Invoice()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
    Private Sub PurComboBox_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PurComboBox.TextChanged

        If PurComboBox.Text = "Purchase Item" Then
            DirectSaleCheckBox.Enabled = True
            DirectSaleGroupBox.Enabled = True
            Customers_dgv1.Hide()
            Customers_dgv.Show()
            GridView()
        End If
        If PurComboBox.Text = "Sale Item" Then
            DirectSaleCheckBox.Enabled = False
            DirectSaleGroupBox.Enabled = False
            GridView1()
            Customers_dgv.Hide()

            Customers_dgv1.Show()

        End If
    End Sub
    Private Sub Customers_dgv1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Customers_dgv1.CellDoubleClick
        LoadGridInfo1()
    End Sub
    Private Sub Customers_dgv1_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Customers_dgv1.RowHeaderMouseDoubleClick
        LoadGridInfo1()
    End Sub
    Private Sub ComboItem_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboItem.SelectedIndexChanged

    End Sub
    Private Sub PurComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PurComboBox.SelectedIndexChanged
        If PurComboBox.Text = "Purchase Item" Then
            DirectSaleCheckBox.Enabled = True
            DirectSaleGroupBox.Enabled = True
            Customers_dgv1.Hide()
            Customers_dgv.Show()
            GridView()
        End If
        If PurComboBox.Text = "Sale Item" Then
            DirectSaleCheckBox.Enabled = False
            DirectSaleGroupBox.Enabled = False
            GridView1()
            Customers_dgv.Hide()

            Customers_dgv1.Show()

        End If

    End Sub

    Private Sub PAmountTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAmountTextBox.TextChanged

    End Sub
End Class