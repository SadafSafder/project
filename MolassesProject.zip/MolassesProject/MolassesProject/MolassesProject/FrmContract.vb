﻿Public Class FrmContract

    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt2 As New DataTable
    Dim dt As New DataTable

    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(QtyTextBox.Text) And IsNumeric(RateTextBox.Text)) Then

                cmdsql.CommandText = "INSERT INTO  contract (cid,AccName,item,Sdate,Edate,Rate,Qty,Alert,Status,Cntype,Stock,AccNo) VALUES  ('" & CidTextBox.Text & "','" & AccNameTextBox.Text & "','" & itemtextbox.Text & "','" & SDateDateTimePicker.Text & "' ,'" & EDateDateTimePicker.Text & "','" & RateTextBox.Text & "','" & QtyTextBox.Text & "','" & AlertTextBox.Text & "','" & statusTextbox.Text & "','" & CntypeTextbox.Text & "','" & QtyTextBox.Text & "','" & AccNoTextBox.Text & "' )"

                cmdsql.ExecuteNonQuery()
            Else
                MessageBox.Show("Please Enter Data in Correct Format")

            End If



        Catch ex As Exception
            MsgBox(" Please Enter Data in Proper Format")

        End Try



    End Sub
    Private Sub updation()
        Try


            cmdsql.Connection = con
            If (IsNumeric(QtyTextBox.Text) And IsNumeric(RateTextBox.Text)) Then

                cmdsql.CommandText = "update Contract set AccName='" & AccNameTextBox.Text & "',AccNo='" & AccNoTextBox.Text & "',cntype='" & CntypeTextbox.Text & "', item='" & itemtextbox.Text & "', Sdate='" & SDateDateTimePicker.Text & "', Edate='" & EDateDateTimePicker.Text & "' , Alert='" & AlertTextBox.Text & "', Qty='" & QtyTextBox.Text & "' , Rate='" & RateTextBox.Text & "',status='" & statusTextbox.Text & "'  where cid='" & CidTextBox.Text & "'  "
                cmdsql.ExecuteNonQuery()
            Else
                MessageBox.Show("Please Enter Data in Correct Format")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub SqlGridView()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * from Contract order by Sr desc", con)

            daSql.Fill(dt)
            Me.dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub boxvalue()

        CLEAR_CONTROL()
        CidTextBox.DataBindings.Add("text", dt, "cid")
        AccNoTextBox.DataBindings.Add("text", dt, "AccNO")
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        ' AddressTextBox.DataBindings.Add("text", dt, "type")
        AccNameTextBox.DataBindings.Add("text", dt, "AccName")
        SDateDateTimePicker.DataBindings.Add("text", dt, "Sdate")
        EDateDateTimePicker.DataBindings.Add("text", dt, "Edate")
        AlertTextBox.DataBindings.Add("text", dt, "Alert")
        statusTextbox.DataBindings.Add("text", dt, "Status")
        itemtextbox.DataBindings.Add("text", dt, "item")
        RateTextBox.DataBindings.Add("text", dt, "Rate")
        QtyTextBox.DataBindings.Add("text", dt, "Qty")
        CntypeTextbox.DataBindings.Add("text", dt, "Cntype")
    End Sub


    Function CLEAR_CONTROL()
        CidTextBox.DataBindings.Clear()
        AccNoTextBox.DataBindings.Clear()
        CntypeTextbox.DataBindings.Clear()
        AccNameTextBox.DataBindings.Clear()
        SDateDateTimePicker.DataBindings.Clear()
        EDateDateTimePicker.DataBindings.Clear()
        AlertTextBox.DataBindings.Clear()
        itemtextbox.DataBindings.Clear()
        statusTextbox.DataBindings.Clear()
        RateTextBox.DataBindings.Clear()
        QtyTextBox.DataBindings.Clear()

        '  dt.Clear()
        CidTextBox.Text = ""
        AccNameTextBox.Text = ""
        AccNoTextBox.Text = ""
        RateTextBox.Text = ""
        QtyTextBox.Text = ""

        CntypeTextbox.Text = ""
        itemtextbox.Text = ""
        SDateDateTimePicker.Text = ""
        EDateDateTimePicker.Text = ""
        AlertTextBox.Text = ""
        statusTextbox.Text = ""

        Return 0
    End Function
    Private Sub ccode()
        CidTextBox.Text = ""
        Dim ed As String
        cmdsql = New SqlClient.SqlCommand("select isnull(Count(Cid),0) from Contract where AccNo = '" & AccNoTextBox.Text & "' ", con)


        ed = cmdsql.ExecuteScalar()


        ed = ed + 1


        CidTextBox.Text = AccNoTextBox.Text + "-" + ed
    End Sub
    Private Sub itemlink()
        Try


            dt2.Clear()
            Dim da2 As New SqlClient.SqlDataAdapter("select ItemName from Stock ", con)

            da2.Fill(dt2)



            itemtextbox.DataBindings.Clear()

            '  itemtextbox.Text = ""




            itemtextbox.DataSource = dt2
            itemtextbox.DisplayMember = "ItemName"

            itemtextbox.SelectedIndex = 0

            '   buttunNotxt.DataBindings.Add("Text", dt, "ButtonNo")





        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub


    Private Sub FrmContract_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DBConnection()
        SqlGridView()
        itemlink()
        Me.KeyPreview = True
        CntypeTextbox.SelectedIndex = 1
        statusTextbox.SelectedIndex = 0
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If AccNameTextBox.Text <> "" Then
            ccode()

            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Plese Fill All Info")
        End If

    End Sub

    Private Sub AccNoTextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles AccNoTextBox.KeyDown
        AccSearch.ShowDialog()
    End Sub

    Private Sub AccNoTextBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNoTextBox.SelectedIndexChanged

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If AccNameTextBox.Text <> "" Then

            updation()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please Fill All Info")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If CidTextBox.Text <> "" Then
            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM contract WHERE cid= '" & CidTextBox.Text & "'   "
                cmdsql.ExecuteNonQuery()
                MsgBox("Delete Successfuly")




                CLEAR_CONTROL()
                SqlGridView()

                '  boxvalue()

            Else : result = DialogResult.No
                ' MsgBox("Delete Cancel")


            End If

        Else
            MsgBox("Please Select Any Contract !!")
        End If
    End Sub

    Private Sub itemtextbox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles itemtextbox.GotFocus
        itemlink()
    End Sub

    Private Sub itemtextbox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itemtextbox.SelectedIndexChanged

    End Sub

    Private Sub dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellContentClick

    End Sub

    Private Sub dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgv.RowHeaderMouseDoubleClick
        boxvalue()

    End Sub

    Private Sub RateTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RateTextBox.TextChanged

    End Sub
End Class