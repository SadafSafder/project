﻿Module Module1
    Public con As New SqlClient.SqlConnection
    ' Dim cmd As New SqlClient.SqlCommand

    Public Sub DBConnection()
        'Acces DataBase Connectivity and for MS Access 2003 PROVIDER=Microsoft.Jet.OLEDB.4.0
        Try
            'con.ConnectionString = "Data Source=chaudhary\ASAD;Initial Catalog=molassesDB;Persist Security Info=True;User ID=sa;Password=1234"
            'con.ConnectionString = "Data Source=DESKTOP-9NKCNF4;Initial Catalog=molassesDB;Persist Security Info=True;User ID=sa;Password=12345"
            con.ConnectionString = "Data Source=DESKTOP-4PUB20G\SQLEXPRESS;Initial Catalog=molassesDB;Persist Security Info=True;User ID=sa;Password=12345"
            ' cmd.Connection = con
            con.Open()
            '  MessageBox.Show(con.State.ToString())
        Catch ex As Exception
            MsgBox("DataBase not connected due to the reason because " & ex.Message)
        End Try
    End Sub
End Module
