﻿Imports System.Management
Public Class FrmBackUp
    Dim cmdsql As New SqlClient.SqlCommand
    Private Sub FrmBackUp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' DBConnection()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value = 100 Then
            Timer1.Enabled = False
            ProgressBar1.Visible = False
            ' MsgBox("Backup Created Successfully!!!")
        Else
            ProgressBar1.Value = ProgressBar1.Value + 5
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try


            SaveFileDialog1.FileName = Today.Date.ToString("dd-MM-yyyy")
            SaveFileDialog1.ShowDialog()
            Dim s As String
            s = SaveFileDialog1.FileName


            cmdsql.Connection = con
            cmdsql.CommandText = "backup database MolassesDB to disk='" & s & "'"
            cmdsql.ExecuteNonQuery()
            Timer1.Enabled = True
            ProgressBar1.Visible = True
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class