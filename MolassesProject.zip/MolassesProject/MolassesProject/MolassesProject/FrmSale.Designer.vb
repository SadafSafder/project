﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSale
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim SidLabel As System.Windows.Forms.Label
        Dim SRateLabel As System.Windows.Forms.Label
        Dim SQtyLabel As System.Windows.Forms.Label
        Dim SAmountLabel As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim TidLabel As System.Windows.Forms.Label
        Dim Label7 As System.Windows.Forms.Label
        Dim Label9 As System.Windows.Forms.Label
        Dim CidLabel As System.Windows.Forms.Label
        Dim Label10 As System.Windows.Forms.Label
        Dim Label8 As System.Windows.Forms.Label
        Dim LblRemainingStock As System.Windows.Forms.Label
        Dim Label11 As System.Windows.Forms.Label
        Dim Label17 As System.Windows.Forms.Label
        Dim Label14 As System.Windows.Forms.Label
        Dim Label15 As System.Windows.Forms.Label
        Dim Label20 As System.Windows.Forms.Label
        Me.MolassesDBDataSet = New MolassesProject.molassesDBDataSet()
        Me.SaleBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SaleTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.SaleTableAdapter()
        Me.TableAdapterManager = New MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager()
        Me.SidTextBox = New System.Windows.Forms.TextBox()
        Me.SaledateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.SRateTextBox = New System.Windows.Forms.TextBox()
        Me.SQtyTextBox = New System.Windows.Forms.TextBox()
        Me.SAmountTextBox = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.FrAmountTextbox = New System.Windows.Forms.TextBox()
        Me.FrRateTextbox = New System.Windows.Forms.TextBox()
        Me.ToTextbox = New System.Windows.Forms.TextBox()
        Me.FromTextbox = New System.Windows.Forms.TextBox()
        Me.SQtyUnitText = New System.Windows.Forms.TextBox()
        Me.RdoParty = New System.Windows.Forms.RadioButton()
        Me.RdoContract = New System.Windows.Forms.RadioButton()
        Me.CidTextBox = New System.Windows.Forms.TextBox()
        Me.ComboItem = New System.Windows.Forms.ComboBox()
        Me.StockBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CRatePerKGTextbox = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BtnContract = New System.Windows.Forms.Button()
        Me.BtnParty = New System.Windows.Forms.Button()
        Me.StockTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.StockTableAdapter()
        Me.LabelAvgRate = New System.Windows.Forms.Label()
        Me.LabelMesage = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.VehicleNoTextBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Customers_dgv = New System.Windows.Forms.DataGridView()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label19 = New System.Windows.Forms.Label()
        SidLabel = New System.Windows.Forms.Label()
        SRateLabel = New System.Windows.Forms.Label()
        SQtyLabel = New System.Windows.Forms.Label()
        SAmountLabel = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        TidLabel = New System.Windows.Forms.Label()
        Label7 = New System.Windows.Forms.Label()
        Label9 = New System.Windows.Forms.Label()
        CidLabel = New System.Windows.Forms.Label()
        Label10 = New System.Windows.Forms.Label()
        Label8 = New System.Windows.Forms.Label()
        LblRemainingStock = New System.Windows.Forms.Label()
        Label11 = New System.Windows.Forms.Label()
        Label17 = New System.Windows.Forms.Label()
        Label14 = New System.Windows.Forms.Label()
        Label15 = New System.Windows.Forms.Label()
        Label20 = New System.Windows.Forms.Label()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SaleBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StockBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.Customers_dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'SidLabel
        '
        SidLabel.AutoSize = True
        SidLabel.Location = New System.Drawing.Point(18, 28)
        SidLabel.Name = "SidLabel"
        SidLabel.Size = New System.Drawing.Size(58, 15)
        SidLabel.TabIndex = 1
        SidLabel.Text = "Sale ID:"
        '
        'SRateLabel
        '
        SRateLabel.AutoSize = True
        SRateLabel.Location = New System.Drawing.Point(21, 321)
        SRateLabel.Name = "SRateLabel"
        SRateLabel.Size = New System.Drawing.Size(175, 15)
        SRateLabel.TabIndex = 7
        SRateLabel.Text = "Sale Rate / Ton / Mon /Kg:"
        '
        'SQtyLabel
        '
        SQtyLabel.AutoSize = True
        SQtyLabel.Location = New System.Drawing.Point(438, 284)
        SQtyLabel.Name = "SQtyLabel"
        SQtyLabel.Size = New System.Drawing.Size(135, 15)
        SQtyLabel.TabIndex = 9
        SQtyLabel.Text = "Sale Quantity In KG:"
        SQtyLabel.Visible = False
        '
        'SAmountLabel
        '
        SAmountLabel.AutoSize = True
        SAmountLabel.Location = New System.Drawing.Point(438, 314)
        SAmountLabel.Name = "SAmountLabel"
        SAmountLabel.Size = New System.Drawing.Size(92, 15)
        SAmountLabel.TabIndex = 11
        SAmountLabel.Text = "Sale Amount:"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Location = New System.Drawing.Point(438, 414)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(72, 15)
        Label5.TabIndex = 111
        Label5.Text = "Fr Amount"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(21, 414)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(126, 15)
        Label4.TabIndex = 109
        Label4.Text = "Freight Rate / Ton:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(433, 382)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(77, 15)
        Label3.TabIndex = 107
        Label3.Text = "Unload To:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(21, 385)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(100, 15)
        Label2.TabIndex = 105
        Label2.Text = "Loading From:"
        '
        'TidLabel
        '
        TidLabel.AutoSize = True
        TidLabel.Location = New System.Drawing.Point(21, 346)
        TidLabel.Name = "TidLabel"
        TidLabel.Size = New System.Drawing.Size(80, 15)
        TidLabel.TabIndex = 103
        TidLabel.Text = "Vehicle No:"
        '
        'Label7
        '
        Label7.AutoSize = True
        Label7.Location = New System.Drawing.Point(21, 284)
        Label7.Name = "Label7"
        Label7.Size = New System.Drawing.Size(92, 15)
        Label7.TabIndex = 119
        Label7.Text = "Quantity (KG)"
        '
        'Label9
        '
        Label9.AutoSize = True
        Label9.Location = New System.Drawing.Point(18, 76)
        Label9.Name = "Label9"
        Label9.Size = New System.Drawing.Size(101, 15)
        Label9.TabIndex = 124
        Label9.Text = "Purchase Type"
        '
        'CidLabel
        '
        CidLabel.AutoSize = True
        CidLabel.Location = New System.Drawing.Point(21, 114)
        CidLabel.Name = "CidLabel"
        CidLabel.Size = New System.Drawing.Size(82, 15)
        CidLabel.TabIndex = 121
        CidLabel.Text = "Contract ID:"
        '
        'Label10
        '
        Label10.AutoSize = True
        Label10.Location = New System.Drawing.Point(21, 177)
        Label10.Name = "Label10"
        Label10.Size = New System.Drawing.Size(35, 15)
        Label10.TabIndex = 125
        Label10.Text = "Item"
        '
        'Label8
        '
        Label8.AutoSize = True
        Label8.Location = New System.Drawing.Point(21, 209)
        Label8.Name = "Label8"
        Label8.Size = New System.Drawing.Size(125, 15)
        Label8.TabIndex = 127
        Label8.Text = "Contract Rate / KG"
        '
        'LblRemainingStock
        '
        LblRemainingStock.AutoSize = True
        LblRemainingStock.Location = New System.Drawing.Point(737, 178)
        LblRemainingStock.Name = "LblRemainingStock"
        LblRemainingStock.Size = New System.Drawing.Size(0, 15)
        LblRemainingStock.TabIndex = 130
        '
        'Label11
        '
        Label11.AutoSize = True
        Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label11.ForeColor = System.Drawing.Color.Teal
        Label11.Location = New System.Drawing.Point(6, 71)
        Label11.Name = "Label11"
        Label11.Size = New System.Drawing.Size(254, 29)
        Label11.TabIndex = 129
        Label11.Text = " Remaining Quantity:"
        '
        'Label17
        '
        Label17.AutoSize = True
        Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label17.ForeColor = System.Drawing.Color.Teal
        Label17.Location = New System.Drawing.Point(6, 25)
        Label17.Name = "Label17"
        Label17.Size = New System.Drawing.Size(170, 29)
        Label17.TabIndex = 133
        Label17.Text = "Average Rate"
        '
        'Label14
        '
        Label14.AutoSize = True
        Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label14.ForeColor = System.Drawing.Color.Teal
        Label14.Location = New System.Drawing.Point(6, 21)
        Label14.Name = "Label14"
        Label14.Size = New System.Drawing.Size(219, 29)
        Label14.TabIndex = 141
        Label14.Text = "Contract Quantity:"
        '
        'Label15
        '
        Label15.AutoSize = True
        Label15.Location = New System.Drawing.Point(21, 145)
        Label15.Name = "Label15"
        Label15.Size = New System.Drawing.Size(103, 15)
        Label15.TabIndex = 1185
        Label15.Text = "Account Name:"
        '
        'Label20
        '
        Label20.AutoSize = True
        Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label20.ForeColor = System.Drawing.Color.Teal
        Label20.Location = New System.Drawing.Point(6, 71)
        Label20.Name = "Label20"
        Label20.Size = New System.Drawing.Size(149, 29)
        Label20.TabIndex = 129
        Label20.Text = " Item Stock:"
        '
        'MolassesDBDataSet
        '
        Me.MolassesDBDataSet.DataSetName = "molassesDBDataSet"
        Me.MolassesDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'SaleBindingSource
        '
        Me.SaleBindingSource.DataMember = "Sale"
        Me.SaleBindingSource.DataSource = Me.MolassesDBDataSet
        '
        'SaleTableAdapter
        '
        Me.SaleTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccountsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContractTableAdapter = Nothing
        Me.TableAdapterManager.InvTableAdapter = Nothing
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.PurchaseTableAdapter = Nothing
        Me.TableAdapterManager.SaleTableAdapter = Me.SaleTableAdapter
        Me.TableAdapterManager.StockTableAdapter = Nothing
        Me.TableAdapterManager.TransactionsTableAdapter = Nothing
        Me.TableAdapterManager.TransportationTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VehicleTableAdapter = Nothing
        Me.TableAdapterManager.VouchersTableAdapter = Nothing
        '
        'SidTextBox
        '
        Me.SidTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SaleBindingSource, "Sid", True))
        Me.SidTextBox.Location = New System.Drawing.Point(205, 24)
        Me.SidTextBox.Name = "SidTextBox"
        Me.SidTextBox.ReadOnly = True
        Me.SidTextBox.Size = New System.Drawing.Size(187, 21)
        Me.SidTextBox.TabIndex = 2
        Me.SidTextBox.TabStop = False
        '
        'SaledateDateTimePicker
        '
        Me.SaledateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.SaleBindingSource, "Saledate", True))
        Me.SaledateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.SaledateDateTimePicker.Location = New System.Drawing.Point(938, 6)
        Me.SaledateDateTimePicker.Name = "SaledateDateTimePicker"
        Me.SaledateDateTimePicker.Size = New System.Drawing.Size(186, 21)
        Me.SaledateDateTimePicker.TabIndex = 6
        Me.SaledateDateTimePicker.TabStop = False
        '
        'SRateTextBox
        '
        Me.SRateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SaleBindingSource, "SRate", True))
        Me.SRateTextBox.Location = New System.Drawing.Point(206, 315)
        Me.SRateTextBox.Name = "SRateTextBox"
        Me.SRateTextBox.Size = New System.Drawing.Size(188, 21)
        Me.SRateTextBox.TabIndex = 4
        '
        'SQtyTextBox
        '
        Me.SQtyTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SaleBindingSource, "SQty", True))
        Me.SQtyTextBox.Location = New System.Drawing.Point(579, 284)
        Me.SQtyTextBox.Name = "SQtyTextBox"
        Me.SQtyTextBox.Size = New System.Drawing.Size(133, 21)
        Me.SQtyTextBox.TabIndex = 10
        Me.SQtyTextBox.TabStop = False
        Me.SQtyTextBox.Visible = False
        '
        'SAmountTextBox
        '
        Me.SAmountTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SaleBindingSource, "SAmount", True))
        Me.SAmountTextBox.Enabled = False
        Me.SAmountTextBox.Location = New System.Drawing.Point(579, 311)
        Me.SAmountTextBox.Name = "SAmountTextBox"
        Me.SAmountTextBox.Size = New System.Drawing.Size(133, 21)
        Me.SAmountTextBox.TabIndex = 12
        Me.SAmountTextBox.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(207, 459)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(110, 39)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(323, 459)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(110, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(439, 459)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'FrAmountTextbox
        '
        Me.FrAmountTextbox.Enabled = False
        Me.FrAmountTextbox.Location = New System.Drawing.Point(574, 408)
        Me.FrAmountTextbox.Name = "FrAmountTextbox"
        Me.FrAmountTextbox.Size = New System.Drawing.Size(133, 21)
        Me.FrAmountTextbox.TabIndex = 9
        Me.FrAmountTextbox.TabStop = False
        '
        'FrRateTextbox
        '
        Me.FrRateTextbox.Location = New System.Drawing.Point(206, 409)
        Me.FrRateTextbox.Name = "FrRateTextbox"
        Me.FrRateTextbox.Size = New System.Drawing.Size(188, 21)
        Me.FrRateTextbox.TabIndex = 8
        '
        'ToTextbox
        '
        Me.ToTextbox.Location = New System.Drawing.Point(574, 376)
        Me.ToTextbox.Name = "ToTextbox"
        Me.ToTextbox.Size = New System.Drawing.Size(133, 21)
        Me.ToTextbox.TabIndex = 7
        '
        'FromTextbox
        '
        Me.FromTextbox.Location = New System.Drawing.Point(206, 379)
        Me.FromTextbox.Name = "FromTextbox"
        Me.FromTextbox.Size = New System.Drawing.Size(188, 21)
        Me.FromTextbox.TabIndex = 6
        '
        'SQtyUnitText
        '
        Me.SQtyUnitText.Location = New System.Drawing.Point(206, 284)
        Me.SQtyUnitText.Name = "SQtyUnitText"
        Me.SQtyUnitText.Size = New System.Drawing.Size(188, 21)
        Me.SQtyUnitText.TabIndex = 3
        '
        'RdoParty
        '
        Me.RdoParty.AutoSize = True
        Me.RdoParty.Checked = True
        Me.RdoParty.Location = New System.Drawing.Point(129, 16)
        Me.RdoParty.Name = "RdoParty"
        Me.RdoParty.Size = New System.Drawing.Size(57, 19)
        Me.RdoParty.TabIndex = 1050
        Me.RdoParty.TabStop = True
        Me.RdoParty.Text = "Party"
        Me.RdoParty.UseVisualStyleBackColor = True
        '
        'RdoContract
        '
        Me.RdoContract.AutoSize = True
        Me.RdoContract.Location = New System.Drawing.Point(0, 16)
        Me.RdoContract.Name = "RdoContract"
        Me.RdoContract.Size = New System.Drawing.Size(78, 19)
        Me.RdoContract.TabIndex = 104
        Me.RdoContract.Text = "Contract"
        Me.RdoContract.UseVisualStyleBackColor = True
        '
        'CidTextBox
        '
        Me.CidTextBox.Location = New System.Drawing.Point(206, 113)
        Me.CidTextBox.Name = "CidTextBox"
        Me.CidTextBox.Size = New System.Drawing.Size(188, 21)
        Me.CidTextBox.TabIndex = 0
        '
        'ComboItem
        '
        Me.ComboItem.FormattingEnabled = True
        Me.ComboItem.Location = New System.Drawing.Point(206, 174)
        Me.ComboItem.Name = "ComboItem"
        Me.ComboItem.Size = New System.Drawing.Size(188, 23)
        Me.ComboItem.TabIndex = 2
        '
        'StockBindingSource
        '
        Me.StockBindingSource.DataMember = "Stock"
        Me.StockBindingSource.DataSource = Me.MolassesDBDataSet
        '
        'CRatePerKGTextbox
        '
        Me.CRatePerKGTextbox.Enabled = False
        Me.CRatePerKGTextbox.Location = New System.Drawing.Point(206, 206)
        Me.CRatePerKGTextbox.Name = "CRatePerKGTextbox"
        Me.CRatePerKGTextbox.Size = New System.Drawing.Size(188, 21)
        Me.CRatePerKGTextbox.TabIndex = 128
        Me.CRatePerKGTextbox.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Black
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(280, 68)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(103, 37)
        Me.Label12.TabIndex = 131
        Me.Label12.Text = "00.00"
        '
        'BtnContract
        '
        Me.BtnContract.Location = New System.Drawing.Point(510, 111)
        Me.BtnContract.Name = "BtnContract"
        Me.BtnContract.Size = New System.Drawing.Size(99, 27)
        Me.BtnContract.TabIndex = 121
        Me.BtnContract.TabStop = False
        Me.BtnContract.Text = "Contract"
        Me.BtnContract.UseVisualStyleBackColor = True
        '
        'BtnParty
        '
        Me.BtnParty.Location = New System.Drawing.Point(510, 141)
        Me.BtnParty.Name = "BtnParty"
        Me.BtnParty.Size = New System.Drawing.Size(99, 27)
        Me.BtnParty.TabIndex = 120
        Me.BtnParty.TabStop = False
        Me.BtnParty.Text = "Party"
        Me.BtnParty.UseVisualStyleBackColor = True
        '
        'StockTableAdapter
        '
        Me.StockTableAdapter.ClearBeforeFill = True
        '
        'LabelAvgRate
        '
        Me.LabelAvgRate.AutoSize = True
        Me.LabelAvgRate.BackColor = System.Drawing.Color.Black
        Me.LabelAvgRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgRate.ForeColor = System.Drawing.Color.Red
        Me.LabelAvgRate.Location = New System.Drawing.Point(280, 19)
        Me.LabelAvgRate.Name = "LabelAvgRate"
        Me.LabelAvgRate.Size = New System.Drawing.Size(103, 37)
        Me.LabelAvgRate.TabIndex = 132
        Me.LabelAvgRate.Text = "00.00"
        '
        'LabelMesage
        '
        Me.LabelMesage.AutoSize = True
        Me.LabelMesage.ForeColor = System.Drawing.Color.Red
        Me.LabelMesage.Location = New System.Drawing.Point(517, 18)
        Me.LabelMesage.Name = "LabelMesage"
        Me.LabelMesage.Size = New System.Drawing.Size(65, 15)
        Me.LabelMesage.TabIndex = 134
        Me.LabelMesage.Text = "Message"
        Me.LabelMesage.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Label15)
        Me.GroupBox3.Controls.Add(Me.AccNameTextBox)
        Me.GroupBox3.Controls.Add(Me.GroupBox1)
        Me.GroupBox3.Controls.Add(Me.VehicleNoTextBox)
        Me.GroupBox3.Controls.Add(Me.Button4)
        Me.GroupBox3.Controls.Add(Me.Button6)
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Controls.Add(Me.LabelMesage)
        Me.GroupBox3.Controls.Add(Me.BtnContract)
        Me.GroupBox3.Controls.Add(Me.BtnParty)
        Me.GroupBox3.Controls.Add(Label8)
        Me.GroupBox3.Controls.Add(Me.CRatePerKGTextbox)
        Me.GroupBox3.Controls.Add(Me.ComboItem)
        Me.GroupBox3.Controls.Add(Label10)
        Me.GroupBox3.Controls.Add(Label9)
        Me.GroupBox3.Controls.Add(CidLabel)
        Me.GroupBox3.Controls.Add(Me.CidTextBox)
        Me.GroupBox3.Controls.Add(Label7)
        Me.GroupBox3.Controls.Add(Me.SQtyUnitText)
        Me.GroupBox3.Controls.Add(Label5)
        Me.GroupBox3.Controls.Add(Me.FrAmountTextbox)
        Me.GroupBox3.Controls.Add(Label4)
        Me.GroupBox3.Controls.Add(Me.FrRateTextbox)
        Me.GroupBox3.Controls.Add(Label3)
        Me.GroupBox3.Controls.Add(Me.ToTextbox)
        Me.GroupBox3.Controls.Add(Label2)
        Me.GroupBox3.Controls.Add(Me.FromTextbox)
        Me.GroupBox3.Controls.Add(TidLabel)
        Me.GroupBox3.Controls.Add(SidLabel)
        Me.GroupBox3.Controls.Add(Me.SidTextBox)
        Me.GroupBox3.Controls.Add(SRateLabel)
        Me.GroupBox3.Controls.Add(Me.SRateTextBox)
        Me.GroupBox3.Controls.Add(SQtyLabel)
        Me.GroupBox3.Controls.Add(Me.SQtyTextBox)
        Me.GroupBox3.Controls.Add(SAmountLabel)
        Me.GroupBox3.Controls.Add(Me.SAmountTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 29)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(735, 515)
        Me.GroupBox3.TabIndex = 135
        Me.GroupBox3.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Ivory
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.ForeColor = System.Drawing.Color.Navy
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(550, 459)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 39)
        Me.Button1.TabIndex = 1186
        Me.Button1.TabStop = False
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SaleBindingSource, "AccName", True))
        Me.AccNameTextBox.Location = New System.Drawing.Point(205, 143)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(266, 21)
        Me.AccNameTextBox.TabIndex = 1184
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RdoContract)
        Me.GroupBox1.Controls.Add(Me.RdoParty)
        Me.GroupBox1.Location = New System.Drawing.Point(205, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(187, 48)
        Me.GroupBox1.TabIndex = 1182
        Me.GroupBox1.TabStop = False
        '
        'VehicleNoTextBox
        '
        Me.VehicleNoTextBox.FormattingEnabled = True
        Me.VehicleNoTextBox.Location = New System.Drawing.Point(207, 346)
        Me.VehicleNoTextBox.Name = "VehicleNoTextBox"
        Me.VehicleNoTextBox.Size = New System.Drawing.Size(186, 23)
        Me.VehicleNoTextBox.TabIndex = 1181
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(558, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 24)
        Me.Label1.TabIndex = 136
        Me.Label1.Text = "Sale Item"
        '
        'Customers_dgv
        '
        Me.Customers_dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.Customers_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Customers_dgv.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Customers_dgv.Location = New System.Drawing.Point(61, 545)
        Me.Customers_dgv.MultiSelect = False
        Me.Customers_dgv.Name = "Customers_dgv"
        Me.Customers_dgv.ReadOnly = True
        Me.Customers_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Customers_dgv.Size = New System.Drawing.Size(1060, 193)
        Me.Customers_dgv.TabIndex = 140
        Me.Customers_dgv.TabStop = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Black
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(280, 13)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(103, 37)
        Me.Label13.TabIndex = 142
        Me.Label13.Text = "00.00"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Label14)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Label11)
        Me.GroupBox5.Location = New System.Drawing.Point(741, 29)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(459, 120)
        Me.GroupBox5.TabIndex = 143
        Me.GroupBox5.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Label20)
        Me.GroupBox4.Controls.Add(Label17)
        Me.GroupBox4.Controls.Add(Me.LabelAvgRate)
        Me.GroupBox4.Location = New System.Drawing.Point(741, 140)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(459, 120)
        Me.GroupBox4.TabIndex = 144
        Me.GroupBox4.TabStop = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Black
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Red
        Me.Label19.Location = New System.Drawing.Point(280, 68)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(103, 37)
        Me.Label19.TabIndex = 131
        Me.Label19.Text = "00.00"
        '
        'FrmSale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(1212, 741)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Customers_dgv)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(LblRemainingStock)
        Me.Controls.Add(Me.SaledateDateTimePicker)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Name = "FrmSale"
        Me.Text = "FrmSale"
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SaleBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StockBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Customers_dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MolassesDBDataSet As MolassesProject.molassesDBDataSet
    Friend WithEvents SaleBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SaleTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.SaleTableAdapter
    Friend WithEvents TableAdapterManager As MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents SidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SaledateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents SRateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SQtyTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SAmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents FrAmountTextbox As System.Windows.Forms.TextBox
    Friend WithEvents FrRateTextbox As System.Windows.Forms.TextBox
    Friend WithEvents ToTextbox As System.Windows.Forms.TextBox
    Friend WithEvents FromTextbox As System.Windows.Forms.TextBox
    Friend WithEvents SQtyUnitText As System.Windows.Forms.TextBox
    Friend WithEvents RdoParty As System.Windows.Forms.RadioButton
    Friend WithEvents RdoContract As System.Windows.Forms.RadioButton
    Friend WithEvents CidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComboItem As System.Windows.Forms.ComboBox
    Friend WithEvents CRatePerKGTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents BtnContract As System.Windows.Forms.Button
    Friend WithEvents BtnParty As System.Windows.Forms.Button
    Friend WithEvents StockBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StockTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.StockTableAdapter
    Friend WithEvents LabelAvgRate As System.Windows.Forms.Label
    Friend WithEvents LabelMesage As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Customers_dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents VehicleNoTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
