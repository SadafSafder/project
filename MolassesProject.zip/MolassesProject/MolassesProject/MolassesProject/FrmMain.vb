﻿Public Class FrmMain
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Private Sub UsersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmUser.Show()
    End Sub

    Private Sub CompanyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ItemsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmPurchase.ShowDialog()
    End Sub

    Private Sub SaleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmSale.ShowDialog()
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmVouchers.ShowDialog()
    End Sub
    Private Sub RibbonButton19_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton19.Click
        frmTranspotationReport.ShowDialog()
    End Sub
    Private Sub alert()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT Cid,Item, Edate from Contract where Status='OnGoing' order by EDate", con)

            daSql.Fill(dt)
            Me.Dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub FrmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' DBConnection()
        alert()
        Timer1.Enabled = True
    End Sub

    Private Sub CustomerLedgerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmLedgerReport.ShowDialog()
    End Sub

    Private Sub BalanceSheetToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmBalanceSheet.ShowDialog()
    End Sub

    Private Sub SaleReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmSaleReport.ShowDialog()
    End Sub

    Private Sub PurchaseReportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        FrmPurchaseReport.ShowDialog()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = TimeOfDay
        Label2.Text = Date.Now.ToString("D")
    End Sub

    Private Sub Ribbon1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ribbon1.Click

    End Sub

    Private Sub RibbonButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton1.Click
        FrmAccounts.ShowDialog()
    End Sub

    Private Sub RibbonButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton2.Click
        FrmItem.ShowDialog()
    End Sub

    Private Sub RibbonButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton3.Click
        FrmVehicle.ShowDialog()
    End Sub

    Private Sub RibbonButton4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton4.Click
        FrmContract.ShowDialog()
    End Sub


    Private Sub RibbonButton7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton7.Click
        FrmVouchers.ShowDialog()
    End Sub

    Private Sub RibbonButton14_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton14.Click
        FrmPurchase.ShowDialog()
    End Sub

    Private Sub RibbonButton15_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton15.Click
        FrmSale.ShowDialog()
    End Sub

    Private Sub RibbonButton13_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton13.Click
        FrmUser.ShowDialog()
    End Sub

    Private Sub RibbonButton8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton8.Click
        FrmSaleReport.ShowDialog()
    End Sub

    Private Sub RibbonButton10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton10.Click
        FrmPurchaseReport.ShowDialog()
    End Sub

    Private Sub RibbonButton9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton9.Click
        FrmLedgerReport.ShowDialog()
    End Sub

    Private Sub RibbonButton11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton11.Click
        FrmBalanceSheet.ShowDialog()
    End Sub

    Private Sub RibbonButton12_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton12.Click
        FrmBackUp.ShowDialog()
    End Sub

    Private Sub RibbonButton16_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton16.Click
        System.Diagnostics.Process.Start("calc.exe")
    End Sub

    Private Sub RibbonButton17_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton17.Click
        System.Diagnostics.Process.Start("wordpad.exe")

    End Sub

    Private Sub RibbonButton5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton5.Click
        FrmSale.ShowDialog()
    End Sub

    Private Sub RibbonButton20_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RibbonButton20.Click
        FrmPayVouchers.ShowDialog()
    End Sub
End Class