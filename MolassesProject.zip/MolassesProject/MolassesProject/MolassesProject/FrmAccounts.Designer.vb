﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAccounts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim AccNoLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Dim AccHolderLabel As System.Windows.Forms.Label
        Dim TypeLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim PhoneLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.AccNoTextBox = New System.Windows.Forms.TextBox()
        Me.AccountsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MolassesDBDataSet = New MolassesProject.molassesDBDataSet()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.AccHolderTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.PhoneTextBox = New System.Windows.Forms.TextBox()
        Me.TypeTextBox = New System.Windows.Forms.ComboBox()
        Me.TableAdapterManager = New MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager()
        Me.AccountsTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.AccountsTableAdapter()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        AccNoLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        AccHolderLabel = New System.Windows.Forms.Label()
        TypeLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        PhoneLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AccountsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AccNoLabel
        '
        AccNoLabel.AutoSize = True
        AccNoLabel.Location = New System.Drawing.Point(26, 76)
        AccNoLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccNoLabel.Name = "AccNoLabel"
        AccNoLabel.Size = New System.Drawing.Size(83, 15)
        AccNoLabel.TabIndex = 102
        AccNoLabel.Text = "Account No:"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(26, 106)
        AccNameLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(103, 15)
        AccNameLabel.TabIndex = 104
        AccNameLabel.Text = "Account Name:"
        '
        'AccHolderLabel
        '
        AccHolderLabel.AutoSize = True
        AccHolderLabel.Location = New System.Drawing.Point(490, 106)
        AccHolderLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AccHolderLabel.Name = "AccHolderLabel"
        AccHolderLabel.Size = New System.Drawing.Size(108, 15)
        AccHolderLabel.TabIndex = 106
        AccHolderLabel.Text = "Account Holder:"
        AddHandler AccHolderLabel.Click, AddressOf Me.AccHolderLabel_Click
        '
        'TypeLabel
        '
        TypeLabel.AutoSize = True
        TypeLabel.Location = New System.Drawing.Point(26, 136)
        TypeLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TypeLabel.Name = "TypeLabel"
        TypeLabel.Size = New System.Drawing.Size(41, 15)
        TypeLabel.TabIndex = 108
        TypeLabel.Text = "Type:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.Location = New System.Drawing.Point(26, 166)
        AddressLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(62, 15)
        AddressLabel.TabIndex = 109
        AddressLabel.Text = "Address:"
        '
        'PhoneLabel
        '
        PhoneLabel.AutoSize = True
        PhoneLabel.Location = New System.Drawing.Point(493, 166)
        PhoneLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        PhoneLabel.Name = "PhoneLabel"
        PhoneLabel.Size = New System.Drawing.Size(52, 15)
        PhoneLabel.TabIndex = 111
        PhoneLabel.Text = "Phone:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.ForeColor = System.Drawing.Color.Red
        Label3.Location = New System.Drawing.Point(205, 79)
        Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(154, 15)
        Label3.TabIndex = 115
        Label3.Text = "(Please Enter 3-Characters"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightBlue
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(169, 216)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 114
        Me.GroupBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(8, 14)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.Navy
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(242, 14)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 30
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(125, 14)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(360, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'dgv
        '
        Me.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(148, 285)
        Me.dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(642, 336)
        Me.dgv.TabIndex = 113
        Me.dgv.TabStop = False
        '
        'AccNoTextBox
        '
        Me.AccNoTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.AccNoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AccountsBindingSource, "AccNo", True))
        Me.AccNoTextBox.Location = New System.Drawing.Point(133, 73)
        Me.AccNoTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNoTextBox.Name = "AccNoTextBox"
        Me.AccNoTextBox.Size = New System.Drawing.Size(64, 21)
        Me.AccNoTextBox.TabIndex = 0
        '
        'AccountsBindingSource
        '
        Me.AccountsBindingSource.DataMember = "Accounts"
        Me.AccountsBindingSource.DataSource = Me.MolassesDBDataSet
        '
        'MolassesDBDataSet
        '
        Me.MolassesDBDataSet.DataSetName = "molassesDBDataSet"
        Me.MolassesDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AccountsBindingSource, "AccName", True))
        Me.AccNameTextBox.Location = New System.Drawing.Point(133, 103)
        Me.AccNameTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(341, 21)
        Me.AccNameTextBox.TabIndex = 1
        '
        'AccHolderTextBox
        '
        Me.AccHolderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AccountsBindingSource, "AccHolder", True))
        Me.AccHolderTextBox.Location = New System.Drawing.Point(605, 103)
        Me.AccHolderTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AccHolderTextBox.Name = "AccHolderTextBox"
        Me.AccHolderTextBox.Size = New System.Drawing.Size(301, 21)
        Me.AccHolderTextBox.TabIndex = 2
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AccountsBindingSource, "Address", True))
        Me.AddressTextBox.Location = New System.Drawing.Point(133, 163)
        Me.AddressTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(341, 21)
        Me.AddressTextBox.TabIndex = 4
        '
        'PhoneTextBox
        '
        Me.PhoneTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AccountsBindingSource, "Phone", True))
        Me.PhoneTextBox.Location = New System.Drawing.Point(605, 163)
        Me.PhoneTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PhoneTextBox.Name = "PhoneTextBox"
        Me.PhoneTextBox.Size = New System.Drawing.Size(185, 21)
        Me.PhoneTextBox.TabIndex = 5
        '
        'TypeTextBox
        '
        Me.TypeTextBox.FormattingEnabled = True
        Me.TypeTextBox.Location = New System.Drawing.Point(133, 132)
        Me.TypeTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TypeTextBox.Name = "TypeTextBox"
        Me.TypeTextBox.Size = New System.Drawing.Size(341, 23)
        Me.TypeTextBox.TabIndex = 3
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccountsTableAdapter = Me.AccountsTableAdapter
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContractTableAdapter = Nothing
        Me.TableAdapterManager.InvTableAdapter = Nothing
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.PurchaseTableAdapter = Nothing
        Me.TableAdapterManager.SaleTableAdapter = Nothing
        Me.TableAdapterManager.StockTableAdapter = Nothing
        Me.TableAdapterManager.TransactionsTableAdapter = Nothing
        Me.TableAdapterManager.TransportationTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VehicleTableAdapter = Nothing
        Me.TableAdapterManager.VouchersTableAdapter = Nothing
        '
        'AccountsTableAdapter
        '
        Me.AccountsTableAdapter.ClearBeforeFill = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(332, 27)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(257, 24)
        Me.Label2.TabIndex = 101
        Me.Label2.Text = "CUSTOMERS ACCOUNTS"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-360, -209)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 100
        Me.Label1.Text = "Label1"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.ForeColor = System.Drawing.Color.Red
        Label4.Location = New System.Drawing.Point(602, 145)
        Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(211, 15)
        Label4.TabIndex = 116
        Label4.Text = "(Please Enter Ph. No. Without dashes"
        '
        'FrmAccounts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(920, 677)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(AccNoLabel)
        Me.Controls.Add(Me.AccNoTextBox)
        Me.Controls.Add(Me.AccNameTextBox)
        Me.Controls.Add(Me.AccHolderTextBox)
        Me.Controls.Add(Me.AddressTextBox)
        Me.Controls.Add(Me.PhoneTextBox)
        Me.Controls.Add(Me.TypeTextBox)
        Me.Controls.Add(AccNameLabel)
        Me.Controls.Add(AccHolderLabel)
        Me.Controls.Add(TypeLabel)
        Me.Controls.Add(AddressLabel)
        Me.Controls.Add(PhoneLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmAccounts"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmAccounts"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AccountsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents AccNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AccountsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MolassesDBDataSet As MolassesProject.molassesDBDataSet
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AccHolderTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PhoneTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TypeTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents TableAdapterManager As MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents AccountsTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.AccountsTableAdapter
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
