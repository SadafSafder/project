﻿Public Class FrmVehicle
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dt As New DataTable

    Private Sub insertion()
        Try
            cmdsql.Connection = con
            If (IsNumeric(PhoneTextBox.Text)) Then

                cmdsql.CommandText = "INSERT INTO  Vehicle (vid,VehNo,Vowner,Address,Phone) VALUES  ('" & VidTextBox.Text & "','" & VehNoTextBox.Text & "','" & VOwnerTextBox.Text & "','" & AddressTextBox.Text & "' ,'" & PhoneTextBox.Text & "' )"

                cmdsql.ExecuteNonQuery()
            Else
                MsgBox("Please Enter Data in Proper Format")

            End If



        Catch ex As Exception

        End Try



    End Sub

    Private Sub updation()
        Try


            cmdsql.Connection = con
            cmdsql.CommandText = "update Vehicle set  VehNo='" & VehNoTextBox.Text & "', Vowner='" & VOwnerTextBox.Text & "', Address='" & AddressTextBox.Text & "' , Phone='" & PhoneTextBox.Text & "'  where vid='" & VidTextBox.Text & "'  "
            cmdsql.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub id()
        VidTextBox.Text = ""
        Dim ed As Double
        cmdsql = New SqlClient.SqlCommand("select isnull(max(vid),0) from Vehicle", con)


        ed = cmdsql.ExecuteScalar()


        ed = ed + 1

        VidTextBox.Text = ed
    End Sub



    Private Sub SqlGridView()
        Try

            dt.Clear()


            Dim daSql As New SqlClient.SqlDataAdapter("SELECT * from Vehicle ", con)

            daSql.Fill(dt)
            Me.Dgv.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub boxvalue()

        CLEAR_CONTROL()
        VidTextBox.DataBindings.Add("text", dt, "Vid")
        VOwnerTextBox.DataBindings.Add("text", dt, "Vowner")
        '  Obalancetxt.DataBindings.Add("text", dt, "balance")
        ' AddressTextBox.DataBindings.Add("text", dt, "type")
        VehNoTextBox.DataBindings.Add("text", dt, "VehNO")
        PhoneTextBox.DataBindings.Add("text", dt, "Phone")
        AddressTextBox.DataBindings.Add("text", dt, "Address")

    End Sub


    Function CLEAR_CONTROL()
        VidTextBox.DataBindings.Clear()
        VOwnerTextBox.DataBindings.Clear()

        VehNoTextBox.DataBindings.Clear()
        PhoneTextBox.DataBindings.Clear()
        AddressTextBox.DataBindings.Clear()
        '  dt.Clear()
        VidTextBox.Text = ""
        AddressTextBox.Text = ""
        VOwnerTextBox.Text = ""



        PhoneTextBox.Text = ""
        VehNoTextBox.Text = ""
        Return 0
    End Function
    Private Sub FrmVehicle_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' DBConnection()
        SqlGridView()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If VehNoTextBox.Text <> "" Then
            id()
            insertion()
            CLEAR_CONTROL()
            SqlGridView()
        Else
            MsgBox("Please Fill All Info")
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CLEAR_CONTROL()
        SqlGridView()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If VidTextBox.Text <> "" Then

            updation()
            CLEAR_CONTROL()
            SqlGridView()

        Else
            MsgBox("Please Select any Vehicle !!")

        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If VidTextBox.Text <> "" Then
            Dim result = MessageBox.Show("Are you sure Delete ", "Warning !!!", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then



                cmdsql.Connection = con
                cmdsql.CommandText = "DELETE  FROM Vehicle WHERE vid= '" & VidTextBox.Text & "'   "
                cmdsql.ExecuteNonQuery()
                'MsgBox("Delete Successfuly")




                CLEAR_CONTROL()
                SqlGridView()

                '  boxvalue()

            Else : result = DialogResult.No
                ' MsgBox("Delete Cancel")


            End If

        Else
            MsgBox("Please Select Any Vehicle !!")
        End If
    End Sub

    Private Sub Dgv_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv.CellContentClick

    End Sub

    Private Sub Dgv_RowHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Dgv.RowHeaderMouseDoubleClick
        CLEAR_CONTROL()
        boxvalue()
    End Sub
End Class