﻿Public Class Login
    Dim cmdsql As New SqlClient.SqlCommand
    Dim dr As SqlClient.SqlDataReader
    Public user As String

    Private Sub Login_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        ProgressBar1.Value = 0
    End Sub

    Private Sub Login_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            cmdlogin.PerformClick()
        End If
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ProgressBar1.Value = ProgressBar1.Value + 2
        If ProgressBar1.Value = 100 Then
            Timer1.Enabled = False

            '    If typetxt.Text = "Admin" Then


            FrmMain.ShowDialog()
            '   txtpassword.Text = ""
            '  End If



            Me.Hide()

        End If
    End Sub
    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DBConnection()
        Timer1.Interval = 30
        Timer1.Enabled = False
        ProgressBar1.Hide()
        txtusername.Focus()
        Me.KeyPreview = True
    End Sub

    Private Sub cmdlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdlogin.Click
        Try


            cmdsql = New SqlClient.SqlCommand("select * from login where username='" & txtusername.Text & "' and password ='" & txtpassword.Text & "' and type ='" & typetxt.Text & "' ", con)

            dr = cmdsql.ExecuteReader
            If (dr.HasRows = True) Then
                Cursor = Cursors.WaitCursor
                ProgressBar1.Show()

                If Today.Date < "11/05/2016" Then


                    Timer1.Enabled = True

                End If

                '  FrmMain.Show()

            Else


                MessageBox.Show("WRONG USERNAME AND PASSWORD")
                txtpassword.Text = ""
                txtusername.Text = ""
                txtusername.Focus()
            End If
            dr.Close()
        Catch EX As Exception
            MsgBox(EX.Message)
        End Try
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub GroupBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles GroupBox1.KeyDown

    End Sub
End Class