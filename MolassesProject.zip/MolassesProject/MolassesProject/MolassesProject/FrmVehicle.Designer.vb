﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmVehicle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim VidLabel As System.Windows.Forms.Label
        Dim VehNoLabel As System.Windows.Forms.Label
        Dim VOwnerLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim PhoneLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Dgv = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TableAdapterManager = New MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager()
        Me.VehicleTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.VehicleTableAdapter()
        Me.VidTextBox = New System.Windows.Forms.TextBox()
        Me.VehicleBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MolassesDBDataSet = New MolassesProject.molassesDBDataSet()
        Me.VehNoTextBox = New System.Windows.Forms.TextBox()
        Me.VOwnerTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.PhoneTextBox = New System.Windows.Forms.TextBox()
        VidLabel = New System.Windows.Forms.Label()
        VehNoLabel = New System.Windows.Forms.Label()
        VOwnerLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        PhoneLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.Dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VehicleBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VidLabel
        '
        VidLabel.AutoSize = True
        VidLabel.Location = New System.Drawing.Point(33, 61)
        VidLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        VidLabel.Name = "VidLabel"
        VidLabel.Size = New System.Drawing.Size(76, 15)
        VidLabel.TabIndex = 107
        VidLabel.Text = "Vehicle ID:"
        '
        'VehNoLabel
        '
        VehNoLabel.AutoSize = True
        VehNoLabel.Location = New System.Drawing.Point(33, 91)
        VehNoLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        VehNoLabel.Name = "VehNoLabel"
        VehNoLabel.Size = New System.Drawing.Size(80, 15)
        VehNoLabel.TabIndex = 112
        VehNoLabel.Text = "Vehicle No:"
        '
        'VOwnerLabel
        '
        VOwnerLabel.AutoSize = True
        VOwnerLabel.Location = New System.Drawing.Point(33, 121)
        VOwnerLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        VOwnerLabel.Name = "VOwnerLabel"
        VOwnerLabel.Size = New System.Drawing.Size(103, 15)
        VOwnerLabel.TabIndex = 113
        VOwnerLabel.Text = "Vehicle Owner:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.Location = New System.Drawing.Point(33, 151)
        AddressLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(62, 15)
        AddressLabel.TabIndex = 114
        AddressLabel.Text = "Address:"
        '
        'PhoneLabel
        '
        PhoneLabel.AutoSize = True
        PhoneLabel.Location = New System.Drawing.Point(33, 181)
        PhoneLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        PhoneLabel.Name = "PhoneLabel"
        PhoneLabel.Size = New System.Drawing.Size(52, 15)
        PhoneLabel.TabIndex = 115
        PhoneLabel.Text = "Phone:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.ForeColor = System.Drawing.Color.Red
        Label2.Location = New System.Drawing.Point(381, 178)
        Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(162, 15)
        Label2.TabIndex = 119
        Label2.Text = "Please Enter without dashes"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.LightBlue
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Location = New System.Drawing.Point(45, 214)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(493, 63)
        Me.GroupBox1.TabIndex = 118
        Me.GroupBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(19, 17)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(109, 39)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Ivory
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.Location = New System.Drawing.Point(253, 17)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(109, 39)
        Me.Button3.TabIndex = 30
        Me.Button3.TabStop = False
        Me.Button3.Text = "Delete"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Location = New System.Drawing.Point(136, 17)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(371, 17)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Dgv
        '
        Me.Dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.Dgv.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv.Location = New System.Drawing.Point(11, 283)
        Me.Dgv.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Dgv.Name = "Dgv"
        Me.Dgv.Size = New System.Drawing.Size(604, 219)
        Me.Dgv.TabIndex = 117
        Me.Dgv.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(274, 21)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 24)
        Me.Label1.TabIndex = 116
        Me.Label1.Text = "Vehicle"
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AccountsTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContractTableAdapter = Nothing
        Me.TableAdapterManager.InvTableAdapter = Nothing
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.PurchaseTableAdapter = Nothing
        Me.TableAdapterManager.SaleTableAdapter = Nothing
        Me.TableAdapterManager.StockTableAdapter = Nothing
        Me.TableAdapterManager.TransactionsTableAdapter = Nothing
        Me.TableAdapterManager.TransportationTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VehicleTableAdapter = Me.VehicleTableAdapter
        Me.TableAdapterManager.VouchersTableAdapter = Nothing
        '
        'VehicleTableAdapter
        '
        Me.VehicleTableAdapter.ClearBeforeFill = True
        '
        'VidTextBox
        '
        Me.VidTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VehicleBindingSource, "Vid", True))
        Me.VidTextBox.Location = New System.Drawing.Point(150, 55)
        Me.VidTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.VidTextBox.Name = "VidTextBox"
        Me.VidTextBox.ReadOnly = True
        Me.VidTextBox.Size = New System.Drawing.Size(115, 21)
        Me.VidTextBox.TabIndex = 110
        Me.VidTextBox.TabStop = False
        '
        'VehicleBindingSource
        '
        Me.VehicleBindingSource.DataMember = "Vehicle"
        Me.VehicleBindingSource.DataSource = Me.MolassesDBDataSet
        '
        'MolassesDBDataSet
        '
        Me.MolassesDBDataSet.DataSetName = "molassesDBDataSet"
        Me.MolassesDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VehNoTextBox
        '
        Me.VehNoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VehicleBindingSource, "VehNo", True))
        Me.VehNoTextBox.Location = New System.Drawing.Point(150, 85)
        Me.VehNoTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.VehNoTextBox.Name = "VehNoTextBox"
        Me.VehNoTextBox.Size = New System.Drawing.Size(223, 21)
        Me.VehNoTextBox.TabIndex = 106
        '
        'VOwnerTextBox
        '
        Me.VOwnerTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VehicleBindingSource, "VOwner", True))
        Me.VOwnerTextBox.Location = New System.Drawing.Point(150, 115)
        Me.VOwnerTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.VOwnerTextBox.Name = "VOwnerTextBox"
        Me.VOwnerTextBox.Size = New System.Drawing.Size(393, 21)
        Me.VOwnerTextBox.TabIndex = 108
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VehicleBindingSource, "Address", True))
        Me.AddressTextBox.Location = New System.Drawing.Point(150, 145)
        Me.AddressTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(393, 21)
        Me.AddressTextBox.TabIndex = 109
        '
        'PhoneTextBox
        '
        Me.PhoneTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VehicleBindingSource, "Phone", True))
        Me.PhoneTextBox.Location = New System.Drawing.Point(150, 175)
        Me.PhoneTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.PhoneTextBox.Name = "PhoneTextBox"
        Me.PhoneTextBox.Size = New System.Drawing.Size(223, 21)
        Me.PhoneTextBox.TabIndex = 111
        '
        'FrmVehicle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(628, 510)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Dgv)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(VidLabel)
        Me.Controls.Add(Me.VidTextBox)
        Me.Controls.Add(VehNoLabel)
        Me.Controls.Add(VOwnerLabel)
        Me.Controls.Add(AddressLabel)
        Me.Controls.Add(PhoneLabel)
        Me.Controls.Add(Me.VehNoTextBox)
        Me.Controls.Add(Me.VOwnerTextBox)
        Me.Controls.Add(Me.AddressTextBox)
        Me.Controls.Add(Me.PhoneTextBox)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmVehicle"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FrmVehicle"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.Dgv, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VehicleBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MolassesDBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Dgv As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TableAdapterManager As MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents VehicleTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.VehicleTableAdapter
    Friend WithEvents VidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents VehicleBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MolassesDBDataSet As MolassesProject.molassesDBDataSet
    Friend WithEvents VehNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents VOwnerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PhoneTextBox As System.Windows.Forms.TextBox
End Class
