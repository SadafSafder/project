﻿Public Class FrmPayVouchers
    ' Dim consql As New SqlClient.SqlConnection
    Dim cmdsql As New SqlClient.SqlCommand
    Dim row As Integer
    Dim dt As New DataTable
    Dim dt1 As New DataTable
    Dim dt2 As New DataTable
    Dim dt3 As New DataTable
    Dim dt4 As New DataTable
    Dim dt5 As New DataTable
    Dim tot As Decimal
    Dim rdr As SqlClient.SqlDataReader
    Dim chk As Boolean = False
    Dim cmd As New SqlClient.SqlCommand
    Dim Inv As Double
    Dim grand As Integer
    Public Sub Invoice()
        Try
            '            Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select isnull(Invoice,0) from Inv"
            Inv = cmd.ExecuteScalar()
            'PidTextBox.Text = Format(Inv, "")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub InvoiceGenerator()
        Try
            'Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select isnull(Invoice,0) from Inv"
            Inv = cmd.ExecuteScalar()
            Inv = Inv + 1
            cmd.CommandText = "update Inv set Invoice='" & Inv & "'"
            cmd.ExecuteScalar()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub



    Private Sub total()
        Dim debit As Double = 0
        Dim credit As Double = 0
        For Each row As DataGridViewRow In DataGridView1.Rows

            debit = debit + row.Cells("Debit").Value
            credit = credit + row.Cells("Credit").Value
        Next
        Label4.Text = debit
        Label5.Text = credit
      

    End Sub
    Private Sub insertion()

        Try
           
            For Each row As DataGridViewRow In DataGridView1.Rows

                Invoice()
                ' MessageBox.Show(Inv)
                If row.Cells("Debit").Value = "" Then




                    cmdsql.Connection = con
                    cmdsql.CommandText = "INSERT INTO  transactions (Transid,Transdate,AccName,Description,Credit) VALUES  ('" & Inv & "','" & Datetxt.Text & "','" & row.Cells("AccName").Value & "','" & row.Cells("Detail").Value & "','" & row.Cells("Credit").Value & "')"
                    cmdsql.ExecuteNonQuery()

                    cmdsql.Connection = con
                    cmdsql.CommandText = "INSERT INTO  transactions (Transid,Transdate,AccName,Description,Debit) VALUES  ('" & Inv & "','" & Datetxt.Text & "','Cash','" & row.Cells("Detail").Value & "','" & row.Cells("Credit").Value & "')"
                    cmdsql.ExecuteNonQuery()


                End If

                If row.Cells("Credit").Value = "" Then



                    cmdsql.Connection = con
                    cmdsql.CommandText = "INSERT INTO  transactions (Transid,Transdate,AccName,Description,Debit) VALUES  ('" & Inv & "','" & Datetxt.Text & "','" & row.Cells("AccName").Value & "','" & row.Cells("Detail").Value & "','" & row.Cells("Debit").Value & "')"
                    cmdsql.ExecuteNonQuery()

                    cmdsql.Connection = con
                    cmdsql.CommandText = "INSERT INTO  transactions (Transid,Transdate,AccName,Description,Credit) VALUES  ('" & Inv & "','" & Datetxt.Text & "','Cash','" & row.Cells("Detail").Value & "','" & row.Cells("Debit").Value & "')"
                    cmdsql.ExecuteNonQuery()


                End If

                InvoiceGenerator()

            Next



        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try



    End Sub




    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub



    Private Sub FrmPayVouchers_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then
            AccSearch.ShowDialog()
        End If

    End Sub
    Private Sub cashInhand()
        Try


            Dim a As Decimal

            ''''''''for items qty
            cmdsql = New SqlClient.SqlCommand("select  sum(isnull(Debit,0)) - sum(isnull(Credit,0))  from Transactions where AccName='Cash'", con)




            Label1.Text = cmdsql.ExecuteScalar()
            DataGridView1.Columns(0).ReadOnly = True
        Catch ex As Exception

        End Try
    End Sub


    Private Sub FrmPayVouchers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DBConnection()
      
        cashInhand()
        Me.KeyPreview = True
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try


            insertion()
            cashInhand()
            DataGridView1.Rows.Clear()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If e.ColumnIndex = 0 Then
            AccSearch.ShowDialog()
        End If
    End Sub

    Private Sub DataGridView1_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        If e.ColumnIndex = 0 Then
            ' DataGridView1.CurrentCell = DataGridView1.Item(1, 0)
            DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Selected = True
            DataGridView1.CurrentCell = DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex)
        End If
        total()

    End Sub

    Private Sub DataGridView1_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEnter

    End Sub

    Private Sub DataGridView1_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged


    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        DataGridView1.Rows.Clear()
        Label4.Text = 0.0
        Label5.Text = 0.0
    End Sub

    Private Sub DataGridView1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseClick
        total()
    End Sub

    Private Sub DataGridView1_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.RowHeaderMouseClick
        total()
    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        insertion()
        cashInhand()
        DataGridView1.Rows.Clear()
    End Sub
End Class