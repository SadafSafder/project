﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPurchase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim PidLabel As System.Windows.Forms.Label
        Dim CidLabel As System.Windows.Forms.Label
        Dim AccNameLabel As System.Windows.Forms.Label
        Dim PDateLabel As System.Windows.Forms.Label
        Dim PRateLabel As System.Windows.Forms.Label
        Dim PQtyLabel As System.Windows.Forms.Label
        Dim PAmountLabel As System.Windows.Forms.Label
        Dim TidLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Dim Label7 As System.Windows.Forms.Label
        Dim Label8 As System.Windows.Forms.Label
        Dim Label9 As System.Windows.Forms.Label
        Dim Label10 As System.Windows.Forms.Label
        Dim LblRemainingStock As System.Windows.Forms.Label
        Dim Label13 As System.Windows.Forms.Label
        Dim Label14 As System.Windows.Forms.Label
        Dim Label15 As System.Windows.Forms.Label
        Dim Label17 As System.Windows.Forms.Label
        Dim Label16 As System.Windows.Forms.Label
        Dim Label18 As System.Windows.Forms.Label
        Dim Label20 As System.Windows.Forms.Label
        Me.PidTextBox = New System.Windows.Forms.TextBox()
        Me.CidTextBox = New System.Windows.Forms.TextBox()
        Me.AccNameTextBox = New System.Windows.Forms.TextBox()
        Me.PDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.PRateTextBox = New System.Windows.Forms.TextBox()
        Me.PAmountTextBox = New System.Windows.Forms.TextBox()
        Me.FromTextbox = New System.Windows.Forms.TextBox()
        Me.ToTextbox = New System.Windows.Forms.TextBox()
        Me.FRateTextbox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.PQtyUnitText = New System.Windows.Forms.TextBox()
        Me.FrAmountTextbox = New System.Windows.Forms.TextBox()
        Me.CRatePerKGTextbox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RdoParty = New System.Windows.Forms.RadioButton()
        Me.RdoContract = New System.Windows.Forms.RadioButton()
        Me.ComboItem = New System.Windows.Forms.ComboBox()
        Me.StockBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MolassesDBDataSet1 = New MolassesProject.molassesDBDataSet()
        Me.StockTableAdapter = New MolassesProject.molassesDBDataSetTableAdapters.StockTableAdapter()
        Me.LblRemQty = New System.Windows.Forms.Label()
        Me.BtnParty = New System.Windows.Forms.Button()
        Me.BtnContract = New System.Windows.Forms.Button()
        Me.BtnDirectSaleParty = New System.Windows.Forms.Button()
        Me.CustAccNameTextbox = New System.Windows.Forms.TextBox()
        Me.SRateTextBox = New System.Windows.Forms.TextBox()
        Me.SAmountTextbox = New System.Windows.Forms.TextBox()
        Me.DirectSaleGroupBox = New System.Windows.Forms.GroupBox()
        Me.DirectSaleCheckBox = New System.Windows.Forms.CheckBox()
        Me.LabelAvgRate = New System.Windows.Forms.Label()
        Me.LabelMesage = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.PurComboBox = New System.Windows.Forms.ComboBox()
        Me.VehicleNoTextBox = New System.Windows.Forms.ComboBox()
        Me.Customers_dgv = New System.Windows.Forms.DataGridView()
        Me.LblConQty = New System.Windows.Forms.Label()
        Me.LblItemStock = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Customers_dgv1 = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        PidLabel = New System.Windows.Forms.Label()
        CidLabel = New System.Windows.Forms.Label()
        AccNameLabel = New System.Windows.Forms.Label()
        PDateLabel = New System.Windows.Forms.Label()
        PRateLabel = New System.Windows.Forms.Label()
        PQtyLabel = New System.Windows.Forms.Label()
        PAmountLabel = New System.Windows.Forms.Label()
        TidLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        Label7 = New System.Windows.Forms.Label()
        Label8 = New System.Windows.Forms.Label()
        Label9 = New System.Windows.Forms.Label()
        Label10 = New System.Windows.Forms.Label()
        LblRemainingStock = New System.Windows.Forms.Label()
        Label13 = New System.Windows.Forms.Label()
        Label14 = New System.Windows.Forms.Label()
        Label15 = New System.Windows.Forms.Label()
        Label17 = New System.Windows.Forms.Label()
        Label16 = New System.Windows.Forms.Label()
        Label18 = New System.Windows.Forms.Label()
        Label20 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        CType(Me.StockBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MolassesDBDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DirectSaleGroupBox.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.Customers_dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.Customers_dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PidLabel
        '
        PidLabel.AutoSize = True
        PidLabel.Location = New System.Drawing.Point(34, 30)
        PidLabel.Name = "PidLabel"
        PidLabel.Size = New System.Drawing.Size(29, 15)
        PidLabel.TabIndex = 3
        PidLabel.Text = "ID :"
        '
        'CidLabel
        '
        CidLabel.AutoSize = True
        CidLabel.Location = New System.Drawing.Point(36, 176)
        CidLabel.Name = "CidLabel"
        CidLabel.Size = New System.Drawing.Size(82, 15)
        CidLabel.TabIndex = 5
        CidLabel.Text = "Contract ID:"
        '
        'AccNameLabel
        '
        AccNameLabel.AutoSize = True
        AccNameLabel.Location = New System.Drawing.Point(32, 136)
        AccNameLabel.Name = "AccNameLabel"
        AccNameLabel.Size = New System.Drawing.Size(124, 15)
        AccNameLabel.TabIndex = 7
        AccNameLabel.Text = "Vendor Acc Name:"
        '
        'PDateLabel
        '
        PDateLabel.AutoSize = True
        PDateLabel.Location = New System.Drawing.Point(908, 13)
        PDateLabel.Name = "PDateLabel"
        PDateLabel.Size = New System.Drawing.Size(41, 15)
        PDateLabel.TabIndex = 9
        PDateLabel.Text = "Date:"
        '
        'PRateLabel
        '
        PRateLabel.AutoSize = True
        PRateLabel.Location = New System.Drawing.Point(448, 338)
        PRateLabel.Name = "PRateLabel"
        PRateLabel.Size = New System.Drawing.Size(141, 15)
        PRateLabel.TabIndex = 11
        PRateLabel.Text = "Purchase Rate / Ton:"
        '
        'PQtyLabel
        '
        PQtyLabel.AutoSize = True
        PQtyLabel.Location = New System.Drawing.Point(415, 288)
        PQtyLabel.Name = "PQtyLabel"
        PQtyLabel.Size = New System.Drawing.Size(0, 15)
        PQtyLabel.TabIndex = 13
        PQtyLabel.Visible = False
        '
        'PAmountLabel
        '
        PAmountLabel.AutoSize = True
        PAmountLabel.Location = New System.Drawing.Point(36, 282)
        PAmountLabel.Name = "PAmountLabel"
        PAmountLabel.Size = New System.Drawing.Size(123, 15)
        PAmountLabel.TabIndex = 15
        PAmountLabel.Text = "Purchase Amount:"
        '
        'TidLabel
        '
        TidLabel.AutoSize = True
        TidLabel.Location = New System.Drawing.Point(36, 71)
        TidLabel.Name = "TidLabel"
        TidLabel.Size = New System.Drawing.Size(80, 15)
        TidLabel.TabIndex = 17
        TidLabel.Text = "Vehicle No."
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(34, 405)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(96, 15)
        Label2.TabIndex = 19
        Label2.Text = "Loading From"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(415, 402)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(77, 15)
        Label3.TabIndex = 21
        Label3.Text = "Unload To:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Location = New System.Drawing.Point(32, 322)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(122, 15)
        Label4.TabIndex = 23
        Label4.Text = "Freight Rate / Ton"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Location = New System.Drawing.Point(36, 359)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(108, 15)
        Label5.TabIndex = 25
        Label5.Text = "Freight Amount:"
        '
        'Label7
        '
        Label7.AutoSize = True
        Label7.Location = New System.Drawing.Point(34, 215)
        Label7.Name = "Label7"
        Label7.Size = New System.Drawing.Size(92, 15)
        Label7.TabIndex = 105
        Label7.Text = "Quantity (KG)"
        '
        'Label8
        '
        Label8.AutoSize = True
        Label8.Location = New System.Drawing.Point(34, 250)
        Label8.Name = "Label8"
        Label8.Size = New System.Drawing.Size(125, 15)
        Label8.TabIndex = 109
        Label8.Text = "Contract Rate / KG"
        '
        'Label9
        '
        Label9.AutoSize = True
        Label9.Location = New System.Drawing.Point(448, 299)
        Label9.Name = "Label9"
        Label9.Size = New System.Drawing.Size(101, 15)
        Label9.TabIndex = 112
        Label9.Text = "Purchase Type"
        '
        'Label10
        '
        Label10.AutoSize = True
        Label10.Location = New System.Drawing.Point(34, 105)
        Label10.Name = "Label10"
        Label10.Size = New System.Drawing.Size(35, 15)
        Label10.TabIndex = 113
        Label10.Text = "Item"
        '
        'LblRemainingStock
        '
        LblRemainingStock.AutoSize = True
        LblRemainingStock.Location = New System.Drawing.Point(737, 179)
        LblRemainingStock.Name = "LblRemainingStock"
        LblRemainingStock.Size = New System.Drawing.Size(0, 15)
        LblRemainingStock.TabIndex = 116
        '
        'Label13
        '
        Label13.AutoSize = True
        Label13.Location = New System.Drawing.Point(11, 24)
        Label13.Name = "Label13"
        Label13.Size = New System.Drawing.Size(140, 15)
        Label13.TabIndex = 120
        Label13.Text = "Customer Acc Name:"
        '
        'Label14
        '
        Label14.AutoSize = True
        Label14.Location = New System.Drawing.Point(12, 64)
        Label14.Name = "Label14"
        Label14.Size = New System.Drawing.Size(74, 15)
        Label14.TabIndex = 123
        Label14.Text = "Sale Rate:"
        '
        'Label15
        '
        Label15.AutoSize = True
        Label15.Location = New System.Drawing.Point(12, 105)
        Label15.Name = "Label15"
        Label15.Size = New System.Drawing.Size(92, 15)
        Label15.TabIndex = 125
        Label15.Text = "Sale Amount:"
        '
        'Label17
        '
        Label17.AutoSize = True
        Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label17.ForeColor = System.Drawing.Color.Teal
        Label17.Location = New System.Drawing.Point(12, 118)
        Label17.Name = "Label17"
        Label17.Size = New System.Drawing.Size(170, 29)
        Label17.TabIndex = 129
        Label17.Text = "Average Rate"
        '
        'Label16
        '
        Label16.AutoSize = True
        Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label16.ForeColor = System.Drawing.Color.Teal
        Label16.Location = New System.Drawing.Point(9, 75)
        Label16.Name = "Label16"
        Label16.Size = New System.Drawing.Size(247, 29)
        Label16.TabIndex = 141
        Label16.Text = " Remaining Quantity"
        '
        'Label18
        '
        Label18.AutoSize = True
        Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label18.ForeColor = System.Drawing.Color.Teal
        Label18.Location = New System.Drawing.Point(12, 28)
        Label18.Name = "Label18"
        Label18.Size = New System.Drawing.Size(219, 29)
        Label18.TabIndex = 143
        Label18.Text = "Contract Quantity:"
        '
        'Label20
        '
        Label20.AutoSize = True
        Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label20.ForeColor = System.Drawing.Color.Teal
        Label20.Location = New System.Drawing.Point(9, 166)
        Label20.Name = "Label20"
        Label20.Size = New System.Drawing.Size(149, 29)
        Label20.TabIndex = 129
        Label20.Text = " Item Stock:"
        '
        'PidTextBox
        '
        Me.PidTextBox.Location = New System.Drawing.Point(221, 27)
        Me.PidTextBox.Name = "PidTextBox"
        Me.PidTextBox.ReadOnly = True
        Me.PidTextBox.Size = New System.Drawing.Size(188, 21)
        Me.PidTextBox.TabIndex = 1
        '
        'CidTextBox
        '
        Me.CidTextBox.BackColor = System.Drawing.Color.White
        Me.CidTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CidTextBox.Location = New System.Drawing.Point(221, 170)
        Me.CidTextBox.Name = "CidTextBox"
        Me.CidTextBox.Size = New System.Drawing.Size(188, 21)
        Me.CidTextBox.TabIndex = 0
        '
        'AccNameTextBox
        '
        Me.AccNameTextBox.BackColor = System.Drawing.Color.White
        Me.AccNameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AccNameTextBox.Location = New System.Drawing.Point(221, 133)
        Me.AccNameTextBox.Name = "AccNameTextBox"
        Me.AccNameTextBox.Size = New System.Drawing.Size(266, 21)
        Me.AccNameTextBox.TabIndex = 1
        '
        'PDateDateTimePicker
        '
        Me.PDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.PDateDateTimePicker.Location = New System.Drawing.Point(969, 7)
        Me.PDateDateTimePicker.Name = "PDateDateTimePicker"
        Me.PDateDateTimePicker.Size = New System.Drawing.Size(194, 21)
        Me.PDateDateTimePicker.TabIndex = 10
        '
        'PRateTextBox
        '
        Me.PRateTextBox.BackColor = System.Drawing.Color.White
        Me.PRateTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PRateTextBox.Location = New System.Drawing.Point(553, 338)
        Me.PRateTextBox.Name = "PRateTextBox"
        Me.PRateTextBox.Size = New System.Drawing.Size(188, 21)
        Me.PRateTextBox.TabIndex = 6
        '
        'PAmountTextBox
        '
        Me.PAmountTextBox.BackColor = System.Drawing.Color.White
        Me.PAmountTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PAmountTextBox.ForeColor = System.Drawing.Color.Red
        Me.PAmountTextBox.Location = New System.Drawing.Point(220, 279)
        Me.PAmountTextBox.Name = "PAmountTextBox"
        Me.PAmountTextBox.ReadOnly = True
        Me.PAmountTextBox.Size = New System.Drawing.Size(189, 22)
        Me.PAmountTextBox.TabIndex = 16
        Me.PAmountTextBox.TabStop = False
        '
        'FromTextbox
        '
        Me.FromTextbox.BackColor = System.Drawing.Color.White
        Me.FromTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FromTextbox.Location = New System.Drawing.Point(221, 399)
        Me.FromTextbox.Name = "FromTextbox"
        Me.FromTextbox.Size = New System.Drawing.Size(188, 21)
        Me.FromTextbox.TabIndex = 8
        '
        'ToTextbox
        '
        Me.ToTextbox.BackColor = System.Drawing.Color.White
        Me.ToTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToTextbox.Location = New System.Drawing.Point(560, 394)
        Me.ToTextbox.Name = "ToTextbox"
        Me.ToTextbox.Size = New System.Drawing.Size(167, 21)
        Me.ToTextbox.TabIndex = 9
        '
        'FRateTextbox
        '
        Me.FRateTextbox.BackColor = System.Drawing.Color.White
        Me.FRateTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FRateTextbox.Location = New System.Drawing.Point(219, 316)
        Me.FRateTextbox.Name = "FRateTextbox"
        Me.FRateTextbox.Size = New System.Drawing.Size(188, 21)
        Me.FRateTextbox.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Ivory
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.ForeColor = System.Drawing.Color.Navy
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.Location = New System.Drawing.Point(508, 474)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 39)
        Me.Button1.TabIndex = 86
        Me.Button1.TabStop = False
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Ivory
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.Navy
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button4.Location = New System.Drawing.Point(165, 474)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(110, 39)
        Me.Button4.TabIndex = 11
        Me.Button4.Text = "Save"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Ivory
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.ForeColor = System.Drawing.Color.Navy
        Me.Button2.Location = New System.Drawing.Point(281, 474)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(110, 39)
        Me.Button2.TabIndex = 40
        Me.Button2.TabStop = False
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Ivory
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.ForeColor = System.Drawing.Color.Navy
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button6.Location = New System.Drawing.Point(397, 474)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(105, 39)
        Me.Button6.TabIndex = 85
        Me.Button6.TabStop = False
        Me.Button6.Text = "Update"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'PQtyUnitText
        '
        Me.PQtyUnitText.BackColor = System.Drawing.Color.White
        Me.PQtyUnitText.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PQtyUnitText.Location = New System.Drawing.Point(221, 209)
        Me.PQtyUnitText.Name = "PQtyUnitText"
        Me.PQtyUnitText.Size = New System.Drawing.Size(188, 21)
        Me.PQtyUnitText.TabIndex = 5
        '
        'FrAmountTextbox
        '
        Me.FrAmountTextbox.BackColor = System.Drawing.Color.White
        Me.FrAmountTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FrAmountTextbox.ForeColor = System.Drawing.Color.Red
        Me.FrAmountTextbox.Location = New System.Drawing.Point(220, 356)
        Me.FrAmountTextbox.Name = "FrAmountTextbox"
        Me.FrAmountTextbox.ReadOnly = True
        Me.FrAmountTextbox.Size = New System.Drawing.Size(187, 21)
        Me.FrAmountTextbox.TabIndex = 14
        Me.FrAmountTextbox.TabStop = False
        '
        'CRatePerKGTextbox
        '
        Me.CRatePerKGTextbox.BackColor = System.Drawing.Color.White
        Me.CRatePerKGTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CRatePerKGTextbox.Location = New System.Drawing.Point(221, 244)
        Me.CRatePerKGTextbox.Name = "CRatePerKGTextbox"
        Me.CRatePerKGTextbox.ReadOnly = True
        Me.CRatePerKGTextbox.Size = New System.Drawing.Size(188, 21)
        Me.CRatePerKGTextbox.TabIndex = 110
        Me.CRatePerKGTextbox.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RdoParty)
        Me.GroupBox2.Controls.Add(Me.RdoContract)
        Me.GroupBox2.Location = New System.Drawing.Point(538, 215)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(189, 50)
        Me.GroupBox2.TabIndex = 111
        Me.GroupBox2.TabStop = False
        '
        'RdoParty
        '
        Me.RdoParty.AutoSize = True
        Me.RdoParty.Location = New System.Drawing.Point(112, 20)
        Me.RdoParty.Name = "RdoParty"
        Me.RdoParty.Size = New System.Drawing.Size(57, 19)
        Me.RdoParty.TabIndex = 105
        Me.RdoParty.Text = "Party"
        Me.RdoParty.UseVisualStyleBackColor = True
        '
        'RdoContract
        '
        Me.RdoContract.AutoSize = True
        Me.RdoContract.Checked = True
        Me.RdoContract.Location = New System.Drawing.Point(2, 17)
        Me.RdoContract.Name = "RdoContract"
        Me.RdoContract.Size = New System.Drawing.Size(78, 19)
        Me.RdoContract.TabIndex = 2
        Me.RdoContract.TabStop = True
        Me.RdoContract.Text = "Contract"
        Me.RdoContract.UseVisualStyleBackColor = True
        '
        'ComboItem
        '
        Me.ComboItem.BackColor = System.Drawing.Color.White
        Me.ComboItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboItem.FormattingEnabled = True
        Me.ComboItem.Location = New System.Drawing.Point(222, 102)
        Me.ComboItem.Name = "ComboItem"
        Me.ComboItem.Size = New System.Drawing.Size(188, 23)
        Me.ComboItem.TabIndex = 2
        '
        'StockBindingSource
        '
        Me.StockBindingSource.DataMember = "Stock"
        Me.StockBindingSource.DataSource = Me.MolassesDBDataSet1
        '
        'MolassesDBDataSet1
        '
        Me.MolassesDBDataSet1.DataSetName = "molassesDBDataSet"
        Me.MolassesDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'StockTableAdapter
        '
        Me.StockTableAdapter.ClearBeforeFill = True
        '
        'LblRemQty
        '
        Me.LblRemQty.AutoSize = True
        Me.LblRemQty.BackColor = System.Drawing.Color.Black
        Me.LblRemQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRemQty.ForeColor = System.Drawing.Color.Red
        Me.LblRemQty.Location = New System.Drawing.Point(284, 71)
        Me.LblRemQty.Name = "LblRemQty"
        Me.LblRemQty.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LblRemQty.Size = New System.Drawing.Size(191, 33)
        Me.LblRemQty.TabIndex = 117
        Me.LblRemQty.Text = "Contract Qty"
        Me.LblRemQty.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BtnParty
        '
        Me.BtnParty.Location = New System.Drawing.Point(524, 130)
        Me.BtnParty.Name = "BtnParty"
        Me.BtnParty.Size = New System.Drawing.Size(99, 27)
        Me.BtnParty.TabIndex = 4
        Me.BtnParty.TabStop = False
        Me.BtnParty.Text = "Party"
        Me.BtnParty.UseVisualStyleBackColor = True
        '
        'BtnContract
        '
        Me.BtnContract.Location = New System.Drawing.Point(528, 172)
        Me.BtnContract.Name = "BtnContract"
        Me.BtnContract.Size = New System.Drawing.Size(99, 27)
        Me.BtnContract.TabIndex = 3
        Me.BtnContract.TabStop = False
        Me.BtnContract.Text = "Contract"
        Me.BtnContract.UseVisualStyleBackColor = True
        '
        'BtnDirectSaleParty
        '
        Me.BtnDirectSaleParty.Location = New System.Drawing.Point(345, 54)
        Me.BtnDirectSaleParty.Name = "BtnDirectSaleParty"
        Me.BtnDirectSaleParty.Size = New System.Drawing.Size(99, 27)
        Me.BtnDirectSaleParty.TabIndex = 122
        Me.BtnDirectSaleParty.Text = "Party"
        Me.BtnDirectSaleParty.UseVisualStyleBackColor = True
        '
        'CustAccNameTextbox
        '
        Me.CustAccNameTextbox.BackColor = System.Drawing.Color.White
        Me.CustAccNameTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustAccNameTextbox.Location = New System.Drawing.Point(162, 21)
        Me.CustAccNameTextbox.Name = "CustAccNameTextbox"
        Me.CustAccNameTextbox.Size = New System.Drawing.Size(282, 21)
        Me.CustAccNameTextbox.TabIndex = 121
        '
        'SRateTextBox
        '
        Me.SRateTextBox.BackColor = System.Drawing.Color.White
        Me.SRateTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SRateTextBox.Location = New System.Drawing.Point(162, 59)
        Me.SRateTextBox.Name = "SRateTextBox"
        Me.SRateTextBox.Size = New System.Drawing.Size(171, 21)
        Me.SRateTextBox.TabIndex = 124
        '
        'SAmountTextbox
        '
        Me.SAmountTextbox.BackColor = System.Drawing.Color.White
        Me.SAmountTextbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SAmountTextbox.ForeColor = System.Drawing.Color.Red
        Me.SAmountTextbox.Location = New System.Drawing.Point(162, 99)
        Me.SAmountTextbox.Name = "SAmountTextbox"
        Me.SAmountTextbox.ReadOnly = True
        Me.SAmountTextbox.Size = New System.Drawing.Size(172, 21)
        Me.SAmountTextbox.TabIndex = 126
        '
        'DirectSaleGroupBox
        '
        Me.DirectSaleGroupBox.Controls.Add(Label14)
        Me.DirectSaleGroupBox.Controls.Add(Me.BtnDirectSaleParty)
        Me.DirectSaleGroupBox.Controls.Add(Me.SAmountTextbox)
        Me.DirectSaleGroupBox.Controls.Add(Label13)
        Me.DirectSaleGroupBox.Controls.Add(Me.CustAccNameTextbox)
        Me.DirectSaleGroupBox.Controls.Add(Me.SRateTextBox)
        Me.DirectSaleGroupBox.Controls.Add(Label15)
        Me.DirectSaleGroupBox.Location = New System.Drawing.Point(763, 368)
        Me.DirectSaleGroupBox.Name = "DirectSaleGroupBox"
        Me.DirectSaleGroupBox.Size = New System.Drawing.Size(464, 133)
        Me.DirectSaleGroupBox.TabIndex = 127
        Me.DirectSaleGroupBox.TabStop = False
        '
        'DirectSaleCheckBox
        '
        Me.DirectSaleCheckBox.AutoSize = True
        Me.DirectSaleCheckBox.Location = New System.Drawing.Point(763, 352)
        Me.DirectSaleCheckBox.Name = "DirectSaleCheckBox"
        Me.DirectSaleCheckBox.Size = New System.Drawing.Size(97, 19)
        Me.DirectSaleCheckBox.TabIndex = 127
        Me.DirectSaleCheckBox.TabStop = False
        Me.DirectSaleCheckBox.Text = "Direct Sale"
        Me.DirectSaleCheckBox.UseVisualStyleBackColor = True
        '
        'LabelAvgRate
        '
        Me.LabelAvgRate.AutoSize = True
        Me.LabelAvgRate.BackColor = System.Drawing.Color.Black
        Me.LabelAvgRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LabelAvgRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelAvgRate.ForeColor = System.Drawing.Color.Red
        Me.LabelAvgRate.Location = New System.Drawing.Point(286, 118)
        Me.LabelAvgRate.Name = "LabelAvgRate"
        Me.LabelAvgRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LabelAvgRate.Size = New System.Drawing.Size(92, 33)
        Me.LabelAvgRate.TabIndex = 128
        Me.LabelAvgRate.Text = "00.00"
        Me.LabelAvgRate.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LabelMesage
        '
        Me.LabelMesage.AutoSize = True
        Me.LabelMesage.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LabelMesage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMesage.ForeColor = System.Drawing.Color.Red
        Me.LabelMesage.Location = New System.Drawing.Point(522, 27)
        Me.LabelMesage.Name = "LabelMesage"
        Me.LabelMesage.Size = New System.Drawing.Size(65, 15)
        Me.LabelMesage.TabIndex = 131
        Me.LabelMesage.Text = "Message"
        Me.LabelMesage.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.PurComboBox)
        Me.GroupBox3.Controls.Add(Me.VehicleNoTextBox)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.Button4)
        Me.GroupBox3.Controls.Add(Me.Button6)
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Controls.Add(Me.BtnContract)
        Me.GroupBox3.Controls.Add(Me.LabelMesage)
        Me.GroupBox3.Controls.Add(Me.BtnParty)
        Me.GroupBox3.Controls.Add(Me.ComboItem)
        Me.GroupBox3.Controls.Add(Label10)
        Me.GroupBox3.Controls.Add(Label9)
        Me.GroupBox3.Controls.Add(Me.GroupBox2)
        Me.GroupBox3.Controls.Add(Label8)
        Me.GroupBox3.Controls.Add(Me.CRatePerKGTextbox)
        Me.GroupBox3.Controls.Add(Me.FrAmountTextbox)
        Me.GroupBox3.Controls.Add(Label7)
        Me.GroupBox3.Controls.Add(Me.PQtyUnitText)
        Me.GroupBox3.Controls.Add(Label5)
        Me.GroupBox3.Controls.Add(Label4)
        Me.GroupBox3.Controls.Add(Me.FRateTextbox)
        Me.GroupBox3.Controls.Add(Label3)
        Me.GroupBox3.Controls.Add(Me.ToTextbox)
        Me.GroupBox3.Controls.Add(Label2)
        Me.GroupBox3.Controls.Add(Me.FromTextbox)
        Me.GroupBox3.Controls.Add(PidLabel)
        Me.GroupBox3.Controls.Add(Me.PidTextBox)
        Me.GroupBox3.Controls.Add(CidLabel)
        Me.GroupBox3.Controls.Add(Me.CidTextBox)
        Me.GroupBox3.Controls.Add(AccNameLabel)
        Me.GroupBox3.Controls.Add(Me.AccNameTextBox)
        Me.GroupBox3.Controls.Add(PRateLabel)
        Me.GroupBox3.Controls.Add(Me.PRateTextBox)
        Me.GroupBox3.Controls.Add(PQtyLabel)
        Me.GroupBox3.Controls.Add(PAmountLabel)
        Me.GroupBox3.Controls.Add(Me.PAmountTextBox)
        Me.GroupBox3.Controls.Add(TidLabel)
        Me.GroupBox3.Location = New System.Drawing.Point(10, 30)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(747, 525)
        Me.GroupBox3.TabIndex = 132
        Me.GroupBox3.TabStop = False
        '
        'PurComboBox
        '
        Me.PurComboBox.FormattingEnabled = True
        Me.PurComboBox.Items.AddRange(New Object() {"Purchase Item", "Sale Item"})
        Me.PurComboBox.Location = New System.Drawing.Point(553, 296)
        Me.PurComboBox.Name = "PurComboBox"
        Me.PurComboBox.Size = New System.Drawing.Size(188, 23)
        Me.PurComboBox.TabIndex = 133
        '
        'VehicleNoTextBox
        '
        Me.VehicleNoTextBox.FormattingEnabled = True
        Me.VehicleNoTextBox.Location = New System.Drawing.Point(223, 65)
        Me.VehicleNoTextBox.Name = "VehicleNoTextBox"
        Me.VehicleNoTextBox.Size = New System.Drawing.Size(189, 23)
        Me.VehicleNoTextBox.TabIndex = 132
        '
        'Customers_dgv
        '
        Me.Customers_dgv.BackgroundColor = System.Drawing.Color.LightBlue
        Me.Customers_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Customers_dgv.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Customers_dgv.Location = New System.Drawing.Point(151, 561)
        Me.Customers_dgv.MultiSelect = False
        Me.Customers_dgv.Name = "Customers_dgv"
        Me.Customers_dgv.ReadOnly = True
        Me.Customers_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Customers_dgv.Size = New System.Drawing.Size(964, 178)
        Me.Customers_dgv.TabIndex = 142
        Me.Customers_dgv.TabStop = False
        '
        'LblConQty
        '
        Me.LblConQty.AutoSize = True
        Me.LblConQty.BackColor = System.Drawing.Color.Black
        Me.LblConQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblConQty.ForeColor = System.Drawing.Color.Red
        Me.LblConQty.Location = New System.Drawing.Point(282, 22)
        Me.LblConQty.Name = "LblConQty"
        Me.LblConQty.Size = New System.Drawing.Size(36, 37)
        Me.LblConQty.TabIndex = 144
        Me.LblConQty.Text = "0"
        '
        'LblItemStock
        '
        Me.LblItemStock.AutoSize = True
        Me.LblItemStock.BackColor = System.Drawing.Color.Black
        Me.LblItemStock.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblItemStock.ForeColor = System.Drawing.Color.Red
        Me.LblItemStock.Location = New System.Drawing.Point(283, 163)
        Me.LblItemStock.Name = "LblItemStock"
        Me.LblItemStock.Size = New System.Drawing.Size(103, 37)
        Me.LblItemStock.TabIndex = 131
        Me.LblItemStock.Text = "00.00"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.LblItemStock)
        Me.GroupBox4.Controls.Add(Label20)
        Me.GroupBox4.Controls.Add(Me.LabelAvgRate)
        Me.GroupBox4.Controls.Add(Label18)
        Me.GroupBox4.Controls.Add(Me.LblConQty)
        Me.GroupBox4.Controls.Add(Label17)
        Me.GroupBox4.Controls.Add(Me.LblRemQty)
        Me.GroupBox4.Controls.Add(Label16)
        Me.GroupBox4.Location = New System.Drawing.Point(778, 30)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(476, 235)
        Me.GroupBox4.TabIndex = 145
        Me.GroupBox4.TabStop = False
        '
        'Customers_dgv1
        '
        Me.Customers_dgv1.BackgroundColor = System.Drawing.Color.LightBlue
        Me.Customers_dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Customers_dgv1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Customers_dgv1.Location = New System.Drawing.Point(151, 561)
        Me.Customers_dgv1.MultiSelect = False
        Me.Customers_dgv1.Name = "Customers_dgv1"
        Me.Customers_dgv1.ReadOnly = True
        Me.Customers_dgv1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Customers_dgv1.Size = New System.Drawing.Size(964, 178)
        Me.Customers_dgv1.TabIndex = 146
        Me.Customers_dgv1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(532, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(202, 24)
        Me.Label6.TabIndex = 147
        Me.Label6.Text = "Sale / Purchase Item"
        '
        'FrmPurchase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(1266, 741)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Customers_dgv1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Customers_dgv)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.DirectSaleCheckBox)
        Me.Controls.Add(Me.DirectSaleGroupBox)
        Me.Controls.Add(LblRemainingStock)
        Me.Controls.Add(PDateLabel)
        Me.Controls.Add(Me.PDateDateTimePicker)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Name = "FrmPurchase"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmPurchase"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.StockBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MolassesDBDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DirectSaleGroupBox.ResumeLayout(False)
        Me.DirectSaleGroupBox.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.Customers_dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.Customers_dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AccNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents PRateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PAmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FromTextbox As System.Windows.Forms.TextBox
    Friend WithEvents ToTextbox As System.Windows.Forms.TextBox
    Friend WithEvents FRateTextbox As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents PQtyUnitText As System.Windows.Forms.TextBox
    Friend WithEvents FrAmountTextbox As System.Windows.Forms.TextBox
    Friend WithEvents MolassesDBDataSet As MolassesProject.molassesDBDataSet
    Friend WithEvents PurchaseTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.PurchaseTableAdapter
    Friend WithEvents TableAdapterManager As MolassesProject.molassesDBDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CRatePerKGTextbox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents RdoParty As System.Windows.Forms.RadioButton
    Friend WithEvents RdoContract As System.Windows.Forms.RadioButton
    Friend WithEvents ComboItem As System.Windows.Forms.ComboBox
    Friend WithEvents MolassesDBDataSet1 As MolassesProject.molassesDBDataSet
    Friend WithEvents StockBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StockTableAdapter As MolassesProject.molassesDBDataSetTableAdapters.StockTableAdapter
    Friend WithEvents LblRemQty As System.Windows.Forms.Label
    Friend WithEvents BtnParty As System.Windows.Forms.Button
    Friend WithEvents BtnContract As System.Windows.Forms.Button
    Friend WithEvents BtnDirectSaleParty As System.Windows.Forms.Button
    Friend WithEvents CustAccNameTextbox As System.Windows.Forms.TextBox
    Friend WithEvents SRateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SAmountTextbox As System.Windows.Forms.TextBox
    Friend WithEvents DirectSaleGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents DirectSaleCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents LabelAvgRate As System.Windows.Forms.Label
    Friend WithEvents LabelMesage As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Customers_dgv As System.Windows.Forms.DataGridView
    Friend WithEvents LblConQty As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents VehicleNoTextBox As System.Windows.Forms.ComboBox
    Friend WithEvents PurComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents LblItemStock As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Customers_dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
