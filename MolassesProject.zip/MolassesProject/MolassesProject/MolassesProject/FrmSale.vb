﻿Public Class FrmSale
    Dim cmd As New SqlClient.SqlCommand
    Dim dt As New DataTable
    Dim dt2 As New DataTable
    Dim ds As New DataSet
    Dim ContQty As Integer
    Public SaleParty As Boolean
    Public SaleContract As Boolean
    Dim Chk As Boolean
    Private Sub SaleBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        '   Me.SaleBindingSource.EndEdit()
        '  Me.TableAdapterManager.UpdateAll(Me.MolassesDBDataSet)

    End Sub

    Private Sub Vehiclelink()
        Try


            dt2.Clear()
            Dim da2 As New SqlClient.SqlDataAdapter("select VehNo from Vehicle ", con)

            da2.Fill(dt2)



            VehicleNoTextBox.DataBindings.Clear()

            '  itemtextbox.Text = ""




            VehicleNoTextBox.DataSource = dt2
            VehicleNoTextBox.DisplayMember = "VehNo"

            VehicleNoTextBox.SelectedIndex = 0

            '   buttunNotxt.DataBindings.Add("Text", dt, "ButtonNo")





        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub FrmSale_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MolassesDBDataSet.Stock' table. You can move, or remove it, as needed.

        ' DBConnection()
        Vehiclelink()
        Invoice()
        FillItemCombo()
        GridView()
        ' RdoParty.Checked = True
        'rdoTON.Checked = True
        
    End Sub
    Public Sub Invoice()
        Try
            Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select Invoice from Inv"
            Inv = cmd.ExecuteScalar()
            SidTextBox.Text = Format(Inv, "")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub InvoiceGenerator()
        Try
            Dim Inv As Double
            cmd.Connection = con
            cmd.CommandText = "select Invoice from Inv"
            Inv = cmd.ExecuteScalar()
            Inv = Inv + 1
            cmd.CommandText = "update Inv set Invoice='" & Inv & "'"
            cmd.ExecuteScalar()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ContractQtySelect()
        Try

            cmd.Connection = con
            cmd.CommandText = "select Qty from Contract where Cid='" & CidTextBox.Text & "'"
            ContQty = cmd.ExecuteScalar
        Catch ex As Exception

        End Try

    End Sub
    Private Sub FillItemCombo()
        Dim dasql As New SqlClient.SqlDataAdapter("select * from Stock order by ItemName", con)
        Dim dt As New DataTable
        dasql.Fill(dt)
        If dt.Rows.Count > 0 Then
            ComboItem.DataSource = dt
            ComboItem.DisplayMember = "ItemName"
        End If
    End Sub
    Private Sub GridView()


        ' Dim Customer As String

        '        Dim dasql As New SqlClient.SqlDataAdapter("select * from Customer where CType='" & Customer & "' order by OfficeName", con)
        Dim dasql As New SqlClient.SqlDataAdapter("select * from Sale order by Sid Desc", con)
        dasql.Fill(dt)
        Me.Customers_dgv.DataSource = dt

    End Sub
    Private Sub LoadGridInfo()
        Try

            cmd.Connection = con
            SidTextBox.Text = Customers_dgv.CurrentRow.Cells(0).Value
            CidTextBox.Text = Customers_dgv.CurrentRow.Cells(1).Value
            AccNameTextBox.Text = Customers_dgv.CurrentRow.Cells(2).Value
            SaledateDateTimePicker.Text = Customers_dgv.CurrentRow.Cells(3).Value
            ComboItem.Text = Customers_dgv.CurrentRow.Cells(4).Value
            SRateTextBox.Text = Customers_dgv.CurrentRow.Cells(6).Value
            SQtyTextBox.Text = Customers_dgv.CurrentRow.Cells(7).Value
            SAmountTextBox.Text = Customers_dgv.CurrentRow.Cells(8).Value
            VehicleNoTextBox.Text = Customers_dgv.CurrentRow.Cells(9).Value
            'If rdoKG.Checked = True Then
            'SQtyUnitText.Text = SQtyTextBox.Text
            'End If
            'If rdoMON.Checked = True Then
            'SQtyUnitText.Text = SQtyTextBox.Text / 40
            'End If
            'If rdoTON.Checked = True Then
            'SQtyUnitText.Text = SQtyTextBox.Text / 1000
            'End If

            '/////////////////////// Contract / Party Select //////////////////
            If Customers_dgv.CurrentRow.Cells(1).Value = "" Then
                RdoParty.Checked = True
            Else
                RdoContract.Checked = True
            End If
            '////////////////////////////////////////////////////////////////
            '///////////////// Transportation Select ////////////////////////
            cmd.CommandText = "select TFrom from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FromTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select TTO from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            ToTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FRate from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FrRateTextbox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select FAmount from Transportation where Tid='" & Customers_dgv.CurrentRow.Cells(0).Value & "'"
            FrAmountTextbox.Text = cmd.ExecuteScalar

        Catch ex As Exception

        End Try

    End Sub
    Private Sub UpdateSale()
        cmd.Connection = con
        '///////////////////// Delete From Purchase ///////////
        cmd.CommandText = "delete from Sale where Sid='" & SidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '//////////////////////////////////////////////////////
        '/////////////////////// Update Transaction ////////////
        cmd.CommandText = "delete from Transactions where TransId='" & SidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '////////////////////////////////////////////////////////
        '/////////////////////// Update Transportation ////////////
        cmd.CommandText = "delete from Transportation where Tid='" & SidTextBox.Text & "'"
        cmd.ExecuteNonQuery()
        '////////////////////////////////////////////////////////
        '///////////// Update Contract ///////////////////////
        If CidTextBox.Text <> "" Then
            Dim Stock As Integer
            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
            Stock = cmd.ExecuteScalar
            Stock = Stock - SQtyTextBox.Text
            cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid='" & CidTextBox.Text & "'"
            cmd.ExecuteScalar()

        End If
        '////////////////////////////////////////////////////////
        '///////////// Update Stock //////////////////////////
        cmd.Connection = con
        Dim Qty As Integer
        cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
        Qty = cmd.ExecuteScalar
        Qty = Qty + SQtyTextBox.Text()
        cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
        cmd.ExecuteScalar()

        '////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        '//////////////////////// Saving Again /////////////////////////////////////////////////////////////////////////
        CheckForm()
        If Chk = True Then

            If RdoContract.Checked = True Then
                InsertSale()
                UpdateTransaction()
                UpdateTransportation()
                CheckContract()
                UpdateContract()
                UpdateStock()
            Else
                InsertSale()
                UpdateTransaction()
                UpdateTransportation()
                UpdateStock()
                dt.Clear()
                GridView()
            End If
            Clear()
        End If

    End Sub
    Private Sub CheckForm()

        If SidTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter ID"
            LabelMesage.Visible = True
            Chk = False
            SidTextBox.Focus()
            Exit Sub

        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If AccNameTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Vendor Name"
            LabelMesage.Visible = True
            Chk = False
            AccNameTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If ComboItem.Text = "" Then
            LabelMesage.Text = "Please Enter Item"
            LabelMesage.Visible = True
            Chk = False
            ComboItem.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If SQtyUnitText.Text = "" Then
            LabelMesage.Text = "Please Enter Quantity"
            LabelMesage.Visible = True
            Chk = False
            SQtyUnitText.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If SRateTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Rate"
            LabelMesage.Visible = True
            Chk = False
            SRateTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If VehicleNoTextBox.Text = "" Then
            LabelMesage.Text = "Please Enter Vehicle No"
            LabelMesage.Visible = True
            Chk = False
            VehicleNoTextBox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If FromTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Loading From"
            LabelMesage.Visible = True
            Chk = False
            FromTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If

        If ToTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Destination TO:"
            LabelMesage.Visible = True
            Chk = False
            ToTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If FrRateTextbox.Text = "" Then
            LabelMesage.Text = "Please Enter Freight Rate"
            LabelMesage.Visible = True
            Chk = False
            FrRateTextbox.Focus()
            Exit Sub
        Else
            LabelMesage.Visible = False
            Chk = True
        End If
        If SQtyTextBox.Text > Label19.Text Then
            LabelMesage.Text = "Entered Quantity is more than stock"
            LabelMesage.Visible = True
            Chk = False
            MessageBox.Show("Entered Quantity is more than stock")
            SQtyTextBox.Focus()


        End If
    End Sub
    Private Sub Unitcalculate()
        Try

            '            If rdoKG.Checked = True Then
            'SQtyTextBox.Text = SQtyUnitText.Text
            'If CRatePerKGTextbox.Text <> "" Then
            ' SRateTextBox.Text = CRatePerKGTextbox.Text
            ' End If
            ' Dim a As Decimal
            ' a = SQtyTextBox.Text / 40
            'SAmountTextBox.Text = SQtyTextBox.Text * SRateTextBox.Text
            'End If

            '//////////////////////// Mon Selector/////////////////////////
            'If rdoMON.Checked = True Then
            'SQtyTextBox.Text = SQtyUnitText.Text * 40
            'If CRatePerKGTextbox.Text <> "" Then
            'SRateTextBox.Text = CRatePerKGTextbox.Text * 40
            'End If
            'SAmountTextBox.Text = SQtyUnitText.Text * SRateTextBox.Text
            'End If
            '/////////////////////// Ton Selector ///////////////////////
            'If rdoTON.Checked = True Then
            'SQtyTextBox.Text = SQtyUnitText.Text * 1000
            'If CRatePerKGTextbox.Text <> "" Then
            ' SRateTextBox.Text = CRatePerKGTextbox.Text * 1000
            'End If
            SAmountTextBox.Text = SQtyUnitText.Text * SRateTextBox.Text / 40
            'End If

        Catch ex As Exception

        End Try

    End Sub
    Private Sub FreightCalculate()
        Try
            FrAmountTextbox.Text = (FrRateTextbox.Text / 1000) * SQtyUnitText.Text
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Enable()
        SidTextBox.Enabled = True
        CidTextBox.Enabled = True
        AccNameTextBox.Enabled = True
        SQtyUnitText.Enabled = True
        SQtyTextBox.Enabled = True
        SRateTextBox.Enabled = True
        SAmountTextBox.Enabled = True
        VehicleNoTextBox.Enabled = True
        FromTextbox.Enabled = True
        ToTextbox.Enabled = True
        FrRateTextbox.Enabled = True
        FrAmountTextbox.Enabled = True
    End Sub
    Private Sub Disable()
        SidTextBox.Enabled = False
        CidTextBox.Enabled = False
        AccNameTextBox.Enabled = False
        SQtyUnitText.Enabled = False
        SQtyTextBox.Enabled = False
        SRateTextBox.Enabled = False
        SAmountTextBox.Enabled = False
        VehicleNoTextBox.Enabled = False
        FromTextbox.Enabled = False
        ToTextbox.Enabled = False
        FrRateTextbox.Enabled = False
        FrAmountTextbox.Enabled = False
    End Sub
    Private Sub Clear()
        'SidTextBox.Clear()
        CidTextBox.Clear()
        AccNameTextBox.Clear()
        SQtyUnitText.Clear()
        SQtyTextBox.Clear()
        SRateTextBox.Clear()
        SAmountTextBox.Clear()
        ' VehicleNoTextBox.Clear()
        FromTextbox.Clear()
        ToTextbox.Clear()
        FrRateTextbox.Clear()
        FrAmountTextbox.Clear()
        CRatePerKGTextbox.Clear()
    End Sub
    Private Sub InsertSale()
        Try
            '     Dim ContractRate As Integer
            Dim Rate As Decimal
            Dim AvgRate As Decimal

            '        If rdoKG.Checked = True Then
            'Rate = SRateTextBox.Text
            'End If
            'If rdoMON.Checked = True Then
            'Rate = SRateTextBox.Text / 40
            'End If
            'If rdoTON.Checked = True Then
            'Rate = SRateTextBox.Text / 1000
            'End If
            Rate = SRateTextBox.Text
            cmd.CommandText = "select AvgRate from Stock where ItemName='" & ComboItem.Text & "'"
            AvgRate = cmd.ExecuteScalar
            '/////////////////////////////////////////////////////////////////////////
            cmd.CommandText = "INSERT INTO Sale (Sid,Cid,AccName,SaleDate,Item,AvgRate,SRate,SQty,SAmount,VehicleNo) VALUES('" & SidTextBox.Text & "','" & CidTextBox.Text & "','" & AccNameTextBox.Text & "','" & SaledateDateTimePicker.Text & "','" & ComboItem.Text & "','" & AvgRate & "','" & Rate & "','" & SQtyTextBox.Text & "','" & SAmountTextBox.Text & "','" & VehicleNoTextBox.Text & "')"
            cmd.ExecuteNonQuery()
            '       MessageBox.Show("Record Inserted in sale")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub UpdateContract()
        Dim Status As String
        cmd.Connection = con
        cmd.CommandText = "select Status from Contract where Cid='" & CidTextBox.Text & "'"
        Status = cmd.ExecuteScalar
        If Status = "Finish" Then
            MessageBox.Show("Contract Finished")
        Else
            Dim Stock As Integer
            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
            Stock = cmd.ExecuteScalar
            Stock = Stock - SQtyTextBox.Text
            If Stock < 0 Then
                MessageBox.Show(" Stock limited ")
            Else
                cmd.CommandText = "update Contract set Stock='" & Stock & "' where Cid= ' " & CidTextBox.Text & "'"
                cmd.ExecuteScalar()
                If Stock = 0 Then
                    cmd.CommandText = "update Contract set Status='Finish' where Cid=' " & CidTextBox.Text & "'"
                    cmd.ExecuteScalar()
                End If
            End If
            
            '        MessageBox.Show(Stock)

        End If
    End Sub
    Private Sub CheckContract()
        Dim ChkStatus As Integer
        cmd.Connection = con
        cmd.CommandText = "select Stock from Contract where Cid=' " & CidTextBox.Text & "'"
        ChkStatus = cmd.ExecuteScalar

        If ChkStatus <= 0 Then
            MessageBox.Show("Contract is Finished")
            cmd.CommandText = "update Contract set Status='Finish' where Cid='" & CidTextBox.Text & "'"
            cmd.ExecuteScalar()
        End If
    End Sub
    Private Sub UpdateTransaction()
        cmd.Connection = con
        Dim TID As String
        Dim Transport As String
        TID = "Sale" & ComboItem.Text
        Transport = "Sale From Godwon To " & AccNameTextBox.Text
        '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Debit) values ('" & SidTextBox.Text & "','" & SaledateDateTimePicker.Text & "','" & AccNameTextBox.Text & "','" & TID & "','" & SAmountTextBox.Text & "')"
        cmd.ExecuteNonQuery()
        '///////////////////////////// Updation of Transport Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transactions (TransId,TransDate,AccName,Description,Credit) values ('" & SidTextBox.Text & "','" & SaledateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & Transport & "','" & FrAmountTextbox.Text & "')"
        cmd.ExecuteNonQuery()

    End Sub
    Private Sub UpdateTransportation()
        cmd.Connection = con
        Dim Transport As String
        Transport = "Sale Transport" & ComboItem.Text

        '///////////////////////////// Updation of Vendor Record in Transaction ////////////////////
        cmd.CommandText = "insert into Transportation (Tid,TNature,TDate,VehNo,TFrom,TTO,FRate,Qty,FAmount) values ('" & SidTextBox.Text & "','" & Transport & "','" & SaledateDateTimePicker.Text & "','" & VehicleNoTextBox.Text & "','" & FromTextbox.Text & "','" & ToTextbox.Text & "','" & FrRateTextbox.Text & "','" & SQtyTextBox.Text & "','" & FrAmountTextbox.Text & "')"
        cmd.ExecuteNonQuery()

    End Sub
    Private Sub UpdateStock()
        Try

            cmd.Connection = con
            Dim Qty As Integer
            cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
            Qty = cmd.ExecuteScalar
            Qty = Qty - SQtyTextBox.Text()
            cmd.CommandText = "update Stock set Quantity ='" & Qty & "'from Stock where ItemName='" & ComboItem.Text & "'"
            cmd.ExecuteScalar()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub ContractSelect()
        Try


            Dim Rt As Integer

            cmd.Connection = con
            cmd.CommandText = "select Rate from Contract where Cid='" & CidTextBox.Text & "'"
            Rt = cmd.ExecuteScalar()
            CRatePerKGTextbox.Text = Rt
            cmd.CommandText = "select AccName from Contract where Cid='" & CidTextBox.Text & "'"
            AccNameTextBox.Text = cmd.ExecuteScalar

            cmd.CommandText = "select Item from Contract where Cid='" & CidTextBox.Text & "'"
            ComboItem.Text = cmd.ExecuteScalar

            cmd.CommandText = "select Stock from Contract where Cid='" & CidTextBox.Text & "'"
            Label12.Text = cmd.ExecuteScalar
            ComboItem.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CheckParty()

        If RdoContract.Checked = False Then
            'CidTextBox.Text = ""
            CidTextBox.Enabled = False
            AccNameTextBox.Enabled = True
            ComboItem.Enabled = True
            CRatePerKGTextbox.Enabled = False
            SRateTextBox.Enabled = True
            Clear()
        Else
            CidTextBox.Enabled = True
            AccNameTextBox.Enabled = False
            ComboItem.Enabled = False
            CRatePerKGTextbox.Enabled = False
            SRateTextBox.Enabled = False
            Clear()
        End If
    End Sub
    Private Sub checkEmpty()
        If SRateTextBox.Text = "" Then
            SRateTextBox.Text = 0
        End If
        If SQtyUnitText.Text = "" Then
            SQtyUnitText.Text = 0
        End If

    End Sub
    Private Sub CalculateAvgRate()
        Try


            cmd.Connection = con
            Dim AvgRate As Decimal
            cmd.CommandText = "select AvgRate from Stock where ItemName='" & ComboItem.Text & "'"
            AvgRate = cmd.ExecuteScalar()
            LabelAvgRate.Text = AvgRate
        Catch ex As Exception

        End Try
    End Sub
    Private Sub InsertAvgRate()
        Dim TotalAmount As Decimal
        Dim CAvgRate As Decimal
        TotalAmount = Int(SAmountTextBox.Text) + Int(FrAmountTextbox.Text)
        'MessageBox.Show(TotalAmount)
        CAvgRate = ((TotalAmount / SQtyTextBox.Text) + LabelAvgRate.Text) / 2
        'MessageBox.Show(CAvgRate)
    End Sub
    Private Sub SelectStock()
        Try


            cmd.Connection = con
            Dim Qty As Integer
            cmd.CommandText = "select Quantity from Stock where ItemName='" & ComboItem.Text & "' "
            Qty = cmd.ExecuteScalar
            Label19.Text = Qty
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CidTextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles CidTextBox.KeyDown
        If RdoContract.Checked = True Then
            SaleContract = True
            SaleParty = False
        End If
        If RdoParty.Checked = True Then
            SaleContract = False
            SaleParty = True
        End If

        FrmContractList.ShowDialog()
    End Sub
    Private Sub CidTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CidTextBox.TextChanged
        ContractSelect()
        CalculateAvgRate()
        ContractQtySelect()
        Label13.Text = ContQty
    End Sub
    Private Sub FrRateTextbox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrRateTextbox.TextChanged
        FreightCalculate()
    End Sub
    Private Sub SQtyUnitText_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SQtyUnitText.TextChanged
        Try

            Unitcalculate()
            '            Label12.Text = Label12.Text - SQtyTextBox.Text
            FreightCalculate()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Try

            CheckForm()
            Dim qt As Integer
            Dim CNQTY As Integer
            CNQTY = 1
            If RdoContract.Checked = True Then
                CNQTY = Label12.Text
            End If

            qt = Label19.Text
            If Chk = True Then

                If CNQTY > 0 And qt > 0 Then

                    If RdoContract.Checked = True Then
                        InsertSale()
                        UpdateTransaction()
                        UpdateTransportation()
                        '  CheckContract()
                        UpdateContract()
                        UpdateStock()
                        dt.Clear()
                        GridView()
                    Else
                        InsertSale()
                        UpdateTransaction()
                        UpdateTransportation()
                        UpdateStock()
                        dt.Clear()
                        GridView()
                    End If

                    Clear()
                    InvoiceGenerator()
                    Invoice()
                Else
                    MessageBox.Show("Stock is Over")
                End If


            End If


            RdoParty.Checked = True
            '  rdoTON.Checked = True
        Catch ex As Exception

        End Try

    End Sub
    Private Sub RdoContract_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdoContract.CheckedChanged
        BtnContract.Enabled = True
        BtnParty.Enabled = False
        SaleContract = True
        SaleParty = False
        CheckParty()
    End Sub
    Private Sub RdoParty_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdoParty.CheckedChanged
        BtnContract.Enabled = False
        BtnParty.Enabled = True
        SaleContract = True
        SaleParty = False
        CheckParty()
    End Sub
    Private Sub SRateTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SRateTextBox.TextChanged
        Unitcalculate()
    End Sub
    Private Sub BtnContract_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnContract.Click
        SaleParty = False
        SaleContract = True
        FrmContractList.ShowDialog()

    End Sub
    Private Sub BtnParty_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnParty.Click
        SaleParty = True
        SaleContract = False
        FrmCustomerList.ShowDialog()

    End Sub
    Private Sub ComboItem_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboItem.TextChanged
        CalculateAvgRate()
        SelectStock()
    End Sub
    Private Sub rdoKG_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Unitcalculate()
    End Sub
    Private Sub rdoMON_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Unitcalculate()
    End Sub
    Private Sub rdoTON_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Unitcalculate()
    End Sub
    Private Sub CRatePerKGTextbox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CRatePerKGTextbox.TextChanged
        Try

            If RdoContract.Checked = True Then
                'If rdoKG.Checked = True Then
                SRateTextBox.Text = CRatePerKGTextbox.Text
                'End If
                'If rdoMON.Checked = True Then
                'SRateTextBox.Text = CRatePerKGTextbox.Text * 40
                'End If
                'If rdoTON.Checked = True Then
                'SRateTextBox.Text = CRatePerKGTextbox.Text * 1000
                'End If

            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub AccNameTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CalculateAvgRate()
        'rdoTON.Checked = True
    End Sub
    Private Sub SidTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SidTextBox.TextChanged
        CalculateAvgRate()
        SelectStock()
    End Sub
    Private Sub Customers_dgv_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Customers_dgv.DoubleClick
        LoadGridInfo()
    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        UpdateSale()
    End Sub
    Private Sub Customers_dgv_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Customers_dgv.RowHeaderMouseClick
        LoadGridInfo()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Clear()
        Invoice()
    End Sub
    Private Sub AccNameTextBox_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles AccNameTextBox.KeyDown
        If RdoContract.Checked = True Then
            SaleContract = True
            SaleParty = False
        End If
        If RdoParty.Checked = True Then
            SaleContract = False
            SaleParty = True
        End If

        FrmCustomerList.ShowDialog()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub AccNameTextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccNameTextBox.TextChanged

    End Sub


    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub
End Class